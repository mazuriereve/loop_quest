from __future__ import annotations

import pytest
from case.Case import Case
from case.CaseSpeciale import CaseSpeciale
from case.TypesCase import TypesCase
from personnage.Ennemi import Ennemi
from personnage.TypesEnnemi import TypesEnnemi
from personnage.Joueur import Joueur
from util.Compteur import Compteur

class TestCase:
    def test_init(self: TestCase):
        c = Case(0)
        assert c._listeEnnemis == []
        assert c.coffre == False
        assert c.piege == ""
        
    def test_setter(self: TestCase):
        c = Case(0)
        e1 = Ennemi("Ennemi1", 1, 1, 1, 1, 1, "", (1, 1), 1, 1)
        c.listeEnnemis.append(e1)
        assert c.listeEnnemis[0].nom == "Ennemi1"
        c.coffre = True
        assert c.coffre == True
        c.piege = "piege"
        assert c.piege == "piege"
        
    def test_retirer_ennemis(self: TestCase):
        c = Case(0)
        e1 = Ennemi("Ennemi1", 1, 1, 1, 1, 1, "", (1, 1), 1, 1)
        c.listeEnnemis.append(e1)
        c.retirer_ennemis()
        assert c.listeEnnemis == []
        
class TestCaseSpeciale:
    def test_init(self: TestCaseSpeciale):
        c = CaseSpeciale(0, "case1", 1, TypesEnnemi.Araignee, "effet")
        assert c.compteurEnnemi.valeur == 1
        assert c.compteurEnnemi.valeurInitiale == 1
        assert c.typeEnnemi == TypesEnnemi.Araignee
        assert c.effets == "effet"
        Compteur.setAllCompteur([])
        
    def test_init2(self: TestCaseSpeciale):
        c = CaseSpeciale(0, "case1", 1, TypesEnnemi.Araignee, "effet", True)
        assert c.compteurEnnemi.valeur == 1
        assert c.compteurEnnemi.valeurInitiale == 1
        assert c.typeEnnemi == TypesEnnemi.Araignee
        assert c.effets == "effet"
        assert c.compteurCoffre.valeur == 50
        assert c.compteurCoffre.valeurInitiale == 50
        Compteur.setAllCompteur([])
        
    def test_setter(self: TestCaseSpeciale):
        c = CaseSpeciale(0, "case1", 1, TypesEnnemi.Araignee, "effet")
        c.compteurEnnemi = Compteur(2)
        assert c.compteurEnnemi.valeur == 2
        assert c.compteurEnnemi.valeurInitiale == 2
        c.typeEnnemi = TypesEnnemi.Squelette
        assert c.typeEnnemi == TypesEnnemi.Squelette
        c.effets = "effet2"
        assert c.effets == "effet2"
        c.cheminTextureCase = "texture2"
        assert c.cheminTextureCase == "texture2"
        c.compteurCoffre = Compteur(3)
        assert c.compteurCoffre.valeur == 3
        assert c.compteurCoffre.valeurInitiale == 3
        Compteur.setAllCompteur([])
        
    def test_retirer_ennemis(self: TestCaseSpeciale):
        c = CaseSpeciale(0, "case1", 1, TypesEnnemi.Araignee, "effet", "texture")
        c.listeEnnemis.append(c.typeEnnemi.creerEnnemi())
        c.retirer_ennemis()
        assert c.listeEnnemis == []
        Compteur.setAllCompteur([])
        
class TestTypesCase:
    def test_init_et_cimetiere(self: TestTypesCase):
        c: CaseSpeciale = TypesCase.caseCimetiere.creer_case_speciale(0, [])
        assert c.listeEnnemis == []
        assert c.compteurEnnemi.valeur == 20
        assert c.compteurEnnemi.valeurInitiale == 20
        assert c.typeEnnemi == TypesEnnemi.Squelette
        assert c.effets == None
        
        for _ in range(20):
            c.compteurEnnemi.decompter()
        assert c.compteurEnnemi.valeur == 20
        assert len(c.listeEnnemis) == 1
        
        Compteur.setAllCompteur([])
        
    def test_village(self: TestTypesCase):
        c: CaseSpeciale = TypesCase.caseVillage.creer_case_speciale(0, [])
        assert c.listeEnnemis == []
        assert c.compteurEnnemi.valeur == 20
        assert c.compteurEnnemi.valeurInitiale == 20
        assert c.typeEnnemi == TypesEnnemi.Voleur
        
        j1 = Joueur("Joueur1", 3, 1, 1, 1, "", "", (1, 1), 1, 1)
        j1.pointDeVie = 1
        joueurActuel = 0
        c.donnerEffet(joueurActuel)
        assert j1.pointDeVie == 3
        Joueur.setAllJoueur([])
        
        for _ in range(20):
            c.compteurEnnemi.decompter()
        assert c.compteurEnnemi.valeur == 20
        assert len(c.listeEnnemis) == 1
        Compteur.setAllCompteur([])

    def test_marais(self: TestTypesCase):
        c: CaseSpeciale = TypesCase.caseMarais.creer_case_speciale(0, [])
        assert c.listeEnnemis == []
        assert c.compteurEnnemi.valeur == 25
        assert c.compteurEnnemi.valeurInitiale == 25
        assert c.typeEnnemi == TypesEnnemi.Sorciere
        
        j1 = Joueur("Joueur1", 1, 1, 3, 1, "", "", (1, 1), 1, 1)
        joueurActuel = 0
        c.donnerEffet(joueurActuel)
        assert j1.defense == 1
        
        for _ in range(2):
            Compteur.decompterAll()
        assert j1.defense == 3
        Joueur.setAllJoueur([])
        
        for _ in range(23):
            c.compteurEnnemi.decompter()
        assert c.compteurEnnemi.valeur == 25
        assert len(c.listeEnnemis) == 1
        Joueur.setAllJoueur([])
        Compteur.setAllCompteur([])
        
    def test_nid(self: TestTypesCase):
        c: CaseSpeciale = TypesCase.caseNid.creer_case_speciale(0, [])
        assert c.listeEnnemis == []
        assert c.compteurEnnemi.valeur == 15
        assert c.compteurEnnemi.valeurInitiale == 15
        assert c.typeEnnemi == TypesEnnemi.Araignee
        
        j1 = Joueur("Joueur1", 1, 1, 1, 3, "", "", (1, 1), 1, 1)
        joueurActuel = 0
        c.donnerEffet(joueurActuel)
        assert j1.vitesse == 1
        
        for _ in range(2):
            Compteur.decompterAll()
        assert j1.vitesse == 3
        Joueur.setAllJoueur([])
        
        for _ in range(13):
            c.compteurEnnemi.decompter()
        assert c.compteurEnnemi.valeur == 15
        assert len(c.listeEnnemis) == 1
        Joueur.setAllJoueur([])
        Compteur.setAllCompteur([])
        
    def test_feudecamp(self: TestTypesCase):
        c: CaseSpeciale = TypesCase.caseFeuDeCamp.creer_case_speciale(0, [])
        assert c.listeEnnemis == []
        assert c.typeEnnemi == None
        
        j1 = Joueur("Joueur1", 6, 1, 1, 1, "", "", (1, 1), 1, 1)
        j1.pointDeVie = 1
        j1.capaciteDisponible = False
        joueurActuel = 0
        
        c.donnerEffet(joueurActuel)
        assert j1.pointDeVie == 6
        assert j1.capaciteDisponible == True
        Joueur.setAllJoueur([])
        Compteur.setAllCompteur([])

if __name__ == "__main__":
    pytest.main()
    Compteur.setAllCompteur([])