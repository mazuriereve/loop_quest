from __future__ import annotations

import pytest
import constant
from plateau import *
from util.Compteur import Compteur

class TestPlateau:
    def test_init(self: TestPlateau):
        p = Plateau()
        assert p.compteurZombie.valeur == 15
        assert p.compteurZombie.valeurInitiale == 15
        assert isinstance(p.listeCases[0], CaseSpeciale)
        for i in range(1, constant.TAILLE_PLATEAU):
            assert isinstance(p.listeCases[i], Case)
            if i not in [3, 8, 15, 20]:
                assert p.listeCases[i].listeEnnemis == []
            else:
                assert len(p.listeCases[i].listeEnnemis) == 1
                assert p.listeCases[i].listeEnnemis[0].nom == "Zombie"
        Compteur.setAllCompteur([])
        
    def test_detruire_case(self: TestPlateau):
        p = Plateau()
        p.listeCases[2] = TypesCase.caseMarais.creer_case_speciale(0, [])
        assert p.detruireCase(0) == False
        assert p.detruireCase(1) == False
        assert p.detruireCase(2) == True
        assert len(p.listeCases) == constant.TAILLE_PLATEAU
        Compteur.setAllCompteur([])
        
    def test_compteur(self: TestPlateau):
        p = Plateau()
        compteEnnemi = 0
        for _ in range(15):
            p.compteurZombie.decompter()
        assert p.compteurZombie.valeur == 15
        assert p.compteurZombie.valeurInitiale == 15
        for i in range(constant.TAILLE_PLATEAU):
            if len(p.listeCases[i].listeEnnemis) != 0:
                assert len(p.listeCases[i].listeEnnemis) in [1, 2, 3]
                compteEnnemi += len(p.listeCases[i].listeEnnemis)
                assert p.listeCases[i].listeEnnemis[0].nom == "Zombie"
        assert compteEnnemi == 6
        Compteur.setAllCompteur([])

if __name__ == "__main__":
    pytest.main()
    Compteur.setAllCompteur([])