from __future__ import annotations

import pytest
from util.Effet import Effet
from util.EffetTemporaire import EffetTemporaire
from util.Compteur import Compteur
from personnage.TypesEnnemi import TypesEnnemi
from personnage.Joueur import Joueur
from personnage.ClassesJoueur import ClassesJoueur
from case.TypesCase import TypesCase
from case.CaseSpeciale import CaseSpeciale
import plateau
import operator

class TestEffet:
    def test_init(self: TestEffet):
        a: int = 0
        e = Effet(cible=a, valeur=1)
        assert e.cible == a
        assert e.valeur == 1
        assert e.operateur == None
        assert e._attributCible == None
        
    def test_appliquer_effet1(self: TestEffet):
        p = plateau.Plateau()
        index = 2
        e1 = Effet(cible=p, valeur=TypesCase.caseCimetiere.creer_case_speciale(0, []), attributCible="listeCases")
        e1.appliquerEffet(index=index)
        assert isinstance(p.listeCases[index], CaseSpeciale)
        assert p.listeCases[index].typeEnnemi == TypesEnnemi.Squelette
        e2 = Effet(cible=None, valeur=index, operateur=p.detruireCase)
        e2.appliquerEffet()
        assert not isinstance(p.listeCases[index], CaseSpeciale)
        Compteur.setAllCompteur([])
    
    def test_appliquer_effet2(self: TestEffet):
        joueurActuel = 0
        j1 = Joueur("Joueur1", 2, 1, 1, 1, "", "", (1, 1), 1, 1)
        e = Effet(Joueur.getAllJoueur()[joueurActuel], 1, "pointDeVie", operator.sub)
        e.appliquerEffet()
        assert j1.pointDeVie == 1
        Joueur.setAllJoueur([])
        
class TestEffetTemporaire:
    def test_init1(self: TestEffetTemporaire):
        j1 = Joueur("Joueur1", 2, 1, 1, 1, "", "", (1, 1), 1, 1)
        e = EffetTemporaire(j1, operator.sub, 1, 2, "pointDeVie", repetition=True)
        assert e.cible == j1
        assert e.operateur == operator.sub
        assert e.valeur == 1
        assert e.duree.valeur == 2
        assert e.repetition == True
        assert e.attributCible == "pointDeVie"
        assert e.operateurInv == None
        assert e.valeurInv == None
        Joueur.setAllJoueur([])

    def test_inverse(self: TestEffetTemporaire):
        joueurActuel = 0
        j1 = Joueur("Joueur1", 3, 1, 1, 1, "", "", (1, 1), 1, 1)
        e = EffetTemporaire(Joueur.getAllJoueur()[joueurActuel], operator.sub, 1, 2, "pointDeVie", operateurInv=operator.add, valeurInv=1)
        assert j1.pointDeVie == 2
        e.duree.decompter()
        assert j1.pointDeVie == 2
        e.duree.decompter()
        assert e.duree not in Compteur.getAllCompteur()
        assert j1.pointDeVie == 3
        Compteur.setAllCompteur([])
        Joueur.setAllJoueur([])

    def test_repete(self: TestEffetTemporaire):
        joueurActuel = 0
        j1 = Joueur("Joueur1", 3, 1, 1, 1, "", "", (1, 1), 1, 1)
        e = EffetTemporaire(Joueur.getAllJoueur()[joueurActuel], operator.sub, 1, 2, "pointDeVie", repetition=True)
        assert j1.pointDeVie == 2
        e.duree.decompter()
        assert j1.pointDeVie == 1
        e.duree.decompter()
        assert j1.pointDeVie == 1
        assert e.duree not in Compteur.getAllCompteur()
        Compteur.setAllCompteur([])
        Joueur.setAllJoueur([])
        
    def test_buff_magicien(self: TestEffetTemporaire):
        joueurActuel = 0
        j1 = ClassesJoueur.Magicien.creerJoueur()
        j1.pointDeVie = 5
        e1 = Effet(Joueur.getAllJoueur()[joueurActuel], 5, "pointDeVie", operator.add)
        e1.appliquerEffet()
        e2 = EffetTemporaire(Joueur.getAllJoueur()[joueurActuel], operator.add, 2, 2, "attaque", operator.sub, 2)
        e3 = EffetTemporaire(Joueur.getAllJoueur()[joueurActuel], operator.add, 2, 2, "defense", operator.sub, 2)
        e4 = EffetTemporaire(Joueur.getAllJoueur()[joueurActuel], operator.add, 2, 2, "vitesse", operator.sub, 2)
        assert j1.pointDeVie == 10
        assert j1.attaque == 12
        assert j1.defense == 6
        assert j1.vitesse == 7
        for _ in range(2):
            Compteur.decompterAll()
        assert e2.duree.valeur == 0
        assert j1.pointDeVie == 10
        assert j1.attaque == 10
        assert j1.defense == 4
        assert j1.vitesse == 5
        Compteur.setAllCompteur([])
        Joueur.setAllJoueur([])
        
if __name__ == "__main__":
    pytest.main()
    Compteur.setAllCompteur([])
    Joueur.setAllJoueur([])