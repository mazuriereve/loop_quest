from __future__ import annotations

import pytest
from util.ProprietaireCompteur import ProprietaireCompteur
from util.Compteur import Compteur
from util.CompteurTemporaire import CompteurTemporaire

class Proprio(ProprietaireCompteur):
    def compteurModifie(self: Proprio): pass

class TestCompteur:
    def test_init2(self: TestCompteur):
        c = Compteur(5)
        c.ajouterProprietaire(Proprio())
        assert c.valeur == 5
        assert c.valeurInitiale == 5
        Compteur.setAllCompteur([])
        
    def test_ajouterProprietaire(self: TestCompteur):
        c = Compteur(1)
        p = Proprio()
        c.ajouterProprietaire(p)
        assert c.proprietaire == p
        Compteur.setAllCompteur([])
        
    def test_decompter(self: TestCompteur):
        c = Compteur(5)
        c.ajouterProprietaire(Proprio())
        c.decompter()
        assert c.valeur == 4
        Compteur.setAllCompteur([])
        
    def test_decompterAll(self: TestCompteur):
        c1 = Compteur(5)
        c2 = Compteur(5)
        c1.ajouterProprietaire(Proprio())
        c2.ajouterProprietaire(Proprio())
        Compteur.decompterAll()
        assert c1.valeur == 4
        assert c2.valeur == 4
        Compteur.setAllCompteur([])
        
    def test_decompter2(self: TestCompteur):
        c = Compteur(1)
        c.ajouterProprietaire(Proprio())
        c.decompter()
        assert c.valeur == 1
        Compteur.setAllCompteur([])
        
    def test_retirerCompteur(self: TestCompteur):
        c = Compteur(1)
        c.ajouterProprietaire(Proprio())
        c.retirerCompteur()
        assert c not in Compteur.getAllCompteur()
        assert c.proprietaire == None


class TestCompteurTemporaire:
    def test_init(self: TestCompteurTemporaire):
        c = CompteurTemporaire(5)
        c.ajouterProprietaire(Proprio())
        assert c.valeur == 5
        assert c.valeurInitiale == 5
        Compteur.setAllCompteur([])
    
    def test_decompter(self: TestCompteurTemporaire):
        c = CompteurTemporaire(5)
        c.ajouterProprietaire(Proprio())
        c.decompter()
        assert c.valeur == 4
        Compteur.setAllCompteur([])
        
    def test_decompterAll(self: TestCompteurTemporaire):
        c1 = CompteurTemporaire(5)
        c2 = CompteurTemporaire(5)
        c1.ajouterProprietaire(Proprio())
        c2.ajouterProprietaire(Proprio())
        Compteur.decompterAll()
        assert c1.valeur == 4
        assert c2.valeur == 4
        Compteur.setAllCompteur([])
        
    def test_decompter2(self: TestCompteurTemporaire):
        c = CompteurTemporaire(1)
        c.ajouterProprietaire(Proprio())
        c.decompter()
        assert c not in Compteur.getAllCompteur()
        Compteur.setAllCompteur([])
        
if __name__ == "__main__":
    pytest.main()
    Compteur.setAllCompteur([])