from __future__ import annotations

import pytest
import plateau
from case.TypesCase import TypesCase
from case.CaseSpeciale import CaseSpeciale
from cartes.ListeCartes import ListeCartes
from util.Compteur import Compteur
from personnage.Joueur import Joueur
from personnage.TypesEnnemi import TypesEnnemi

# class TestCarte:
#     def test_init1(self: TestCarte):
#         c = carte.Carte("test", carte.TypeCarte.Consommable, "pass")
#         assert c.nom == "test"
#         assert c.typeCarte == carte.TypeCarte.Consommable
#         assert c.effet == "pass"
#         assert c.duree == None
#         assert c.effetInv == None
#         assert c.effetRepete == False
    
#     def test_init2(self: TestCarte):
#         c = carte.Carte("test", carte.TypeCarte.Consommable, "pass", 5, None, True)
#         assert c.nom == "test"
#         assert c.typeCarte == carte.TypeCarte.Consommable
#         assert c.effet == "pass"
#         assert c.duree == 5
#         assert c.effetInv == None
#         assert c.effetRepete == True
        
#     def test_appliquerEffet(self: TestCarte):
#         j1 = Joueur("Joueur1", 1, 1, 1, 1, "", "", 1)
#         c = carte.Carte("test", carte.TypeCarte.Consommable, "Joueur.getAllJoueur()[0].attaque += 1")
#         try :
#             c.appliquerEffet()
#         except:
#             exec(c.effet)
#         assert j1.attaque == 2
#         Joueur.setAllJoueur([])
        
class TestListeCartes:
    def test_teleportation(self: TestListeCartes):
        joueurActuel = 0
        j1 = Joueur("Joueur1", 1, 1, 1, 1, "", "", (1, 1), 1, 1)
        c = ListeCartes.Teleportation.genererCarte(None, joueurActuel)
        c.utiliser(2)
        assert j1.emplacement == 2
        Joueur.setAllJoueur([])
        
    def test_potion(self: TestListeCartes):
        j1 = Joueur("Joueur1", 3, 1, 1, 1, "", "", (1, 1), 1, 1)
        joueurActuel = 0
        j1.pointDeVie = 1
        c = ListeCartes.Potion.genererCarte(None, joueurActuel)
        c.utiliser()
        assert j1.pointDeVie == 3
        Joueur.setAllJoueur([])
    
    def test_carte_village(self: TestListeCartes):
        p = plateau.Plateau()
        c = ListeCartes.Village.genererCarte(p, None)
        c.utiliser(2)
        assert isinstance(p.listeCases[2], CaseSpeciale)
        assert p.listeCases[2].typeEnnemi == TypesEnnemi.Voleur
        Compteur.setAllCompteur([])
        
    def test_carte_cimetiere(self: TestListeCartes):
        p = plateau.Plateau()
        c = ListeCartes.Cimetiere.genererCarte(p, None)
        c.utiliser(2)
        assert isinstance(p.listeCases[2], CaseSpeciale)
        assert p.listeCases[2].typeEnnemi == TypesEnnemi.Squelette
        Compteur.setAllCompteur([])
        
    def test_carte_marais(self: TestListeCartes):
        p = plateau.Plateau()
        c = ListeCartes.Marais.genererCarte(p, None)
        c.utiliser(2)
        assert isinstance(p.listeCases[2], CaseSpeciale)
        assert p.listeCases[2].typeEnnemi == TypesEnnemi.Sorciere
        Compteur.setAllCompteur([])
        
    def test_carte_nid(self: TestListeCartes):
        p = plateau.Plateau()
        c = ListeCartes.Nid.genererCarte(p, None)
        c.utiliser(2)
        assert isinstance(p.listeCases[2], CaseSpeciale)
        assert p.listeCases[2].typeEnnemi == TypesEnnemi.Araignee
        Compteur.setAllCompteur([])
        
    def test_demolition(self: TestListeCartes):
        p = plateau.Plateau()
        p.listeCases[2] = TypesCase.caseMarais.creer_case_speciale(0, [])
        c = ListeCartes.Demolition.genererCarte(p, None)
        c.utiliser(2)
        assert not isinstance(p.listeCases[2], CaseSpeciale)
        Compteur.setAllCompteur([])

if __name__ == "__main__":
    pytest.main()