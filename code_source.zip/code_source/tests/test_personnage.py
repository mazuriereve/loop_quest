from __future__ import annotations

import pytest
from personnage.Personnage import Personnage
from personnage.Joueur import Joueur
from personnage.ClassesJoueur import ClassesJoueur
from personnage.Ennemi import Ennemi
from personnage.TypesEnnemi import TypesEnnemi
from personnage.CapaciteSpeciale import CapaciteSpeciale
class TestPersonnage:
    def test_init1(self: TestPersonnage):
        p = Personnage("Personnage1", 1, 1, 1, 1, "", (1, 1), 1, 1)
        assert p.nom == "Personnage1"
        assert p.attaque == 1
        assert p.defense == 1
        assert p.pointDeVie == 1
        assert p.vitesse == 1
        assert p.cheminSprite == ""
        assert p.dimension == (1, 1)
        assert p.scaling == 1
        assert p.niveau == 1
        
    def test_init2(self: TestPersonnage):
        p = Personnage("Personnage1", 1, 1, 1, 1, "", (1, 1), 1, 2)
        assert p.nom == "Personnage1"
        assert p.attaque == 3
        assert p.defense == 3
        assert p.pointDeVie == 3
        assert p.vitesse == 3
        assert p.cheminSprite == ""
        assert p.scaling == 1
        assert p.niveau == 2
        
    def test_setter_niveau(self: TestPersonnage):
        p = Personnage("Personnage1", 1, 1, 1, 1, "", (1, 1), 1, 1)
        p.niveau = 2
        assert p.attaque == 3
        assert p.defense == 3
        assert p.pointDeVie == 1 + p.pointDeVieMax//2
        assert p.vitesse == 3
        assert p.niveau == 2
        
    def test_est_mort(self: TestPersonnage):
        p = Personnage("Personnage1", 1, 1, 1, 1, "", (1, 1), 1, 1)
        assert p.est_mort() == False
        p.pointDeVie = 0
        assert p.est_mort() == True
        
        
class TestJoueur:
    def test_init(self: TestPersonnage):
        j1 = Joueur("Joueur1", 1, 1, 1, 1, "", "", (1, 1), 1, 1)
        assert j1.nom == "Joueur1"
        assert j1.attaque == 1
        assert j1.defense == 1
        assert j1.pointDeVie == 1
        assert j1.vitesse == 1
        assert j1.cheminSprite == ""
        assert j1.scaling == 1
        assert j1.niveau == 1
        assert j1.emplacement == 0
        assert j1.pointExperience == 0
        assert j1.cartes[0].nom == "Potion"
        assert j1.cartes[1].nom == "Teleportation"
        Joueur.setAllJoueur([])
        
    def test_allJoueur(self: TestPersonnage):
        j1 = Joueur("Joueur1", 1, 1, 1, 1, "", "", (1, 1), 1, 1)
        assert Joueur.getAllJoueur()[0] == j1
        j2 = Joueur("Joueur2", 1, 1, 1, 1, "", "", (1, 1), 1, 1)
        assert len(Joueur.getAllJoueur()) == 2
        Joueur.setAllJoueur([])
        
    def test_monterNiveau1(self: TestPersonnage):
        j1 = Joueur("Joueur1", 1, 1, 1, 1, "", "", (1, 1), 1, 1)
        j1.niveau += 1
        assert j1.attaque == 3
        assert j1.defense == 3
        assert j1.pointDeVie == 1 + j1.pointDeVieMax//2
        assert j1.vitesse == 3
        assert j1.niveau == 2
        Joueur.setAllJoueur([])
        
    def test_monterNiveau2(self: TestPersonnage):
        j1 = Joueur("Joueur1", 1, 1, 1, 1, "", "", (1, 1), 1, 1)
        j1.pointExperience += 100
        assert j1.pointExperience == 40
        assert j1.pointExperienceMax == 70
        assert j1.niveau == 2
        assert j1.attaque == 3
        assert j1.defense == 3
        assert j1.pointDeVie == 1 + j1.pointDeVieMax//2
        assert j1.vitesse == 3
        Joueur.setAllJoueur([])
        
    def test_utilisationAutoPotion(self: TestPersonnage):
        import cartes.TypeVar as TypeVar
        
        j1 = Joueur("Joueur1", 10, 1, 1, 1, "", "", (1, 1), 1, 1)
        assert j1.pointDeVie == 10
        j1.pointDeVie = 0
        # assert j1.test1 == True
        assert j1.pointDeVie == 5
        Joueur.setAllJoueur([])
        
class TestClassesJoueur:
    def test_chevalier(self: TestClassesJoueur):
        j1 = ClassesJoueur.Chevalier.creerJoueur()
        assert j1.nom == "Chevalier"
        assert j1.pointDeVie == 15
        assert j1.attaque == 8
        assert j1.defense == 5
        assert j1.vitesse == 2
        assert j1.capaciteSpeciale == CapaciteSpeciale.Parade
        assert j1.capaciteDisponible == True
        Joueur.setAllJoueur([])
        
    def test_archer(self: TestClassesJoueur):
        j1 = ClassesJoueur.Archer.creerJoueur()
        assert j1.nom == "Archer"
        assert j1.pointDeVie == 14
        assert j1.attaque == 6
        assert j1.defense == 4
        assert j1.vitesse == 7
        assert j1.capaciteSpeciale == CapaciteSpeciale.Fleche_neutralisante
        assert j1.capaciteDisponible == True
        Joueur.setAllJoueur([])
        
    def test_magicien(self: TestClassesJoueur):
        j1 = ClassesJoueur.Magicien.creerJoueur()
        assert j1.nom == "Magicien"
        assert j1.pointDeVie == 12
        assert j1.attaque == 10
        assert j1.defense == 4
        assert j1.vitesse == 5
        assert j1.capaciteSpeciale == CapaciteSpeciale.Enchantement
        assert j1.capaciteDisponible == True
        Joueur.setAllJoueur([])
        
    def test_chasseur(self: TestClassesJoueur):
        j1 = ClassesJoueur.Chasseur.creerJoueur()
        assert j1.nom == "Chasseur"
        assert j1.pointDeVie == 14
        assert j1.attaque == 7
        assert j1.defense == 5
        assert j1.vitesse == 7
        assert j1.capaciteSpeciale == CapaciteSpeciale.Piege_a_ours
        assert j1.capaciteDisponible == True
        Joueur.setAllJoueur([])
        
    def test_farceur(self: TestClassesJoueur):
        j1 = ClassesJoueur.Farceur.creerJoueur()
        assert j1.nom == "Farceur"
        assert j1.pointDeVie == 10
        assert j1.attaque == 4
        assert j1.defense == 3
        assert j1.vitesse == 15
        assert j1.capaciteSpeciale == CapaciteSpeciale.Farce
        assert j1.capaciteDisponible == True
        Joueur.setAllJoueur([])
        
        
class TestEnnemi:
    def test_init(self: TestEnnemi):
        e1 = Ennemi("Ennemi1", 1, 1, 1, 1, 1, "", (1, 1), 1, 1)
        assert e1.nom == "Ennemi1"
        assert e1.pointDeVie == 1
        assert e1.attaque == 1
        assert e1.defense == 1
        assert e1.vitesse == 1
        assert e1.gainExperience == 1
        assert e1.cheminSprite == ""
        assert e1.scaling == 1
        assert e1.niveau == 1
        
class TestTypesEnnemi:
    def test_zombie(self: TestEnnemi):
        e1 = TypesEnnemi.Zombie.creerEnnemi()
        assert e1.nom == "Zombie"
        assert e1.pointDeVie == 4
        assert e1.attaque == 3
        assert e1.defense == 1
        assert e1.vitesse == 1
        assert e1.gainExperience == 10
        
    def test_squelette(self: TestEnnemi):
        e1 = TypesEnnemi.Squelette.creerEnnemi()
        assert e1.nom == "Squelette"
        assert e1.pointDeVie == 5
        assert e1.attaque == 4
        assert e1.defense == 3
        assert e1.vitesse == 2
        assert e1.gainExperience == 15
        
    def test_voleur(self: TestEnnemi):
        e1 = TypesEnnemi.Voleur.creerEnnemi()
        assert e1.nom == "Voleur"
        assert e1.pointDeVie == 6
        assert e1.attaque == 2
        assert e1.defense == 2
        assert e1.vitesse == 7
        assert e1.gainExperience == 20
        
    def test_sorciere(self: TestEnnemi):
        e1 = TypesEnnemi.Sorciere.creerEnnemi()
        assert e1.nom == "Sorciere"
        assert e1.pointDeVie == 4
        assert e1.attaque == 5
        assert e1.defense == 2
        assert e1.vitesse == 2
        assert e1.gainExperience == 20
        
    def test_araignee(self: TestEnnemi):
        e1 = TypesEnnemi.Araignee.creerEnnemi()
        assert e1.nom == "Araignee"
        assert e1.pointDeVie == 2
        assert e1.attaque == 3
        assert e1.defense == 1
        assert e1.vitesse == 5
        assert e1.gainExperience == 10
        
    def test_boss(self: TestEnnemi):
        e1 = TypesEnnemi.Boss_Squelette.creerEnnemi()
        assert e1.nom == "Boss_Squelette"
        assert e1.pointDeVie == 60
        assert e1.attaque == 10
        assert e1.defense == 6
        assert e1.vitesse == 8
        assert e1.gainExperience == 0
        
if __name__ == "__main__":
    pytest.main()