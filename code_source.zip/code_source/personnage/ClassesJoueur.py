from __future__ import annotations

import constant
from personnage.CapaciteSpeciale import CapaciteSpeciale
from personnage.Joueur import Joueur
from personnage.JoueurIA import JoueurIA


from enum import Enum


class ClassesJoueur(Enum):
    """Énumération des classes de joueur"""
    Chevalier = ("Chevalier", 15, 8, 5, 2, CapaciteSpeciale.Parade, constant.CHEMIN_CHEVALIER, constant.DIMENSION_CHEVALIER, constant.SCALING_CHEVALIER)
    Archer = ("Archer", 14, 6, 4, 7, CapaciteSpeciale.Fleche_neutralisante, constant.CHEMIN_ARCHER, constant.DIMENSION_ARCHER, constant.SCALING_ARCHER)
    Magicien = ("Magicien", 12, 10, 4, 5, CapaciteSpeciale.Enchantement, constant.CHEMIN_MAGICIEN, constant.DIMENSION_MAGICIEN, constant.SCALING_MAGICIEN)
    Chasseur = ("Chasseur", 14, 7, 5, 7, CapaciteSpeciale.Piege_a_ours, constant.CHEMIN_CHASSEUR, constant.DIMENSION_CHASSEUR, constant.SCALING_CHASSEUR)
    Farceur = ("Farceur", 10, 4, 3, 15, CapaciteSpeciale.Farce, constant.CHEMIN_FARCEUR, constant.DIMENSION_FARCEUR, constant.SCALING_FARCEUR)

    def creerJoueur(self: ClassesJoueur) -> Joueur:
        """Créer une instance de Joueur à partir d'une classe de joueur

        Returns:
            Joueur: L'instance de joueur créée
        """
        return Joueur(self.value[0], self.value[1], self.value[2], self.value[3], self.value[4], self.value[5], self.value[6], self.value[7], self.value[8])
    
    def creerJoueurIA(self: ClassesJoueur, value : int) -> Joueur:
        """Créer une instance de Joueur à partir d'une classe de joueur

        Returns:
            Joueur: L'instance de joueur créée
        """
        return JoueurIA(self.value[0], self.value[1], self.value[2], self.value[3], self.value[4], self.value[5], self.value[6], self.value[7], self.value[8],niveau_difficulte = value)