from __future__ import annotations
from cartes.Carte import Carte
from cartes.TypeCarte import TypeCarte

from cartes.TypeVar import TypeVar
import constant
from personnage.Personnage import Personnage
from personnage.CapaciteSpeciale import CapaciteSpeciale



from typing_extensions import override


class Joueur(Personnage):
    """Sous-classe de personnage permettant de modéliser un joueur"""
    # Liste statique contenant tous les joueurs
    allJoueur: list[Joueur] = []

    @staticmethod
    def getAllJoueur() -> list[Joueur]: return Joueur.allJoueur

    @staticmethod
    def setAllJoueur(allJoueur: list[Joueur]): Joueur.allJoueur = allJoueur

    # Constructeur
    def __init__(self: Joueur, nom: str, pointDeVie: int, attaque: int, defense: int, vitesse: int, capaciteSpeciale: CapaciteSpeciale, cheminSprite: str, dimension: tuple[int, int], scaling: float, niveau : int = 1):
        from cartes.ListeCartes import ListeCartes

        super().__init__(nom, pointDeVie, attaque, defense, vitesse, cheminSprite, dimension, scaling, niveau)
        self._pointExperience: int = 0
        self._pointExperienceMax: int = 60
        self._cartes: list[Carte] = []
        self._emplacement: int = 0
        Joueur.allJoueur.append(self)
        self._cartes.append(ListeCartes.Potion.genererCarte(None, len(Joueur.getAllJoueur())-1))
        self._cartes.append(ListeCartes.Teleportation.genererCarte(None, len(Joueur.getAllJoueur())-1))
        self._numero = len(Joueur.allJoueur) - 1
        self._capaciteSpeciale: CapaciteSpeciale = capaciteSpeciale
        self._capaciteDisponible: bool = True
        self._nbDeplacements: int = 0
        self._nbEnnemisVaincus: int = 0
        self._niveauEnnemisRencontres: int = 1
        self._argent: int = 10
        self.isIA: bool = False
        self.niveau_difficulte: int = 0

    # Getters et setters

    @override
    @Personnage.pointDeVie.setter
    def pointDeVie(self: Joueur, pointDeVie: int):
        self._pointDeVie = pointDeVie
        if self._pointDeVie > self._pointDeVieMax:
            self._pointDeVie = self._pointDeVieMax
        if self._pointDeVie <= 0:
            self._pointDeVie = 0
            # Utilise une potion si le joueur en a une
            for c in self._cartes:
                if c.nom == "Potion":
                    self.test2 = True
                    c.utiliser()
                    break

    @property
    def niveau(self: Joueur) -> int: return self._niveau

    @niveau.setter
    def niveau(self: Joueur, niveau: int):
        if niveau > Personnage.niveauMax:
            self._niveau = Personnage.niveauMax
        elif self._niveau < niveau:
            self._niveau = niveau
            self._pointDeVieMax += 2
            self._pointExperienceMax += 10
            self._attaque += 2
            self._defense += 2
            self._vitesse += 2
            if self._niveau == 5:
                # Si le joueur atteint le niveau 5, on retire les cartes de teleportation en sa possession
                self._cartes = list(filter(lambda x: x.nom != "Teleportation", self._cartes))
        else:
            raise ValueError("Le niveau ne peut pas être inférieur au niveau actuel")
        self._pointDeVie += self._pointDeVieMax // 2

    @property
    def pointExperience(self: Joueur) -> int: return self._pointExperience

    @pointExperience.setter
    def pointExperience(self: Joueur, pointExperience: int):
        self._pointExperience = pointExperience*3
        if self._pointExperience >= self._pointExperienceMax:
            self._pointExperience -= self._pointExperienceMax
            self.niveau += 1

    @property
    def pointExperienceMax(self: Joueur) -> int: return self._pointExperienceMax

    @pointExperienceMax.setter
    def pointExperienceMax(self: Joueur, pointExperienceMax: int): self._pointExperienceMax = pointExperienceMax

    @property
    def emplacement(self: Joueur) -> int: return self._emplacement

    @emplacement.setter
    def emplacement(self: Joueur, emplacement: int): self._emplacement = emplacement

    @property
    def cartes(self: Joueur) -> list: return self._cartes

    @cartes.setter
    def cartes(self: Joueur, cartes: list): self._cartes = cartes

    @property
    def numero(self: Joueur) -> int: return self._numero

    @numero.setter
    def numero(self: Joueur, numero: int): self._numero = numero

    @property
    def capaciteSpeciale(self: Joueur) -> CapaciteSpeciale: return self._capaciteSpeciale

    @capaciteSpeciale.setter
    def capaciteSpeciale(self: Joueur, capaciteSpeciale: CapaciteSpeciale): self._capaciteSpeciale = capaciteSpeciale

    @property
    def capaciteDisponible(self: Joueur) -> bool: return self._capaciteDisponible

    @capaciteDisponible.setter
    def capaciteDisponible(self: Joueur, capaciteDisponible: bool):
        self._capaciteDisponible = capaciteDisponible

    @property
    def nbDeplacements(self: Joueur) -> int: return self._nbDeplacements

    @nbDeplacements.setter
    def nbDeplacements(self: Joueur, nbDeplacements: int):
        self._nbDeplacements = nbDeplacements
        if self._nbDeplacements >= constant.TAILLE_PLATEAU:
            self._nbDeplacements = 0
            self._niveauEnnemisRencontres += 1
            self._capaciteDisponible = True

    @property
    def nbEnnemisVaincus(self: Joueur) -> int: return self._nbEnnemisVaincus

    @nbEnnemisVaincus.setter
    def nbEnnemisVaincus(self: Joueur, nbEnnemisVaincus: int):
        self._nbEnnemisVaincus = nbEnnemisVaincus
        if self._nbEnnemisVaincus >= 8:
            self._capaciteDisponible = True
            self._nbEnnemisVaincus = 0

    @property
    def niveauEnnemisRencontres(self: Joueur) -> int: return self._niveauEnnemisRencontres

    @niveauEnnemisRencontres.setter
    def niveauEnnemisRencontres(self: Joueur, niveauEnnemisRencontres: int):
        self._niveauEnnemisRencontres = niveauEnnemisRencontres
        if self._niveauEnnemisRencontres > 5:
            self._niveauEnnemisRencontres = 5
            
    @property
    def argent(self: Joueur) -> int: return self._argent
    
    @argent.setter
    def argent(self: Joueur, argent: int): self._argent = argent

    # Méthodes
    def nouvelleCarte(self: Joueur, c) -> bool:
        """
        Ajoute une nouvelle carte au joueur.

        Args:
            self (Joueur): Le joueur qui reçoit la carte.
            c (Carte): La carte à ajouter.

        Returns:
            bool: True si la carte a été ajoutée ou si le joueur a trop de cartes, False sinon.
        """
        import cartes.TypeVar as TypeVar

        # nbCartePlacable: int = 0
        # nbCarteCombat: int = 0
        # for cj in self._cartes:
        #     if cj.typeCarte in [TypeCarte.Case, TypeCarte.Plateau, TypeCarte.Utilisable, TypeCarte.Placable]:
        #         nbCartePlacable += 1
        #     if cj.typeCarte == TypeCarte.Consommable:
        #         nbCarteCombat += 1

        # Si le joueur n'a plus de place pour une carte, on ne lui en donne pas
        if len(self._cartes) == 10:
            return True

        if c.typeCarte in [TypeCarte.Case, TypeCarte.Plateau, TypeCarte.Utilisable, TypeCarte.Placable]:
            if self.nombreCartePlateau() < 5 and not (c.nom == "Teleportation" and self._niveau == 5):
                self._cartes.append(c)
                return True
        else:
            if self.nombreCarteCombat() < 5:
                self._cartes.append(c)
                return True

        return False

    def payer(self: Joueur, montant: int) -> bool:
        """
        Permet au joueur de payer un montant.

        Args:
            self (Joueur): Le joueur qui paie.
            montant (int): Le montant à payer.

        Returns:
            bool: True si le joueur a assez d'argent pour payer, False sinon.
        """
        if self._argent >= montant:
            self._argent -= montant
            return True
        return False
    
    def nombreCartePlateau(self: Joueur) -> int:
        """
        Retourne le nombre de cartes de type plateau que possède le joueur.

        Args:
            self (Joueur): Le joueur.

        Returns:
            int: Le nombre de cartes de type plateau.
        """
        return len(list(filter(lambda x: x.typeCarte in [TypeCarte.Plateau, TypeCarte.Case, TypeCarte.Utilisable, TypeCarte.Placable], self._cartes)))
    
    def nombreCarteCombat(self: Joueur) -> int:
        """
        Retourne le nombre de cartes utilisable ens combat que possède le joueur.

        Args:
            self (Joueur): Le joueur.

        Returns:
            int: Le nombre de cartes de type combat.
        """
        return len(list(filter(lambda x: x.typeCarte == TypeCarte.Consommable, self._cartes)))

    def __eq__(self, o: object) -> bool:
        if isinstance(o, Joueur):
            return self._numero == o._numero
        return False