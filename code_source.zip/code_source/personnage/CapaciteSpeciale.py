from __future__ import annotations

from __future__ import annotations
from enum import Enum


class CapaciteSpeciale(Enum):
    """Énumération des différentes capacités spéciales"""
    Parade = "Bloque une attaque\net inflige 2 fois l'ATQ\ndu joueur\n(Passe le tour)"
    Fleche_neutralisante = "Empêche l'ennemi\nde jouer et lui inflige\nles dégâts\nd'une attaque\n(Passe le tour)"
    Enchantement = "Rend 5 PV et\naugmente toutes les\nstats de 2"
    Piege_a_ours = "Stoppe le déplacement\nd'un joueur"
    Farce = "L'ennemi cible\ns'attaque lui-même\n(Passe le tour)"