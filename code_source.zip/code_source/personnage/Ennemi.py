from __future__ import annotations

from personnage.Personnage import Personnage


class Ennemi(Personnage):
    """Sous-classe de personnage représentant un ennemi"""
    def __init__(self: Ennemi, nom: str, pointDeVie: int, attaque: int, defense: int, vitesse: int, gainExperience: int, cheminSprite: str, dimension: tuple[int, int], scaling: float, niveau : int = 1, gainArgent: int = 0):
        super().__init__(nom, pointDeVie, attaque, defense, vitesse, cheminSprite, dimension, scaling, niveau)
        self._gainExperience: int = gainExperience #+ ((niveau-1)*5)
        self._gainArgent: int = gainArgent

    # Méthodes
    @property
    def niveau(self: Ennemi) -> int: return self._niveau

    @niveau.setter
    def niveau(self: Ennemi, niveau: int):
        self._pointDeVieMax += 2*(niveau-1)
        self._pointDeVie = self._pointDeVieMax
        self._attaque += 2*(niveau-1)
        self._defense += 1*(niveau-1)
        self._vitesse += 1*(niveau-1)

    @property
    def gainExperience(self: Ennemi) -> int: return self._gainExperience

    @gainExperience.setter
    def gainExperience(self: Ennemi, gainExperience: int): self._gainExperience = gainExperience
    
    @property
    def gainArgent(self: Ennemi) -> int: return self._gainArgent
    
    @gainArgent.setter
    def gainArgent(self: Ennemi, gainArgent: int): self._gainArgent = gainArgent

    def __eq__(self, __value: object) -> bool:
        if isinstance(__value, Ennemi):
            return self._nom == __value._nom and self._pointDeVie == __value._pointDeVie and self._attaque == __value._attaque and self._defense == __value._defense and self._vitesse == __value._vitesse and self._gainExperience == __value._gainExperience and self._cheminSprite == __value._cheminSprite and self._niveau == __value._niveau
        return False