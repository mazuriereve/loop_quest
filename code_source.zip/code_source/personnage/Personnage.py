# Luc DELAGE
# TD1-TPA
# SAE S3C1

# importations
from __future__ import annotations

from abc import ABC, abstractmethod
from typing_extensions import override
from enum import Enum
import cartes.Carte as Carte
import cartes.TypeCarte as TypeCarte
import constant
import pygame

class Personnage(ABC):
    """Classe abstraite modélisant un personnage"""
    
    # Attributs statiques
    niveauMax : int = 5
    
    # Constructeur
    def __init__(self: Personnage, nom: str, pointDeVie: int, attaque: int, defense: int, vitesse: int, cheminSprite: str, dimension: tuple[int, int], scaling: float, niveau : int = 1):
        
        super().__init__()
        self._nom: str = nom
        self._nomClasse: str = nom
        self._pointDeVie: int = pointDeVie + ((niveau-1)*2)
        self._pointDeVieMax: int = pointDeVie + ((niveau-1)*2)
        self._attaque: int = attaque + ((niveau-1)*2)
        self._defense: int = defense + ((niveau-1)*2)
        self._vitesse: int = vitesse + ((niveau-1)*2)
        self._niveau: int = niveau
        self._cheminSprite: str = cheminSprite
        self._sprite: int = 0
        self._delaiSprite: int = 5
        self._dimension: tuple[int, int] = dimension
        self._scaling: float = scaling
        
    # Getters et setters
    @property
    def nom(self: Personnage) -> str: return self._nom
    
    @nom.setter
    def nom(self: Personnage, nom: str): self._nom = nom
    
    @property
    def nomClasse(self: Personnage) -> str: return self._nomClasse
    
    @nomClasse.setter
    def nomClasse(self: Personnage, nomClasse: str): self._nomClasse = nomClasse
    
    @property
    def pointDeVie(self: Personnage) -> int: return self._pointDeVie
    
    @pointDeVie.setter
    def pointDeVie(self: Personnage, pointDeVie: int):
        self._pointDeVie = pointDeVie
        if self._pointDeVie > self._pointDeVieMax:
            self._pointDeVie = self._pointDeVieMax
    
    @property
    def pointDeVieMax(self: Personnage) -> int: return self._pointDeVieMax
    
    @pointDeVieMax.setter
    def pointDeVieMax(self: Personnage, pointDeVieMax: int): self._pointDeVieMax = pointDeVieMax
    
    @property
    def attaque(self: Personnage) -> int: return self._attaque
    
    @attaque.setter
    def attaque(self: Personnage, attaque: int): self._attaque = attaque
    
    @property
    def defense(self: Personnage) -> int: return self._defense
    
    @defense.setter
    def defense(self: Personnage, defense: int): self._defense = defense
    
    @property
    def vitesse(self: Personnage) -> int: return self._vitesse
    
    @vitesse.setter
    def vitesse(self: Personnage, vitesse: int): self._vitesse = vitesse
    
    @property
    def niveau(self: Personnage) -> int: return self._niveau
    
    @niveau.setter
    def niveau(self: Personnage, niveau: int):
        if niveau > Personnage.niveauMax:
            self._niveau = Personnage.niveauMax
        elif self._niveau < niveau:
            self._niveau = niveau
            self._pointDeVieMax += 2
            self._attaque += 2
            self._defense += 2
            self._vitesse += 2
        else:
            raise ValueError("Le niveau ne peut pas être inférieur au niveau actuel")
        self._pointDeVie += self._pointDeVieMax // 2
    
    @property
    def cheminSprite(self: Personnage) -> str: return self._cheminSprite
    
    @cheminSprite.setter
    def cheminSprite(self: Personnage, cheminSprite: str): self._cheminSprite = cheminSprite
    
    @property
    def dimension(self: Personnage) -> tuple[int, int]: return self._dimension
    
    @dimension.setter
    def dimension(self: Personnage, dimension: tuple[int, int]): self._dimension = dimension
    
    @property
    def scaling(self: Personnage) -> float: return self._scaling
    
    @scaling.setter
    def scaling(self: Personnage, scaling: float): self._scaling = scaling
   
    # Méthodes
    def est_mort(self: Personnage) -> bool:
        """Indique si le personnage est mort

        Returns:
         - bool: True si le personnage est mort, False sinon
        """
        if self._pointDeVie <= 0:
            return True
        else:
            return False
        
    def recupererSprite(self: Personnage, animation: str = None) -> pygame.Surface:
        """Récupère le sprite du personnage pour son animation de base

        Returns:
         - pygame.Surface: Le sprite du personnage
        """
        spriteSheet: pygame.Surface = pygame.image.load(self._cheminSprite)
        self._delaiSprite -= 1
        if self._delaiSprite <= 0:
            self._delaiSprite = 5
            self._sprite += 1
            if self._sprite >= spriteSheet.get_width() // self._dimension[0]:
                self._sprite = 0
        return spriteSheet.subsurface(self._sprite*self._dimension[0], 0, self._dimension[0], self._dimension[1])
        
    def animation(self: Personnage, nomAnimation: str, ecran: pygame.Surface, position: tuple[int, int], retourne: bool = False, inverse: bool = False):
        """Permet de lancer l'animation d'un personnage (si elle existe) et de l'afficher à l'écran

        Args:
         - nomAnimation (str): Le nom de l'animation à lancer
         - ecran (pygame.Surface): L'écran sur lequel afficher l'animation
         - position (tuple[int, int]): La position à laquelle afficher l'animation
         - retourne (bool, optional): Indique s'il faut retourner le sprite sur l'axe vertical. Defaults to False.
         - inverse (bool, optional): Indique si l'animation doit être inversée. Defaults to False.
        """
        try:
            spriteSheet: pygame.Surface = pygame.image.load(fr"{constant.REPERTOIRE_COURANT}/ressources/sprites/{self._nomClasse}_{nomAnimation}.png")
            surface = pygame.Surface((self._dimension[0]*self._scaling, self._dimension[1]*self._scaling))
            iterations = range(spriteSheet.get_width()//self._dimension[0])
            if inverse:
                iterations = reversed(iterations)
            for i in iterations:        
                self._delaiSprite = 5
                while self._delaiSprite > 0:
                    self._delaiSprite -= 1
                surface.fill((0, 0, 0))
                sprite = pygame.transform.scale_by(spriteSheet.subsurface((i*self._dimension[0], 0, self._dimension[0], self._dimension[1])), self._scaling)
                if retourne:
                    sprite = pygame.transform.flip(sprite, True, False)
                surface.blit(sprite, (0, 0))
                ecran.blit(surface, (400+position[0]-surface.get_width()/2, position[1]))
                pygame.display.flip()
                pygame.time.wait(100)
            self._delaiSprite = 5
            # surface.fill((0, 0, 0))
            # surface.blit(pygame.transform.scale_by(pygame.image.load(self._cheminSprite).subsurface((0, 0, self._dimension[0], self._dimension[1])), self._scaling), (0, 0))
            ecran.blit(surface, (400+position[0]-surface.get_width()/2, position[1]))
        except:
            # Affiche la raison de l'erreur dans le terminal sans arrêter le programme
            import traceback
            traceback.print_exc()
            pass

class CapaciteSpeciale(Enum):
    """Énumération des différentes capacités spéciales"""
    Parade = "Bloque une attaque\net inflige 2 fois l'ATQ\ndu joueur\n(Passe le tour)"
    Fleche_neutralisante = "Empêche l'ennemi\nde jouer et lui inflige\nles dégâts\nd'une attaque\n(Passe le tour)"
    Enchantement = "Rend 5 PV et\naugmente toutes les\nstats de 2"
    Piege_a_ours = "Stoppe le déplacement\nd'un joueur"
    Farce = "L'ennemi cible\ns'attaque lui-même\n(Passe le tour)"
        
class Joueur(Personnage):
    """Sous-classe de personnage permettant de modéliser un joueur"""
    # Liste statique contenant tous les joueurs
    allJoueur: list[Joueur] = []
    
    @staticmethod
    def getAllJoueur() -> list[Joueur]: return Joueur.allJoueur
    
    @staticmethod
    def setAllJoueur(allJoueur: list[Joueur]): Joueur.allJoueur = allJoueur
    
    # Constructeur
    def __init__(self: Joueur, nom: str, pointDeVie: int, attaque: int, defense: int, vitesse: int, capaciteSpeciale: CapaciteSpeciale, cheminSprite: str, dimension: tuple[int, int], scaling: float, niveau : int = 1):
        import cartes.ListeCartes as ListeCartes
        
        super().__init__(nom, pointDeVie, attaque, defense, vitesse, cheminSprite, dimension, scaling, niveau)
        self._pointExperience: int = 0
        self._pointExperienceMax: int = 60
        self._cartes: list[Carte.Carte] = []
        self._emplacement: int = 0
        Joueur.allJoueur.append(self)
        self._cartes.append(ListeCartes.ListeCartes.Potion.genererCarte(None, len(Joueur.getAllJoueur())-1))
        self._cartes.append(ListeCartes.ListeCartes.Teleportation.genererCarte(None, len(Joueur.getAllJoueur())-1))
        self._numero = len(Joueur.allJoueur) - 1
        self._capaciteSpeciale: CapaciteSpeciale = capaciteSpeciale
        self._capaciteDisponible: bool = True
        self._nbDeplacements: int = 0
        self._nbEnnemisVaincus: int = 0
        self._niveauEnnemisRencontres: int = 1
    
    # Getters et setters
    
    @override
    @Personnage.pointDeVie.setter
    def pointDeVie(self: Joueur, pointDeVie: int):
        self._pointDeVie = pointDeVie
        if self._pointDeVie > self._pointDeVieMax:
            self._pointDeVie = self._pointDeVieMax
        if self._pointDeVie <= 0:
            self._pointDeVie = 0
            # Utilise une potion si le joueur en a une
            for c in self._cartes:
                if c.nom == "Potion":
                    self.test2 = True
                    c.utiliser()
                    break
    
    @property
    def niveau(self: Joueur) -> int: return self._niveau
    
    @niveau.setter
    def niveau(self: Joueur, niveau: int):
        if niveau > Personnage.niveauMax:
            self._niveau = Personnage.niveauMax
        elif self._niveau < niveau:
            self._niveau = niveau
            self._pointDeVieMax += 2
            self._pointExperienceMax += 10
            self._attaque += 2
            self._defense += 2
            self._vitesse += 2
            if self._niveau == 5:
                # Si le joueur atteint le niveau 5, on retire les cartes de teleportation en sa possession
                self._cartes = list(filter(lambda x: x.nom != "Teleportation", self._cartes))
        else:
            raise ValueError("Le niveau ne peut pas être inférieur au niveau actuel")
        self._pointDeVie += self._pointDeVieMax // 2
    
    @property
    def pointExperience(self: Joueur) -> int: return self._pointExperience
    
    @pointExperience.setter
    def pointExperience(self: Joueur, pointExperience: int):
        self._pointExperience = pointExperience
        if self._pointExperience >= self._pointExperienceMax:
            self._pointExperience -= self._pointExperienceMax
            self.niveau += 1
            
    @property
    def pointExperienceMax(self: Joueur) -> int: return self._pointExperienceMax
    
    @pointExperienceMax.setter
    def pointExperienceMax(self: Joueur, pointExperienceMax: int): self._pointExperienceMax = pointExperienceMax
    
    @property
    def emplacement(self: Joueur) -> int: return self._emplacement
    
    @emplacement.setter
    def emplacement(self: Joueur, emplacement: int): self._emplacement = emplacement
    
    @property
    def cartes(self: Joueur) -> list: return self._cartes
    
    @cartes.setter
    def cartes(self: Joueur, cartes: list): self._cartes = cartes
    
    @property
    def numero(self: Joueur) -> int: return self._numero
    
    @numero.setter
    def numero(self: Joueur, numero: int): self._numero = numero
    
    @property
    def capaciteSpeciale(self: Joueur) -> CapaciteSpeciale: return self._capaciteSpeciale
    
    @capaciteSpeciale.setter
    def capaciteSpeciale(self: Joueur, capaciteSpeciale: CapaciteSpeciale): self._capaciteSpeciale = capaciteSpeciale
    
    @property
    def capaciteDisponible(self: Joueur) -> bool: return self._capaciteDisponible
    
    @capaciteDisponible.setter
    def capaciteDisponible(self: Joueur, capaciteDisponible: bool):
        self._capaciteDisponible = capaciteDisponible
    
    @property
    def nbDeplacements(self: Joueur) -> int: return self._nbDeplacements
    
    @nbDeplacements.setter
    def nbDeplacements(self: Joueur, nbDeplacements: int):
        self._nbDeplacements = nbDeplacements
        if self._nbDeplacements >= constant.TAILLE_PLATEAU:
            self._nbDeplacements = 0
            self._niveauEnnemisRencontres += 1
            self._capaciteDisponible = True
            
    @property
    def nbEnnemisVaincus(self: Joueur) -> int: return self._nbEnnemisVaincus
    
    @nbEnnemisVaincus.setter
    def nbEnnemisVaincus(self: Joueur, nbEnnemisVaincus: int):
        self._nbEnnemisVaincus = nbEnnemisVaincus
        if self._nbEnnemisVaincus >= 8:
            self._capaciteDisponible = True
            self._nbEnnemisVaincus = 0
    
    @property
    def niveauEnnemisRencontres(self: Joueur) -> int: return self._niveauEnnemisRencontres
    
    @niveauEnnemisRencontres.setter
    def niveauEnnemisRencontres(self: Joueur, niveauEnnemisRencontres: int):
        self._niveauEnnemisRencontres = niveauEnnemisRencontres
        if self._niveauEnnemisRencontres > 5:
            self._niveauEnnemisRencontres = 5
    
    # Méthodes
    def nouvelleCarte(self: Joueur, c) -> bool:
        """
        Ajoute une nouvelle carte au joueur.

        Args:
            self (Joueur): Le joueur qui reçoit la carte.
            c (Carte): La carte à ajouter.

        Returns:
            bool: True si la carte a été ajoutée ou si le joueur a trop de cartes, False sinon.
        """
        import cartes.TypeVar as TypeVar
        
        nbCartePlacable: int = 0
        nbCarteCombat: int = 0
        for cj in self._cartes:
            if cj.typeCarte in [TypeCarte.TypeCarte.Case, TypeCarte.TypeCarte.Plateau, TypeCarte.TypeCarte.Utilisable, TypeCarte.TypeCarte.Placable]:
                nbCartePlacable += 1
            if cj.typeCarte == TypeCarte.TypeCarte.Consommable:
                nbCarteCombat += 1
        
        # Si le joueur n'a plus de place pour une carte, on ne lui en donne pas
        if nbCarteCombat+nbCartePlacable == 10:
            return True
        
        if c.typeCarte in [TypeCarte.TypeCarte.Case, TypeCarte.TypeCarte.Plateau, TypeCarte.TypeCarte.Utilisable, TypeCarte.TypeCarte.Placable]:
            if nbCartePlacable < 5 and not (c.nom == "Teleportation" and self._niveau == 5):
                self._cartes.append(c)
                return True
        else:
            if nbCarteCombat < 5:
                self._cartes.append(c)
                return True
        
        return False
        
        
    def __eq__(self, o: object) -> bool:
        if isinstance(o, Joueur):
            return self._numero == o._numero
        return False
    
class ClassesJoueur(Enum):
    """Énumération des classes de joueur"""
    Chevalier = ("Chevalier", 15, 8, 5, 2, CapaciteSpeciale.Parade, constant.CHEMIN_CHEVALIER, constant.DIMENSION_CHEVALIER, constant.SCALING_CHEVALIER)
    Archer = ("Archer", 14, 6, 4, 7, CapaciteSpeciale.Fleche_neutralisante, constant.CHEMIN_ARCHER, constant.DIMENSION_ARCHER, constant.SCALING_ARCHER)
    Magicien = ("Magicien", 12, 10, 4, 5, CapaciteSpeciale.Enchantement, constant.CHEMIN_MAGICIEN, constant.DIMENSION_MAGICIEN, constant.SCALING_MAGICIEN)
    Chasseur = ("Chasseur", 14, 7, 5, 7, CapaciteSpeciale.Piege_a_ours, constant.CHEMIN_CHASSEUR, constant.DIMENSION_CHASSEUR, constant.SCALING_CHASSEUR)
    Farceur = ("Farceur", 10, 4, 3, 15, CapaciteSpeciale.Farce, constant.CHEMIN_FARCEUR, constant.DIMENSION_FARCEUR, constant.SCALING_FARCEUR)
    
    def creerJoueur(self: ClassesJoueur) -> Joueur:
        """Créer une instance de Joueur à partir d'une classe de joueur

        Returns:
            Joueur: L'instance de joueur créée
        """
        return Joueur(self.value[0], self.value[1], self.value[2], self.value[3], self.value[4], self.value[5], self.value[6], self.value[7], self.value[8])
    
class Ennemi(Personnage):
    """Sous-classe de personnage représentant un ennemi"""
    def __init__(self: Ennemi, nom: str, pointDeVie: int, attaque: int, defense: int, vitesse: int, gainExperience: int, cheminSprite: str, dimension: tuple[int, int], scaling: float, niveau : int = 1):
        super().__init__(nom, pointDeVie, attaque, defense, vitesse, cheminSprite, dimension, scaling, niveau)
        self._gainExperience: int = gainExperience #+ ((niveau-1)*5)
        
    # Méthodes
    @property
    def niveau(self: Ennemi) -> int: return self._niveau
    
    @niveau.setter
    def niveau(self: Ennemi, niveau: int):
        self._pointDeVieMax += 2*(niveau-1)
        self._pointDeVie = self._pointDeVieMax
        self._attaque += 2*(niveau-1)
        self._defense += 1*(niveau-1)
        self._vitesse += 1*(niveau-1)
    
    @property
    def gainExperience(self: Ennemi) -> int: return self._gainExperience
    
    @gainExperience.setter
    def gainExperience(self: Ennemi, gainExperience: int): self._gainExperience = gainExperience
    
    def __eq__(self, __value: object) -> bool:
        if isinstance(__value, Ennemi):
            return self._nom == __value._nom and self._pointDeVie == __value._pointDeVie and self._attaque == __value._attaque and self._defense == __value._defense and self._vitesse == __value._vitesse and self._gainExperience == __value._gainExperience and self._capaciteSpeciale == __value._capaciteSpeciale and self._cheminSprite == __value._cheminSprite and self._niveau == __value._niveau
        return False

class TypesEnnemi(Enum):
    """Énumération des différents types d'ennemis"""
    Zombie = ("Zombie", 4, 3, 1, 1, 10, constant.CHEMIN_ZOMBIE, constant.DIMENSION_ZOMBIE, constant.SCALING_ZOMBIE)
    Voleur = ("Voleur", 6, 2, 2, 7, 20, constant.CHEMIN_VOLEUR, constant.DIMENSION_VOLEUR, constant.SCALING_VOLEUR)
    Sorciere = ("Sorciere", 4, 5, 2, 2, 20, constant.CHEMIN_SORCIERE, constant.DIMENSION_SORCIERE, constant.SCALING_SORCIERE)
    Squelette = ("Squelette", 5, 4, 3, 2, 15, constant.CHEMIN_SQUELETTE, constant.DIMENSION_SQUELETTE, constant.SCALING_SQUELETTE)
    Araignee = ("Araignee", 2, 3, 1, 5, 10, constant.CHEMIN_ARAIGNEE, constant.DIMENSION_ARAIGNEE, constant.SCALING_ARAIGNEE)
    Boss_Squelette = ("Boss_Squelette", 60, 10, 6, 8, 0, constant.CHEMIN_BOSS, constant.DIMENSION_BOSS, constant.SCALING_BOSS)
    
    def creerEnnemi(self: TypesEnnemi, niveau: int = 1) -> Ennemi:
        """Créer une instance d'ennemi à partir d'un type d'ennemi

        Returns:
            Ennemi: L'instance d'ennemi créée
        """
        return Ennemi(self.value[0], self.value[1], self.value[2], self.value[3], self.value[4], self.value[5], self.value[6], self.value[7], self.value[8], niveau)