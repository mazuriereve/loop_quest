from __future__ import annotations

import constant
from personnage.Ennemi import Ennemi


from enum import Enum


class TypesEnnemi(Enum):
    """Énumération des différents types d'ennemis"""
    Zombie = ("Zombie", 4, 3, 1, 1, 10, constant.CHEMIN_ZOMBIE, constant.DIMENSION_ZOMBIE, constant.SCALING_ZOMBIE, 2)
    Voleur = ("Voleur", 6, 2, 2, 7, 20, constant.CHEMIN_VOLEUR, constant.DIMENSION_VOLEUR, constant.SCALING_VOLEUR, 2)
    Sorciere = ("Sorciere", 4, 5, 2, 2, 20, constant.CHEMIN_SORCIERE, constant.DIMENSION_SORCIERE, constant.SCALING_SORCIERE, 5)
    Squelette = ("Squelette", 5, 4, 3, 2, 15, constant.CHEMIN_SQUELETTE, constant.DIMENSION_SQUELETTE, constant.SCALING_SQUELETTE, 7)
    Araignee = ("Araignee", 2, 3, 1, 5, 10, constant.CHEMIN_ARAIGNEE, constant.DIMENSION_ARAIGNEE, constant.SCALING_ARAIGNEE, 1)
    Boss_Squelette = ("Boss_Squelette", 60, 10, 6, 8, 0, constant.CHEMIN_BOSS, constant.DIMENSION_BOSS, constant.SCALING_BOSS, 0)

    def creerEnnemi(self: TypesEnnemi, niveau: int = 1) -> Ennemi:
        """Créer une instance d'ennemi à partir d'un type d'ennemi

        Returns:
            Ennemi: L'instance d'ennemi créée
        """
        return Ennemi(self.value[0], self.value[1], self.value[2], self.value[3], self.value[4], self.value[5], self.value[6], self.value[7], self.value[8], niveau, self.value[9])