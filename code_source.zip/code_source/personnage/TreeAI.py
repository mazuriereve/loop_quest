from __future__ import annotations
from personnage.CapaciteSpeciale import CapaciteSpeciale
from personnage.Joueur import Joueur
from personnage.Ennemi import Ennemi
import copy
from random import randint



import itertools

class CombatNode:
    def __init__(self, joueur: Joueur, ennemis: list[Ennemi], ennemi_actions, action=None, index_attaque=None):
        self.joueur = joueur
        self.ennemis = ennemis
        self.ennemi_actions = ennemi_actions
        self.children = []
        self.action = action
        self.index_attaque = index_attaque

    def generate_combat_tree(self, depth: int, parent_action=None, index_attaque=None) -> CombatNode:
        if depth == 0 or self.joueur.pointDeVie <= 0 or not self.ennemis:
            return
        joueur_actions = ["attaque", "critique"]
        if self.joueur.capaciteDisponible:
            joueur_actions.append("capaciteSpeciale")
        
        # Générer toutes les combinaisons d'actions possibles
        potion_actions = []
        for t in self.joueur.cartes:
            if t.nom == "Potion":
                potion_actions.append("Potion")
            # elif t.nom == "Fiole_ATQ":
            #     potion_actions.append("Fiole ATQ")
        action_combinations = []
        for r in range(1, 4):
            action_combinations.extend(itertools.product(joueur_actions + potion_actions, repeat=r))

        # Filtrer les combinaisons valides
        two_potions_combinations = list(itertools.permutations(potion_actions, 2))
        action_combinations.extend(two_potions_combinations)
        action_combinations = [combo for combo in action_combinations if (combo.count("Potion") <= 2 and combo.count("Fiole ATQ") <= 2) and len(combo) <= 3 and ((combo[0] == "Potion" or combo[0] == "Fiole ATQ") if len(combo) < 3 else (combo[:2] == ("Potion", "Potion") or combo[:2] == ("Fiole ATQ", "Fiole ATQ") or combo[:2] in two_potions_combinations)) and (combo[-1] != "Potion" and combo[-1] != "Fiole ATQ")]

        joueur_actions = action_combinations
        joueur_actions.append(('attaque'))
        joueur_actions.append(('critique'))
        joueur_actions.append(('capaciteSpeciale'))
        for joueur_action in joueur_actions:
            for i, ennemi_action in enumerate(self.ennemi_actions):
                new_joueur = copy.deepcopy(self.joueur)
                new_ennemis = [copy.deepcopy(ennemi) for ennemi in self.ennemis]

                joueur_hp_before_action = new_joueur.pointDeVie
                for j, ennemi in enumerate(new_ennemis):
                    ennemi_hp_before_action = ennemi.pointDeVie
                    u, o = self.simulate_joueur_action(new_joueur, ennemi, joueur_action, j)
                    new_joueur.pointDeVie = u
                    ennemi.pointDeVie = o
                    v, x = self.simulate_ennemi_action(new_joueur, ennemi, ennemi_action)
                    new_joueur.pointDeVie = v
                    ennemi.pointDeVie = x
                    new_node = CombatNode(new_joueur, new_ennemis, self.ennemi_actions, action=joueur_action, index_attaque=index_attaque if index_attaque is not None else j)
                    self.children.append(new_node)
                    new_ennemis[j].pointDeVie = ennemi.pointDeVie
                    new_joueur.pointDeVie = new_joueur.pointDeVie

                new_node.generate_combat_tree(depth - 1, joueur_action, index_attaque=index_attaque if index_attaque is not None else j)

        return self

    def simulate_joueur_action(self, joueur: Joueur, ennemi: Ennemi, actions, index):
        
        for action in actions:

            if action == "attaque" or action == "critique":
                degat_joueur = 0
                if action == "attaque":
                    degat_joueur = randint(min(int(joueur.attaque * 1.1), joueur.attaque), max(int(joueur.attaque * 1.1), joueur.attaque)) - ennemi.defense
                elif action == "critique":
                    degat_joueur = joueur.attaque * 2 - (ennemi.defense // 2)

                if action == "attaque" or (action == "critique" and randint(0, 100) < joueur.vitesse * 3 - ennemi.vitesse):
                    if ennemi.pointDeVie - degat_joueur <= 0:
                        ennemi.pointDeVie = 0
                    else:
                        ennemi.pointDeVie -= degat_joueur
            elif action == "Potion":
                joueur.pointDeVie += 5
                for v in range(0,len(self.joueur.cartes)):
                    if self.joueur.cartes[v].nom == "Potion":
                        self.joueur.cartes.pop(v)
                        break
            elif action == "capaciteSpeciale":
                if self.capacitejoueur() == "Fleche neutralisante":
                    degat_joueur = randint(int(joueur.attaque * 0.75), joueur.attaque)
                    if ennemi.pointDeVie - degat_joueur <= 0:
                        ennemi.pointDeVie = 0
                    else:
                        ennemi.pointDeVie -= degat_joueur
                elif self.capacitejoueur() == "Farce":
                    degat_joueur = randint(int(ennemi.attaque * 0.75), ennemi.attaque)
                    if ennemi.pointDeVie - degat_joueur <= 0:
                        ennemi.pointDeVie = 0
                    else:
                        ennemi.pointDeVie -= degat_joueur

                elif self.capacitejoueur() == "Parade":
                    if ennemi.pointDeVie - 5 <= 0:
                        ennemi.pointDeVie = 0
                    else:
                        ennemi.pointDeVie -= 5

                if self.ennemis[index].est_mort():
                    pass
                else:
                    pass
        return joueur.pointDeVie, ennemi.pointDeVie

    def simulate_ennemi_action(self, joueur, ennemi, action):
        if action == "attaque":
            degat_ennemi = ennemi.attaque * 1.5 - joueur.defense
            if joueur.pointDeVie - degat_ennemi <= 0:
                    joueur.pointDeVie = 0
            else : joueur.pointDeVie -= degat_ennemi
        return joueur.pointDeVie, ennemi.pointDeVie

    def score(self):
        cartes = 0
        for u in range(0,len(self.joueur.cartes)):
            cartes += 0
        return self.joueur.pointDeVie * len(self.ennemis) - sum(ennemi.pointDeVie for ennemi in self.ennemis)

    # def alpha_beta_search(self, depth, alpha, beta, maximizing_player):
    #     if depth == 0 or not self.children:
    #         if not self.children:
    #             return [(self.score(), self.joueur.pointDeVie, sum(ennemi.pointDeVie for ennemi in self.ennemis))]
    #         else:
    #             return None

    #     best_route = None
    #     best_score = float('-inf') if maximizing_player else float('inf')
    #     best_joueur_hp = 0

    #     for child in self.children:
    #         route = child.alpha_beta_search(depth - 1, alpha, beta, not maximizing_player)
    #         if route is None:
    #             continue
    #         score, joueur_hp, _ = route[0]

    #         if (maximizing_player and score > best_score) or (not maximizing_player and score < best_score):
    #             best_score = score
    #             best_route = route
    #             best_joueur_hp = joueur_hp
    #         elif score == best_score and joueur_hp > best_joueur_hp:
    #             best_route = route
    #             best_joueur_hp = joueur_hp

    #         if maximizing_player:
    #             alpha = max(alpha, score)
    #         else:
    #             beta = min(beta, score)

    #         if beta <= alpha:
    #             break

    #     return [(self.score(), self.joueur.pointDeVie, sum(ennemi.pointDeVie for ennemi in self.ennemis))] + best_route if best_route else None
  
    def alpha_beta(self, depth, alpha, beta, maximizing_player):
        if depth == 0 or not self.children:
            if not self.children:
                return self.score(), self.joueur.pointDeVie, [ennemi.pointDeVie for ennemi in self.ennemis]
            else:
                return None

        if maximizing_player:
            value = float('-inf')
            for child in self.children:
                alpha_beta_val = child.alpha_beta(depth - 1, alpha, beta, False)
                if alpha_beta_val is not None:
                    value = max(value, alpha_beta_val[0])
                    alpha = max(alpha, value)
                    if alpha >= beta:
                        break
                    
            return value, self.joueur.pointDeVie, [ennemi.pointDeVie for ennemi in self.ennemis]
        else:
            value = float('inf')
            for child in self.children:
                alpha_beta_val = child.alpha_beta(depth - 1, alpha, beta, True)
                if alpha_beta_val is not None:
                    value = min(value, alpha_beta_val[0])
                    beta = min(beta, value)
                    if beta <= alpha:
                        break

            return value, self.joueur.pointDeVie, [ennemi.pointDeVie for ennemi in self.ennemis]

    def best_move(self, depth):
        if depth == 0 or not self.children:
            return self.action, self.joueur.pointDeVie, [ennemi.pointDeVie for ennemi in self.ennemis], self.index_attaque

        best_score = float('-inf')
        best_move_info = None
        for child in self.children:
            action, joueur_hp, ennemi_hp, index_attaque = child.best_move(depth - 1)
            score = child.score()

            if score > best_score:
                best_score = score
                if isinstance(action , str):
                    action = (action,)
                best_move_info = (action, joueur_hp, ennemi_hp, index_attaque)

        return best_move_info



    def capacitejoueur(self):
        if self.joueur.capaciteSpeciale == CapaciteSpeciale.Parade:
            return "Parade"
        elif self.joueur.capaciteSpeciale == CapaciteSpeciale.Fleche_neutralisante:
            return "Fleche neutralisante"
        elif self.joueur.capaciteSpeciale == CapaciteSpeciale.Farce:
            return "Farce"
        elif self.joueur.capaciteSpeciale == CapaciteSpeciale.Enchantement:
            return "Enchantement"


#chevalier = ClassesJoueur.Chevalier.creerJoueur()
#zombie = TypesEnnemi.Zombie.creerEnnemi()
#root = CombatNode(chevalier, [zombie],  ["attaque"])
#chevalier.cartes.append(ListeCartes.Potion.genererCarte(None, len(Joueur.getAllJoueur())-1))
#chevalier.cartes.append(ListeCartes.Fiole_ATQ.genererCarte(None, len(Joueur.getAllJoueur())-1))
#full_tree = root.generate_combat_tree(3)
def print_tree(node: CombatNode, indent: int = 0):
    print("  " * indent + f"Joueur HP: {node.joueur.pointDeVie}")
    for i, ennemi in enumerate(node.ennemis):
        print("  " * (indent + 1) + f"Ennemi {i + 1} HP: {ennemi.pointDeVie}")
    for child in node.children:
        print_tree(child, indent + 1)
# print(zombie.pointDeVie)
# print(randint(min(int(chevalier.attaque * 1.5), chevalier.attaque), max(int(chevalier.attaque * 1.5), chevalier.attaque)) - zombie.defense)
#route = root.alpha_beta_search(2, float('-inf'), float('inf'), True)

#print_tree(full_tree)

# for score, joueur_hp, ennemi_hp in route:
#     print(f"Score: {score}, Joueur HP: {joueur_hp}, Ennemi HP: {ennemi_hp}")
    
#best_move_info = root.best_move(2)
# if best_move_info is not None:
#     action, joueur_hp, ennemi_hp = best_move_info
#     print("Best Move:", action, "| Joueur HP:", joueur_hp, "| Ennemi HP:", ennemi_hp)
# else:
#     print("No valid move found.")


#print("Best Move:", root.best_move(2))
#root = CombatNode(chevalier, [zombie],  ["attaque"])
#print("Best Move:", full_tree.best_move(1))
#print("Best Move:", root.best_move(2))