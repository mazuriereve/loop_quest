from __future__ import annotations
from typing_extensions import override

from personnage.Personnage import Personnage
from personnage.CapaciteSpeciale import CapaciteSpeciale
from personnage.Joueur import Joueur
from case.Case import Case
from personnage.Ennemi import Ennemi
import random

from personnage.TreeAI import CombatNode

class JoueurIA(Joueur):
    def __init__(self, nom: str, pointDeVie: int, attaque: int, defense: int, vitesse: int, capaciteSpeciale: CapaciteSpeciale, cheminSprite: str, dimension: tuple[int, int], scaling: float, niveau: int = 1, niveau_difficulte: int = 1):
        super().__init__(nom, pointDeVie, attaque, defense, vitesse, capaciteSpeciale, cheminSprite, dimension, scaling, niveau)
        self.isIA: bool = True
        self.niveau_difficulte = niveau_difficulte

    def choisircible(self, case : Case):
        if self.niveau_difficulte == 1:
            return self.choisircible1(case)
        elif self.niveau_difficulte == 2:
            return self.choisircible2(case)
    
    def jouer_aleatoire(self, max: int):
        if self.niveau_difficulte == 1:
            return self.jouer_aleatoire1(max)
        elif self.niveau_difficulte >=2 :
            return self.jouer_aleatoire2(max)
        
        
    def choosecardIA(self, max: int):
        if max < 0:
            return -1
        elif max == 0:
            return 0
        return random.randint(0,max)
    
    def choosefightIA(self, cartejouee : bool, ennemi : Ennemi):
        if self.niveau_difficulte == 1:
            return self.choosefightIA1(cartejouee,ennemi)
        elif self.niveau_difficulte == 2:
            return self.choosefightIA2(cartejouee,ennemi)

    def choosenbdeplacements(self, listeCases : list[Case], valeur: int, emplacementia : int, longueur : int):
        if self.niveau_difficulte == 1:
            return self.choosenbdeplacements1(listeCases, valeur, emplacementia, longueur)
        elif self.niveau_difficulte >= 2:
            return self.choosenbdeplacements2(listeCases, valeur, emplacementia, longueur)

    
    
    
    
    
    
    
    
    def jouer_aleatoire1(self, max: int):
        if max == 1:
            return 1
        
        interactions_possibles = ["Attaquer", "Utiliser Capacité Spéciale"]
        choix_interaction = random.choice(interactions_possibles)
        if choix_interaction == "Attaquer":
            return 1
        elif choix_interaction == "Utiliser Capacité Spéciale":
            return 2

    def jouer_aleatoire2(self, max: int):
        if max == 1:
            return 1
        
        interactions_possibles = ["Attaquer", "Utiliser Capacité Spéciale"]
        choix_interaction = random.choice(interactions_possibles)

        if choix_interaction == "Attaquer":
            return 1
        elif choix_interaction == "Utiliser Capacité Spéciale":
            return 2
        
    def choisircible1(self, case : Case):
        return random.randint(0, len(case.listeEnnemis) - 1)
    
    def choisircible2(self, case : Case):
        minimumhp = 1000000
        index = 0
        for x in case.listeEnnemis:
            if x.pointDeVie < minimumhp:
                minimumhp = x.pointDeVie
                index = case.listeEnnemis.index(x)
        return index
    
    
    
    
    
    
    def choosefightIA1(self, cartejouee : bool, ennemi : Ennemi):
        if self._capaciteDisponible == True and not cartejouee and self.lencard() > 0:
            interactions_possibles = ["attaque", "critique", "capaciteSpeciale","capaciteSpeciale"]
            choice = random.choice(interactions_possibles)
            if choice == "capaciteSpeciale":
                if random.randint(0,1) == 0:
                    return ["capaciteSpeciale", self.randomcard()]
                else:
                    return ["capaciteSpeciale", self.capacitejoueur()]
            return [choice]
        elif self._capaciteDisponible == True or (not cartejouee and self.lencard() > 0):
            interactions_possibles = ["attaque", "critique", "capaciteSpeciale"]
            choice = random.choice(interactions_possibles)
            if choice == "capaciteSpeciale":
                if self._capaciteDisponible:
                    return ["capaciteSpeciale", self.capacitejoueur()]
                else:
                    return ["capaciteSpeciale", self.randomcard()]
            return [choice]
        else:
            interactions_possibles = ["attaque", "critique"]
            return [random.choice(interactions_possibles)]
        
    
    def choosefightIA2(self, cartejouee : bool, ennemi : Ennemi):
        if not cartejouee:
            if self._capaciteDisponible:
                if self._capaciteSpeciale == CapaciteSpeciale.Parade and ((self._pointExperience / self._pointExperienceMax) + (ennemi.attaque - self._defense) / self._pointDeVie) > 0.75:
                    return ["capaciteSpeciale", "Parade"]
                elif self._capaciteSpeciale == CapaciteSpeciale.Fleche_neutralisante and (self._pointExperience / self._pointExperienceMax) > 0.75 or ennemi.attaque > self._defense + 5 or ennemi.pointDeVie > 2*(self.attaque-ennemi.defense):
                    return ["capaciteSpeciale", "Fleche neutralisante"]
                elif self._capaciteSpeciale == CapaciteSpeciale.Farce and (self._pointExperience / self._pointExperienceMax) > 0.75 or ennemi.attaque > self._defense + 5 or ennemi.pointDeVie > 2*(self.attaque-ennemi.defense):
                    return ["capaciteSpeciale", "Farce"]
                elif self._capaciteSpeciale == CapaciteSpeciale.Enchantement and (self._pointExperience / self._pointExperienceMax) > 0.75 or ennemi.attaque > self._defense + 5 or ennemi.pointDeVie > 2*(self.attaque-ennemi.defense):
                    return ["capaciteSpeciale", "Enchantement"]
            for t in self._cartes:
                if t.nom == "Potion" and self._pointDeVie <= self._pointDeVieMax - 5:
                    return ["capaciteSpeciale","Potion"]
                elif t.nom == "Fiole ATQ" or t.nom == "Fiole_ATQ" and ennemi.pointDeVie >= (self._attaque*0.85 - ennemi.defense):
                    return ["capaciteSpeciale","Fiole ATQ"]
        if (self.vitesse*3-ennemi.vitesse) > 50:
            return ["critique"]
        else:
            return ["attaque"]
    
    
    def choosefightIA3(self, joueur : Joueur, ennemis : list[Ennemi]):
        root = CombatNode(joueur, ennemis,  ["attaque"])
        full_tree = root.generate_combat_tree(3)
        print(root.best_move(3))
        test,a,b, index = root.best_move(3)
        if test == "attaque":
            return ["attaque"], index
        elif test == "capaciteSpeciale":
            return ["critique"], index
        elif test == "Fiole ATQ":
            return ["capaciteSpeciale", "Fiole ATQ"], index
        elif test == "Potion":
            return ["capaciteSpeciale", "Potion"], index
        elif test == "Parade":
            return ["capaciteSpeciale", "Parade"], index
        elif test == "Fleche neutralisante":
            return ["capaciteSpeciale", "Fleche neutralisante"], index
        elif test == "Farce":
            return ["capaciteSpeciale", "Farce"], index
        elif test == "Enchantement":
            return ["capaciteSpeciale", "Enchantement"], index
        else:
            return ["attaque"],0
               
    def capacitejoueur(self):
        if self._capaciteSpeciale == CapaciteSpeciale.Parade:
            return "Parade"
        elif self._capaciteSpeciale == CapaciteSpeciale.Fleche_neutralisante:
            return "Fleche neutralisante"
        elif self._capaciteSpeciale == CapaciteSpeciale.Farce:
            return "Farce"
        elif self._capaciteSpeciale == CapaciteSpeciale.Enchantement:
            return "Enchantement"
        
        
    def randomcard(self):
        card = []
        for t in range (0, len(self.cartes)):
            if self.cartes[t].nom == "Fiole_ATQ":
                card.append("Fiole ATQ")
            elif self.cartes[t].nom == "Potion":
                card.append("Potion")
        return random.choice(card)
    
    def lencard(self):
        card = []
        for t in range (0, len(self.cartes)):
            if self.cartes[t].nom == "Fiole_ATQ":
                card.append("Fiole ATQ")
            elif self.cartes[t].nom == "Potion":
                card.append("Potion")
        return len(card)
        
    def choosenbdeplacements1(self, listeCases : list[Case], valeur: int, emplacementia : int, longueur : int):
        return random.randint(1, valeur)
    
    
    
    
    def choosenbdeplacements2(self, listeCases : list[Case], valeur: int, emplacementia : int, longueur : int):
        for i in range (valeur):
            if len(listeCases[(emplacementia + i) % longueur].listeEnnemis) > 0:
                return i
        return valeur
    
    
    
    
    