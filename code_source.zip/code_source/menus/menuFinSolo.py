from widgets.Bouton import Bouton
import constant
from personnage.Joueur import Joueur

import pygame


def menuFinSolo(ecran: pygame.Surface, solo: bool, partieTerminee: bool):
    """
    Affiche le menu de fin de partie pour un joueur en mode solo ou pour le dernier joueur en mode multijoueur.

    Args:
     - ecran (pygame.Surface): La surface sur laquelle le menu sera affiché.
     - solo (bool): True si le joueur est en mode solo, False sinon.
     - partieTerminee (bool): True si la partie est terminée, False sinon.

    Returns:
     - bool: True si le joueur a choisi de retourner au menu principal, False sinon.
    """
    if not solo:
        joueur = Joueur.getAllJoueur()[0]

    ecran.fill(pygame.Color(0, 0, 0))
    if len(Joueur.getAllJoueur()) == 1 and not solo:
        texte = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 40).render(f"{joueur.nom} est le seul survivant et gagne la partie !", True, (255, 255, 0))
    else:
        texte = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 40).render(f"Vous êtes mort, fin de la partie", True, (255, 255, 0))
    ecran.blit(texte, (ecran.get_width()/2-texte.get_width()/2, ecran.get_height()/2-texte.get_height()/2-140))
    texteRetourAuMenu = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 40).render(" Retourner au menu principal ", True, (255, 255, 255))
    ecran.blit(texteRetourAuMenu, (ecran.get_width()/2-texteRetourAuMenu.get_width()/2, ecran.get_height()/2+texte.get_height()/2-100))
    boutonRetourAuMenu: Bouton = Bouton(" Menu Principal ", (100, 100, 100), (255, 255, 255), (0, 0))
    boutonRetourAuMenu.position = (ecran.get_width()/2-boutonRetourAuMenu.rect.width/2,
                                    ecran.get_height()/2+texte.get_height()/2+texteRetourAuMenu.get_height()-90)
    boutonRetourAuMenu.afficher(ecran)
    pygame.display.flip()
    menuFin = True

    # Boucle du menu de fin de partie
    while menuFin:
        for event in pygame.event.get():
            keys = pygame.key.get_pressed()
            if (keys[pygame.K_LALT] or keys[pygame.K_RALT]) and keys[pygame.K_F4]:
                pygame.quit()
                
            if event.type == pygame.QUIT:
                pygame.quit()

            # Retourne au menu principal
            if event.type == pygame.MOUSEBUTTONDOWN:
                if boutonRetourAuMenu.estClique():
                    menuFin = False
                    partieTerminee = True
                    
        ecran.blit(texte, (ecran.get_width()/2-texte.get_width()/2, ecran.get_height()/2-texte.get_height()/2-140))
        ecran.blit(texteRetourAuMenu, (ecran.get_width()/2-texteRetourAuMenu.get_width()/2, ecran.get_height()/2+texte.get_height()/2-100))
        boutonRetourAuMenu.afficher(ecran)
        pygame.display.flip()
        
    return partieTerminee