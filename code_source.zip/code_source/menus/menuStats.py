import pygame
import constant
from widgets.Bouton import Bouton
import json
import re
import os

def menuStats(ecran: pygame.Surface):
    # Trouver le chemin absolu du fichier JSON dans le dossier source
    clock = pygame.time.Clock()
    chemin_fichier_json = trouver_fichier_json()

    if chemin_fichier_json:
        # Charger les données des joueurs à partir du fichier JSON
        with open(chemin_fichier_json, "r") as f:
            donnees_joueurs = json.load(f)

        # Nettoyer les noms des joueurs pour supprimer les caractères spéciaux
        donnees_joueurs = {re.sub(r'[^\w\s]', '', data["nom"]): data for data in donnees_joueurs.values()}

        fontNom: pygame.font.Font = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 40)

        # Définir les positions des éléments à afficher
        POS_TITRE = (50, 50)

        # Définir les couleurs pour le nom
        COULEUR_NOM = (255, 255, 255)

        # Définir le titre du menu
        titre = fontNom.render("Statistiques", True, (255, 255, 255))

        running = True
        
        joueurPresente = 1
        keys = list(donnees_joueurs.keys())
        texteJoueur = fontNom.render(f"{joueurPresente} sur {len(keys)}", True, COULEUR_NOM)
        
        boutonPrecedent = Bouton(" < ", (100, 100, 100), (255, 255, 255), (ecran.get_width()//2-texteJoueur.get_width()//2-20, 670))
        boutonSuivant = Bouton(" > ", (100, 100, 100), (255, 255, 255), (ecran.get_width()//2+texteJoueur.get_width()//2+10, 670))

        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    pygame.quit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if boutonPrecedent.estClique():
                        if joueurPresente > 1:
                            joueurPresente -= 1
                            
                    if boutonSuivant.estClique():
                        if joueurPresente < len(keys):
                            joueurPresente += 1
                            
                    if bouton_retour.estClique():
                        running = False
                        ecran.fill((0, 0, 0))
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_LEFT:
                        if joueurPresente > 1:
                            joueurPresente -= 1
                        
                    elif event.key == pygame.K_DOWN:
                        if joueurPresente < len(keys):
                            joueurPresente += 1

            ecran.fill((0, 0, 0))
            ecran.blit(titre, POS_TITRE)

            # Afficher les statistiques des joueurs
            donneesJoueurPresente = donnees_joueurs[keys[joueurPresente-1]]
            
            for i, (cle, valeur) in enumerate(donneesJoueurPresente.items()):
                nom = fontNom.render(f"{cle} : {valeur}", True, COULEUR_NOM)
                
                ecran.blit(nom, (50 if i < 7 else ecran.get_width()//2+50, 150 + (i%7) * 50))
                    
            texteJoueur = fontNom.render(f"{joueurPresente} sur {len(keys)}", True, COULEUR_NOM)
            ecran.blit(texteJoueur, (ecran.get_width()//2 - texteJoueur.get_width()//2, 670))

            # Calculer la position du bouton "Retour" juste en dessous de toutes les données
            bouton_retour = Bouton("Retour", (100, 100, 100), (255, 255, 255), (50, ecran.get_height() - 50))  # Création du bouton

            # Afficher le bouton "Retour"
            bouton_retour.afficher(ecran)
            
            boutonPrecedent.afficher(ecran)
            boutonSuivant.afficher(ecran)

            pygame.display.flip()
            clock.tick(60)

    else:
        print("Aucun fichier JSON trouvé dans le dossier source.")

# Fonction pour trouver le fichier JSON dans le dossier source
def trouver_fichier_json():
    # Chemin du dossier source
    chemin_dossier_source = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))

    # Parcourir tous les fichiers du dossier source
    for nom_fichier in os.listdir(chemin_dossier_source):
        chemin_fichier = os.path.join(chemin_dossier_source, nom_fichier)
        
        # Vérifier si le fichier est un fichier JSON
        if nom_fichier.endswith(".json"):
            return chemin_fichier
    
    # Si aucun fichier JSON n'est trouvé, retourner None
    return None
