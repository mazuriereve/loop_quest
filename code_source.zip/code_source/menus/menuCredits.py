import constant
from widgets.Bouton import Bouton


import pygame


def menuCredits(ecran: pygame.Surface):
    """
    Affiche le menu des crédits avec une image défilante et un bouton de retour.

    Args:
     - ecran (pygame.Surface): La surface d'affichage.

    Raises:
     - SystemExit: Si l'utilisateur appuie sur Alt+F4.
    """
    clock = pygame.time.Clock()
    boutonRetour: Bouton = Bouton(" X ", (100, 100, 100), (255, 255, 255), (0, 20))
    boutonRetour.rect.x = ecran.get_width()-boutonRetour.rect.width-20
    imageCredits = pygame.image.load(constant.CHEMIN_IMAGE_CREDITS)
    decalageImage: int = -1

    running: bool = True
    while running:
        for event in pygame.event.get():
            keys = pygame.key.get_pressed()
            if (keys[pygame.K_LALT] or keys[pygame.K_RALT]) and keys[pygame.K_F4]:
                pygame.quit()
            
            if event.type == pygame.QUIT:
                pygame.quit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if boutonRetour.estClique():
                    running = False

        if decalageImage < imageCredits.get_height():
            decalageImage += 1
        else:
            running = False
        ecran.fill(pygame.Color(0, 0, 0))
        ecran.blit(imageCredits, (0, 0-decalageImage))
        boutonRetour.afficher(ecran)
        pygame.display.flip()

        clock.tick(60)