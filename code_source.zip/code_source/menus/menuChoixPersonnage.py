import constant
from boucles.bouclesJeu import boucleJeu
from personnage.ClassesJoueur import ClassesJoueur
from widgets.Bouton import Bouton
from widgets.WidgetCarte import WidgetCarte
from widgets.fonctions import contourRect
import json
from personnage.JoueurIA import JoueurIA
from widgets.BoutonToggle import BoutonToggle
from widgets.Boutonia import BoutonIa


import pygame
import os
import atexit

def menuChoixPersonnage(ecran: pygame.Surface, nbJoueurs: int):
    """
    Affiche un menu pour les joueurs afin qu'ils choisissent leur personnage et entrent leur nom.

    Args:
    - ecran (pygame.Surface): objet representant l'écran de jeu
    - nbJoueurs (int): un entier representant le nombre de joueurs
    """
    clock = pygame.time.Clock()
    ecran.fill(pygame.Color(0, 0, 0))

    # Barre de saisie
    fontNom: pygame.font.Font = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 40)
    texteSaisie: pygame.Surface = pygame.font.Font(constant.CHEMIN_POLICE_TITRE, 60).render(" MMMMMMMMMM ", True, (0, 0, 0))
    zoneDeSaisie: pygame.Rect = pygame.Rect(0, 0, texteSaisie.get_width()+10, texteSaisie.get_height()+10)
    zoneDeSaisie.x = ecran.get_width()/2-zoneDeSaisie.width/2 ; zoneDeSaisie.y = 150
    zoneDeSaisieActive: bool = False
    couleurBordure: pygame.Color = pygame.Color(100, 100, 100)
    nomJoueur: str = ""
    # Permet d'empêcher l'utilisation de caractères spéciaux dans le nom du joueur
    tableTrans = str.maketrans({"é": "e", "è": "e", "ê": "e", "à": "a", "â": "a", "ù": "u", "î": "i", "ô": "o", "ò": "o", "û": "u", "ù": "u", "ç": "c"})

    # Sélection personnage
    texteCaracteristiques: str = ["Points de vie : ", "Attaque : ", "Défense : ", "Vitesse : "]
    listeClassesJoueurs = list(ClassesJoueur)
    indexListeClasses: int = 0
    boitePersonnage: pygame.Rect = pygame.Rect(0, 350, 148, 180)
    boitePersonnage.x = ecran.get_width()/2-boitePersonnage.width/2
    boutonSuivant: Bouton = Bouton(" > ", (100, 100, 100), (255, 255, 255), (0, 0))
    boutonSuivant.position = (boitePersonnage.x+boitePersonnage.width+10, boitePersonnage.y+boitePersonnage.height/2-boutonSuivant.rect.height/2)
    boutonPrecedent: Bouton = Bouton(" < ", (100, 100, 100), (255, 255, 255), (0, 0))
    boutonPrecedent.position = (boitePersonnage.x-boutonPrecedent.rect.width-10, boitePersonnage.y+boitePersonnage.height/2-boutonSuivant.rect.height/2)

    # Bouton confirmer
    boutonConfirmer: Bouton = Bouton(" > Confirmer ", (100, 100, 100), (255, 255, 255), (0, 0))
    boutonConfirmer.position = (ecran.get_width()-boutonConfirmer.rect.width-20, ecran.get_height()-boutonConfirmer.rect.height-20)

    # Créer un dictionnaire vide pour stocker les données des joueurs
    donnees_joueurs = {}

    boutonJoueurIA: BoutonIa = BoutonIa(" 0 ", (0, 0, 0), (255, 255, 255), (20, ecran.get_height()-70))
    texteIA = fontNom.render("Difficulté IA - 0 si pas d'IA", True, (255, 255, 255))
    
    for i in range(nbJoueurs):
        ecran.fill((0, 0, 0))
        txt = fontNom.render(f"Joueur {i+1}, choisissez un personnage", True, (255, 255, 255))
        ecran.blit(txt, (ecran.get_width()/2-txt.get_width()/2, ecran.get_height()/2-txt.get_height()/2))
        pygame.display.flip()
        pygame.time.wait(2000)
        nomJoueur = ""
        running: bool = True
        zoneDeSaisieActive = False
        while running:
            for event in pygame.event.get():
                keys = pygame.key.get_pressed()
                if (keys[pygame.K_LALT] or keys[pygame.K_RALT]) and keys[pygame.K_F4]:
                    pygame.quit()
                    
                if event.type == pygame.QUIT:
                    pygame.quit()

                if event.type == pygame.MOUSEBUTTONDOWN:
                    zoneDeSaisieActive = zoneDeSaisie.collidepoint(pygame.mouse.get_pos())
                    
                    boutonJoueurIA.estClique()
                    
                    if boutonSuivant.estClique():
                        indexListeClasses += 1
                        if indexListeClasses >= len(listeClassesJoueurs):
                            indexListeClasses = 0

                    if boutonPrecedent.estClique():
                        indexListeClasses -= 1
                        if indexListeClasses < 0:
                            indexListeClasses = len(listeClassesJoueurs)-1

                    if boutonConfirmer.estClique():
                        if boutonJoueurIA.active:
                            j = listeClassesJoueurs[indexListeClasses].creerJoueurIA(boutonJoueurIA.difficulte())
                            if nomJoueur != "":
                                j.nom = nomJoueur
                            else:
                                j.nom = f"JoueurIA {i+1} "
                        else:
                            j = listeClassesJoueurs[indexListeClasses].creerJoueur()
                            if nomJoueur != "":
                                j.nom = nomJoueur
                            else:
                                j.nom = f"Joueur {i+1}"

                        # Créer un dictionnaire vide pour stocker les données du joueur actuel
                        donnees_joueur = {}

                        # Ajouter le nom du joueur au dictionnaire
                        donnees_joueur["nom"] = j.nom

                        # Ajouter la classe du personnage choisi par le joueur au dictionnaire
                        donnees_joueur["classe"] = listeClassesJoueurs[indexListeClasses].name

                        # Ajouter les caractéristiques du personnage choisi par le joueur au dictionnaire
                        caracteristiques = {}
                        for j in range(len(texteCaracteristiques)):
                            caracteristiques[texteCaracteristiques[j]] = listeClassesJoueurs[indexListeClasses].value[j+1]

                        # Ajout d'autres données initialisées à 0
                        donnees_joueur["degatsTotaux"] = 0
                        donnees_joueur["nbEnnemisTues"] = 0
                        donnees_joueur["nbAttaquesReussies"] = 0
                        donnees_joueur["nbAttaquesRatees"] = 0
                        donnees_joueur["degatsRecus"] = 0
                        donnees_joueur["nbCartesJouees"] = 0
                        donnees_joueur["argentGagne"] = 0
                        donnees_joueur["argentDepense"] = 0
                        donnees_joueur["nbDeplacements"] = 0
                        donnees_joueur["nbCapacitesUtilisees"] = 0
                        donnees_joueur["nbCombatsGagnes"] = 0
                        donnees_joueur["nbCombatsFuis"] = 0
                        
                        
                        # Ajouter les données du joueur au dictionnaire des joueurs
                        donnees_joueurs[f"joueur_{i+1}"] = donnees_joueur

                            
                        running = False

                if event.type == pygame.KEYDOWN:
                    if zoneDeSaisieActive:
                        if keys[pygame.K_BACKSPACE]:
                            nomJoueur = nomJoueur[:-1]
                        else:
                            if len(nomJoueur) < 10:
                                if event.unicode.isalnum() or event.unicode.isspace():
                                    nomJoueur += event.unicode
                                    nomJoueur = nomJoueur.translate(tableTrans)

            ecran.fill((0, 0, 0))
            # Affichage zone de saisie
            couleurBordure: pygame.Color = pygame.Color(100, 100, 100) if not zoneDeSaisieActive else pygame.Color(255, 255, 255)
            texteNom = fontNom.render(f"Joueur {i+1}, entrez votre nom :", True, (255, 255, 255))
            ecran.blit(texteNom, (zoneDeSaisie.x, 100))
            ecran.blit(texteIA, (100, ecran.get_height()-70))
            if nomJoueur == "":
                texteSaisieSurface: pygame.Surface = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 60).render(f" Cliquez ici ", True, (50, 50, 50))
            else:
                texteSaisieSurface: pygame.Surface = pygame.font.Font(constant.CHEMIN_POLICE_TITRE, 60).render(f" {nomJoueur} ", True, (255, 255, 255))
            ecran.blit(texteSaisieSurface, (zoneDeSaisie.x+5, zoneDeSaisie.y+5))
            for bord, pos in contourRect(zoneDeSaisie, couleurBordure, 2):
                ecran.blit(bord, pos)

            # Affichage sélection personnage
            for bord, pos in contourRect(boitePersonnage, pygame.Color(255, 255, 255), 2):
                ecran.blit(bord, pos)
            boutonPrecedent.afficher(ecran)
            boutonSuivant.afficher(ecran)
            texteClassePersonnage = fontNom.render(listeClassesJoueurs[indexListeClasses].name, True, (255, 255, 255))
            ecran.blit(texteClassePersonnage, (ecran.get_width()/2-texteClassePersonnage.get_width()/2, boitePersonnage.y-texteClassePersonnage.get_height()-10))
            spritePersonnage = pygame.transform.scale_by(
                pygame.image.load(listeClassesJoueurs[indexListeClasses].value[6]).
                subsurface(0, 0, listeClassesJoueurs[indexListeClasses].value[7][0],listeClassesJoueurs[indexListeClasses].value[7][1]),
                           listeClassesJoueurs[indexListeClasses].value[8]*2)
            ecran.blit(spritePersonnage,
                       (ecran.get_width()/2-spritePersonnage.get_width()/2,
                        boitePersonnage.y-(32 if spritePersonnage.get_height() > 190 else 0)*(2 if listeClassesJoueurs[indexListeClasses].name == "Chasseur" else 1)))

            texteCapaciteSpeciale = fontNom.render("Capacité", True, (255, 255, 255))
            ecran.blit(texteCapaciteSpeciale, (150, 300))
            texteCapaciteSpeciale = fontNom.render("spéciale :", True, (255, 255, 255))
            ecran.blit(texteCapaciteSpeciale, (150, 340))
            if listeClassesJoueurs[indexListeClasses].value[5].name != "Fleche_neutralisante":
                nomCapacite = listeClassesJoueurs[indexListeClasses].value[5].name.replace("_", " ")
            else:
                nomCapacite = listeClassesJoueurs[indexListeClasses].value[5].name.replace("_", "\n")
            widgetCarteCapacitePersonnage = WidgetCarte(nomCapacite, listeClassesJoueurs[indexListeClasses].value[5].value, None,
                            f"{constant.REPERTOIRE_COURANT}/ressources/icones/icone_{listeClassesJoueurs[indexListeClasses].value[5].name.lower()}.png", (51, 153, 255))
            widgetCarteCapacitePersonnage.afficher(ecran, ((400-60)//2, (720-150-40)//3), (150, 390))

            texteCaract = fontNom.render("Caractéristiques :", True, (255, 255, 255))
            ecran.blit(texteCaract, (850, 300))
            for j in range(len(texteCaracteristiques)):
                ecran.blit(fontNom.render(f"{texteCaracteristiques[j]}{listeClassesJoueurs[indexListeClasses].value[j+1]}", True, (255, 255, 255)), (850, 350+(j*45)))


            boutonJoueurIA.afficher(ecran)

            # Affichage bouton confirmer
            boutonConfirmer.afficher(ecran)

            pygame.display.flip()

            clock.tick(60)

    # Obtenir le chemin absolu du répertoire du script Python
    chemin_dossier_source = os.path.abspath(os.path.join(os.path.dirname(__file__), os.pardir))

    # Définir le chemin complet du fichier JSON dans le dossier source
    chemin_fichier_json = os.path.join(chemin_dossier_source, "donnees_joueurs.json")

    # Convertir les données des joueurs en une chaîne JSON
    donnees_json = json.dumps(donnees_joueurs)

    # Écrire les données JSON dans un fichier
    with open(chemin_fichier_json, "w") as f:
        f.write(donnees_json)

    # Enregistrer la fonction pour supprimer le fichier JSON lorsque le jeu est fermé
    atexit.register(supprimer_fichier_json)

    # Lancer la boucle principale du jeu
    boucleJeu(ecran)

def supprimer_fichier_json():
    if os.path.exists("donnees_joueurs.json"):
        os.remove("donnees_joueurs.json")

# Enregistrer la fonction pour supprimer le fichier JSON lorsque le jeu est fermé
atexit.register(supprimer_fichier_json)
