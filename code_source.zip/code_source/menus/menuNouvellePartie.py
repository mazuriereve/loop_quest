import constant
from menus.menuChoixPersonnage import menuChoixPersonnage
from widgets.Bouton import Bouton


import pygame


def menuNouvellePartie(ecran: pygame.Surface):
    """
    Affiche le menu pour choisir le nombre de joueurs et appelle le menu de choix de personnage correspondant.

    Args:
     - ecran (pygame.Surface): La surface sur laquelle afficher le menu.
    """
    ecran.fill(pygame.Color(0, 0, 0))
    clock = pygame.time.Clock()
    if constant.CHEMIN_FOND_MENU != None:
        ecran.blit(pygame.image.load(constant.CHEMIN_FOND_MENU), (0, 0))
    texte = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 40).render(" Choisissez le nombre de joueurs ", True, (255, 255, 255))
    ecran.blit(texte, (ecran.get_width()/2-texte.get_width()/2, 100))
    boutonSolo: Bouton = Bouton(" 1 joueur ", (100, 100, 100), (255, 255, 255), (400, 300))
    bouton2Joueurs: Bouton = Bouton(" 2 joueurs ", (100, 100, 100), (255, 255, 255), (400, 400))
    bouton3Joueurs: Bouton = Bouton(" 3 joueurs ", (100, 100, 100), (255, 255, 255), (400, 500))
    bouton4Joueurs: Bouton = Bouton(" 4 joueurs ", (100, 100, 100), (255, 255, 255), (400, 600))
    boutonSolo.position = (ecran.get_width()/2-boutonSolo.rect.width/2, 300)
    bouton2Joueurs.position = (ecran.get_width()/2-bouton2Joueurs.rect.width/2, 400)
    bouton3Joueurs.position = (ecran.get_width()/2-bouton3Joueurs.rect.width/2, 500)
    bouton4Joueurs.position = (ecran.get_width()/2-bouton4Joueurs.rect.width/2, 600)
    boutonSolo.afficher(ecran) ; bouton2Joueurs.afficher(ecran) ; bouton3Joueurs.afficher(ecran) ; bouton4Joueurs.afficher(ecran)
    pygame.display.flip()

    running: bool = True
    while running:
        for event in pygame.event.get():
            keys = pygame.key.get_pressed()
            if (keys[pygame.K_LALT] or keys[pygame.K_RALT]) and keys[pygame.K_F4]:
                pygame.quit()
                
            if event.type == pygame.QUIT:
                pygame.quit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if boutonSolo.estClique():
                    running = False
                    menuChoixPersonnage(ecran, 1)
                elif bouton2Joueurs.estClique():
                    running = False
                    menuChoixPersonnage(ecran, 2)
                elif bouton3Joueurs.estClique():
                    running = False
                    menuChoixPersonnage(ecran, 3)
                elif bouton4Joueurs.estClique():
                    running = False
                    menuChoixPersonnage(ecran, 4)

        clock.tick(60)