import constant
from widgets.Bouton import Bouton


import pygame


def menuTutoriel(ecran: pygame.Surface):
    """
    Affiche le menu tutoriel.

    Args:
        ecran (pygame.Surface): La surface sur laquelle afficher le menu.
    """
    clock = pygame.time.Clock()
    panel: int = 1
    ecran.fill(pygame.Color(0, 0, 0))
    boutonFermer = Bouton(" X ", (100, 100, 100), (255, 255, 255), (0, 0))
    boutonFermer.position = (ecran.get_width()-boutonFermer.rect.width-10, 10)
    boutonSuivant = Bouton(" > ", (100, 100, 100), (255, 255, 255), (0, 0))
    boutonSuivant.position = (ecran.get_width()-boutonSuivant.rect.width-10, ecran.get_height()-boutonSuivant.rect.height-10)
    running = True
    while running:
        for event in pygame.event.get():
            keys = pygame.key.get_pressed()
            if (keys[pygame.K_LALT] or keys[pygame.K_RALT]) and keys[pygame.K_F4]:
                pygame.quit()
                
            if event.type == pygame.QUIT:
                pygame.quit()
                
            if keys[pygame.K_RIGHT] or keys[pygame.K_SPACE] or keys[pygame.K_RETURN]:
                panel += 1
                if panel > 6:
                    panel = 6
                    running = False
            if keys[pygame.K_LEFT] or keys[pygame.K_BACKSPACE]:
                panel -= 1
                if panel < 1:
                    panel = 1

            if event.type == pygame.MOUSEBUTTONDOWN:
                if boutonFermer.estClique():
                    running = False
                elif boutonSuivant.estClique():
                    panel += 1
                    if panel > 6:
                        panel = 6
                        running = False

        ecran.blit(pygame.image.load(f"{constant.REPERTOIRE_COURANT}/ressources/menus/tutoriel_{panel}.png"), (0, 0))
        boutonFermer.afficher(ecran)
        boutonSuivant.afficher(ecran)

        pygame.display.flip()
        clock.tick(60)