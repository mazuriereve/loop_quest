import constant
import plateau
from widgets.Bouton import Bouton
from menus.menuStats import menuStats


import pygame

def menuPause(ecran: pygame.Surface, plat: plateau.Plateau, solo: bool, partieTerminee: bool):
    """
    Affiche le pause du jeu , l'utilisateur a le choix de soit quitter la partie avec "Quitter" 
    ou peut reprendre le jeu     
    """
    clock = pygame.time.Clock()
    ecran = pygame.display.set_mode((1280, 720))

    titreJeu: pygame.Surface = pygame.font.Font(constant.CHEMIN_POLICE_TITRE, 100).render(constant.TITRE_JEU, True, (255, 255, 255))
    ecran.fill(pygame.Color(0, 0, 0))
    if constant.CHEMIN_FOND_MENU != None:
        ecran.blit(pygame.image.load(constant.CHEMIN_FOND_MENU), (0, 0))
    ecran.blit(titreJeu, (ecran.get_width()/2-titreJeu.get_width()/2, 100))

    boutonReprendre: Bouton = Bouton(" Reprendre ", (100, 100, 100), (255, 255, 255), (400, 300))
    boutonStats = Bouton(" Statistiques ", (100, 100, 100), (255, 255, 255), (400, 450))
    boutonQuitter: Bouton = Bouton(" Quitter ", (100, 100, 100), (255, 255, 255), (400, 600))
    
    boutonReprendre.position = (ecran.get_width()/2-boutonReprendre.rect.width/2, 300)
    boutonStats.position = (ecran.get_width()/2-boutonStats.rect.width/2, 450)
    boutonQuitter.position = (ecran.get_width()/2-boutonQuitter.rect.width/2, 600)

    boutonReprendre.afficher(ecran) 
    boutonStats.afficher(ecran) 
    boutonQuitter.afficher(ecran)
    pygame.display.flip()

    running: bool = True
    while running:
        for event in pygame.event.get():
            keys = pygame.key.get_pressed()
            if (keys[pygame.K_LALT] or keys[pygame.K_RALT]) and keys[pygame.K_F4]:
                pygame.quit()
            
            if event.type == pygame.QUIT:
                pygame.quit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if boutonReprendre.estClique():
                    running = False
                elif boutonStats.estClique():
                    menuStats(ecran)
                elif boutonQuitter.estClique():
                    from menus.menuJeu import menuJeu

                    menuJeu()
                    pygame.quit()

        ecran.fill(pygame.Color(0, 0, 0))
        if constant.CHEMIN_FOND_MENU != None:
            ecran.blit(pygame.image.load(constant.CHEMIN_FOND_MENU), (0, 0))
        ecran.blit(titreJeu, (ecran.get_width()/2-titreJeu.get_width()/2, 100))
        boutonReprendre.afficher(ecran) ; boutonStats.afficher(ecran) ; boutonQuitter.afficher(ecran)
        pygame.display.flip()

        clock.tick(60)

    ecran.fill(pygame.Color(156,219,67))


