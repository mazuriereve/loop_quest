import constant
from menus.menuCredits import menuCredits
from menus.menuNouvellePartie import menuNouvellePartie
from menus.menuTutoriel import menuTutoriel
from widgets.Bouton import Bouton


import pygame


def menuJeu():
    """
    Affiche le menu principal du jeu avec les options "Nouvelle partie", "Tutoriel", "Crédits" et "Quitter".
    L'utilisateur peut cliquer sur les boutons pour accéder aux différentes options.
    Si l'utilisateur appuie sur Alt+F4, le programme se ferme.
    """
    clock = pygame.time.Clock()
    ecran = pygame.display.set_mode((1280, 720))
    # Décommenter pour mettre le jeu en plein écran
    pygame.display.toggle_fullscreen()

    titreJeu: pygame.Surface = pygame.font.Font(constant.CHEMIN_POLICE_TITRE, 100).render(constant.TITRE_JEU, True, (255, 255, 255))
    ecran.fill(pygame.Color(0, 0, 0))
    if constant.CHEMIN_FOND_MENU != None:
        ecran.blit(pygame.image.load(constant.CHEMIN_FOND_MENU), (0, 0))
    ecran.blit(titreJeu, (ecran.get_width()/2-titreJeu.get_width()/2, 100))
    boutonNouvellePartie: Bouton = Bouton(" Nouvelle partie ", (100, 100, 100), (255, 255, 255), (400, 300))
    boutonTutoriel: Bouton = Bouton(" Tutoriel ", (100, 100, 100), (255, 255, 255), (400, 400))
    boutonCredits: Bouton = Bouton(" Credits ", (100, 100, 100), (255, 255, 255), (400, 500))
    boutonQuitter: Bouton = Bouton(" Quitter ", (100, 100, 100), (255, 255, 255), (400, 600))
    boutonNouvellePartie.position = (ecran.get_width()/2-boutonNouvellePartie.rect.width/2, 300)
    boutonTutoriel.position = (ecran.get_width()/2-boutonTutoriel.rect.width/2, 400)
    boutonCredits.position = (ecran.get_width()/2-boutonCredits.rect.width/2, 500)
    boutonQuitter.position = (ecran.get_width()/2-boutonQuitter.rect.width/2, 600)
    boutonNouvellePartie.afficher(ecran) ; boutonTutoriel.afficher(ecran) ; boutonCredits.afficher(ecran) ; boutonQuitter.afficher(ecran)
    pygame.display.flip()

    running: bool = True
    while running:
        for event in pygame.event.get():
            keys = pygame.key.get_pressed()
            if (keys[pygame.K_LALT] or keys[pygame.K_RALT]) and keys[pygame.K_F4]:
                pygame.quit()
                
            if event.type == pygame.QUIT:
                pygame.quit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                if boutonNouvellePartie.estClique():
                    menuNouvellePartie(ecran)
                elif boutonTutoriel.estClique():
                    menuTutoriel(ecran)
                elif boutonCredits.estClique():
                    menuCredits(ecran)
                elif boutonQuitter.estClique():
                    running = False

        ecran.fill(pygame.Color(0, 0, 0))
        if constant.CHEMIN_FOND_MENU != None:
            ecran.blit(pygame.image.load(constant.CHEMIN_FOND_MENU), (0, 0))
        ecran.blit(titreJeu, (ecran.get_width()/2-titreJeu.get_width()/2, 100))
        boutonNouvellePartie.afficher(ecran) ; boutonTutoriel.afficher(ecran) ; boutonCredits.afficher(ecran) ; boutonQuitter.afficher(ecran)
        pygame.display.flip()

        clock.tick(60)