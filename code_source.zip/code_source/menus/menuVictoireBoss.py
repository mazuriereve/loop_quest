import constant
from menus.menuStats import menuStats
import plateau
from personnage.Joueur import Joueur
from widgets.Bouton import Bouton


import pygame


def menuVictoireBoss(ecran: pygame.Surface, plat: plateau.Plateau, solo: bool, joueurActuel: int, partieTerminee: bool, tourTermine: bool):
    """
    Affiche le menu de fin de partie en cas de victoire contre le boss.

    Args:
     - ecran (pygame.Surface): la surface d'affichage.
     - plat (plateau.Plateau): le plateau de jeu.
     - solo (bool): True si la partie est en mode solo, False sinon.
     - joueurActuel (int): l'indice du joueur actuel dans la liste de tous les joueurs.
     - partieTerminee (bool): True si la partie est terminée, False sinon.
     - tourTermine (bool): True si le tour est terminé, False sinon.

    Returns:
     - partieTerminee (bool): True si la partie est terminée, False sinon.
     - tourTermine (bool): True si le tour est terminé, False sinon.
    """
    joueur = Joueur.getAllJoueur()[joueurActuel]
    ecran.fill(pygame.Color(0, 0, 0))
    texte = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 40).render(f"{joueur.nom} a vaincu le boss et gagne la partie !",
                                                                        True, (255, 255, 0))
    ecran.blit(texte, (ecran.get_width()/2-texte.get_width()/2, ecran.get_height()/2-texte.get_height()/2-140))
    texteRetourAuMenu = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 40).render(" Retourner au menu principal ", True, (255, 255, 255))
    ecran.blit(texteRetourAuMenu, (ecran.get_width()/2-texteRetourAuMenu.get_width()/2, ecran.get_height()/2+texte.get_height()/2-100))
    boutonRetourAuMenu: Bouton = Bouton(" Menu Principal ", (100, 100, 100), (255, 255, 255), (0, 0))
    boutonRetourAuMenu.position = (ecran.get_width()/2-boutonRetourAuMenu.rect.width/2,
                                    ecran.get_height()/2+texte.get_height()/2+texteRetourAuMenu.get_height()-90)
    boutonRetourAuMenu.afficher(ecran)
    if not solo or len(Joueur.getAllJoueur()) > 1:
        texteContinuer = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 40).render(f" Continuer la partie sans {joueur.nom}",
                                                                                    True, (255, 255, 255))
        ecran.blit(texteContinuer, (ecran.get_width()/2-texteContinuer.get_width()/2,
                                    ecran.get_height()/2+texte.get_height()/2+texteRetourAuMenu.get_height()+boutonRetourAuMenu.rect.height-60))
        boutonContinuer: Bouton = Bouton(" Continuer ", (100, 100, 100), (255, 255, 255), (0, 0))
        boutonContinuer.position = (ecran.get_width()/2-boutonContinuer.rect.width/2,
                                    ecran.get_height()/2+texte.get_height()/2+texteRetourAuMenu.get_height()+boutonRetourAuMenu.rect.height+texteContinuer.get_height()-50)
        boutonContinuer.afficher(ecran)
        
    boutonStats: Bouton = Bouton(" Statistiques ", (100, 100, 100), (255, 255, 255), (0, 0))
    boutonStats.position = (ecran.get_width()/2-boutonStats.rect.width/2,
                            ecran.get_height()/2+texte.get_height()/2+texteRetourAuMenu.get_height()+boutonRetourAuMenu.rect.height+texteContinuer.get_height()+boutonContinuer.rect.height-40)
    boutonStats.afficher(ecran)
    
    pygame.display.flip()
    menuFin = True

    # Boucle du menu de fin de partie
    while menuFin:
        for event in pygame.event.get():
            keys = pygame.key.get_pressed()
            if (keys[pygame.K_LALT] or keys[pygame.K_RALT]) and keys[pygame.K_F4]:
                pygame.quit()
                
            if event.type == pygame.QUIT:
                pygame.quit()

            if event.type == pygame.MOUSEBUTTONDOWN:
                # Retourne au menu principal
                if boutonRetourAuMenu.estClique():
                    partieTerminee = True
                    menuFin = False

                # Continue la partie sans le joueur gagnant
                elif boutonContinuer.estClique():
                    plat.listeCases[joueur.emplacement].listeEnnemis = []
                    plat.listeCases[joueur.emplacement].portail = False
                    Joueur.getAllJoueur().pop(joueurActuel)
                    joueurActuel -= 1
                    ecran.fill(pygame.Color(156,219,67))
                    tourTermine = True
                    partieTerminee = False
                    menuFin = False
                    
                elif boutonStats.estClique():
                    menuStats(ecran)

        ecran.blit(texte, (ecran.get_width()/2-texte.get_width()/2, ecran.get_height()/2-texte.get_height()/2-140))
        ecran.blit(texteRetourAuMenu, (ecran.get_width()/2-texteRetourAuMenu.get_width()/2, ecran.get_height()/2+texte.get_height()/2-100))
        boutonRetourAuMenu.afficher(ecran)
        if not solo or len(Joueur.getAllJoueur()) > 1:
            ecran.blit(texteContinuer, (ecran.get_width()/2-texteContinuer.get_width()/2,
                                        ecran.get_height()/2+texte.get_height()/2+texteRetourAuMenu.get_height()+boutonRetourAuMenu.rect.height-60))
            boutonContinuer.afficher(ecran)
        pygame.display.flip()

    return partieTerminee, tourTermine