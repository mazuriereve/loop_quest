# Boucles de jeu
import json, constant, variables_globales
from affichage.initAffichageCombat import initAffichageCombat
import plateau
from affichage.updateAffichageCombat import updateAffichageCombat
from boucles.fonctions.mortEnnemi import mortEnnemi
from case.Case import Case
from personnage.Ennemi import Ennemi
from personnage.Joueur import Joueur
from personnage.TypesEnnemi import TypesEnnemi
from util.Compteur import Compteur
from util.Effet import Effet
from util.EffetTemporaire import EffetTemporaire
from widgets.BarreLaterale import BarreLaterale
from personnage.JoueurIA import JoueurIA
from menus.menuPause import menuPause
import random


import pygame


import operator
from random import randint


def boucleCombat(ecran: pygame.Surface, barreLaterale: BarreLaterale, plat: plateau.Plateau, case: Case, joueurActuel: int):
    """
    Gère la boucle de combat entre un joueur et des ennemis.

    Args:
     - ecran (pygame.Surface): L'écran servant à l'affichage.
     - barreLaterale (BarreLaterale): La barre latérale servant à l'affichage.
     - plat (plateau.Plateau): Le plateau (utile pour la génération des cartes en récompense).
     - case (Case): La case sur laquelle se trouve le joueur.
     - joueurActuel (int): L'indice du joueur actuel dans la liste de tous les joueurs.
    """
    # Initialisation et affichage
    ecranCombat, boutonAttaque, boutonCritique, boutonCarte , boutonFuite , boutonRetour, boite = initAffichageCombat()
    donneesJoueurActuel = variables_globales.donnees_joueurs[f"joueur_{joueurActuel+1}"]
    barreLaterale.afficher(ecran, joueurActuel, combat=True)
    ecranCombat.afficher(ecran, case, joueurActuel)
    if not Joueur.getAllJoueur()[joueurActuel].isIA:
        boutonAttaque.afficher(ecran)
        boutonCritique.afficher(ecran)
        boutonCarte.afficher(ecran)
        boutonFuite.afficher(ecran)
        boutonRetour.afficher(ecran)
    clock = pygame.time.Clock()
    joueur = Joueur.getAllJoueur()[joueurActuel]

    # Variables utiles à la gestion de la boucle
    indexWidgetSelectionne: int = -1
    tourJoueur: bool = True
    carteJouee: bool = False
    attaque: bool = False
    critique: bool = False
    capaciteSpeciale: str = ""
    cibleCapacite: int = -1
    combatTermine: bool = False

    for ennemi in case.listeEnnemis:
        ennemi.niveau = joueur.niveauEnnemisRencontres
    listeActionsEnnemis: list = list(map(lambda _: randint(0, 1), range(len(case.listeEnnemis))))

    # Sert à vérifier si la capacité spéciale du squelette a été utilisée pour ne pas la réutiliser
    capaciteSpecialeUtilisee: bool = False

    boite.afficher(ecran, "Utilisez une carte\nou\nchoisissez une action")
    pygame.time.delay(500)

    while not combatTermine:
        # Copie de la liste des ennemis au cas où elle est modifiée
        copieListeEnnemis: list[Ennemi] = case.listeEnnemis.copy()
        # Tour du joueur
        if tourJoueur:
            if joueur.isIA:
                i = joueur.choisircible(case)
                if joueur.niveau_difficulte == 3:
                    choixia,i = joueur.choosefightIA3(joueur,copieListeEnnemis)
                else:
                    choixia = joueur.choosefightIA(carteJouee, copieListeEnnemis[i])
                if len(barreLaterale.widgetCartes) > 0:
                    indexWidgetSelectionne = random.randint(0,len(barreLaterale.widgetCartes)-1)
                if choixia[0] == "attaque" or choixia[0] == "critique":
                    indexWidgetSelectionne = -1
                    #i = random.randint(0,len(case.listeEnnemis)-1)
                    if choixia[0] == "attaque":
                        degatJoueur: int = randint(int(joueur.attaque*0.85), joueur.attaque) - copieListeEnnemis[i].defense - listeActionsEnnemis[i]*2
                    elif choixia[0] == "critique":
                        degatJoueur: int = joueur.attaque*2 - (copieListeEnnemis[i].defense//2)
                    # Application des dégats et vérification de la réussite du coup critique
                    if choixia[0] == "attaque" or (choixia[0] == "critique" and randint(0, 100) < joueur.vitesse*3-copieListeEnnemis[i].vitesse):
                        copieListeEnnemis[i].pointDeVie -= degatJoueur if degatJoueur > 0 else 1
                        donneesJoueurActuel["degatsTotaux"] += degatJoueur if degatJoueur > 0 else 1
                        donneesJoueurActuel["nbAttaquesReussies"] += 1
                        boite.afficher(ecran, f"Vous infligez\n{degatJoueur if degatJoueur > 0 else 1} dégât"+("s" if degatJoueur > 1 else "")+f" à\n{copieListeEnnemis[i].nom.replace('_', ' ')} !")
                    else:
                        donneesJoueurActuel["nbAttaquesRatees"] += 1
                        boite.afficher(ecran, f"Vous ratez votre\nattaque critique !")
                        EffetTemporaire(joueur, operator.truediv, 2, 1, "defense", operator.mul, 2)
                    pygame.time.delay(500)
                    joueur.animation("attaque", ecran, ecranCombat.emplacementJoueur)
                    updateAffichageCombat(ecran, barreLaterale, ecranCombat, [boutonAttaque, boutonCritique, boutonCarte],
                                            boite, case, joueurActuel, carteJouee, indexWidgetSelectionne)
                    pygame.time.delay(500)

                    # Si l'ennemi est mort, on l'enlève de la liste des ennemis et on donne le tour à l'ennemi
                    variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)] = donneesJoueurActuel
                    combatTermine = mortEnnemi(ecran, ecranCombat, boite, plat, case, joueurActuel, copieListeEnnemis, i, capaciteSpecialeUtilisee)
                    donneesJoueurActuel = variables_globales.donnees_joueurs[f"joueur_{joueurActuel+1}"]
                    tourJoueur = False
                    attaque = False
                    
                elif choixia[0] == "capaciteSpeciale" and carteJouee == False:
                    
                    #capaciteIA = barreLaterale.widgetCartes[indexWidgetSelectionne-1].nom
                    capaciteIA = choixia[1]
                    if capaciteIA == "Fleche neutralisante":
                        donneesJoueurActuel["nbCapacitesUtilisees"] += 1
                        boite.afficher(ecran, "Vous étourdissez\nl'ennemi pendant\n1 tour !")
                        pygame.time.delay(500)
                        joueur.animation("attaque", ecran, ecranCombat.emplacementJoueur)
                        degatJoueur: int = randint(int(joueur.attaque*0.75), joueur.attaque)
                        copieListeEnnemis[i].pointDeVie -= degatJoueur if degatJoueur > 0 else 1
                        joueur.capaciteDisponible = False
                        donneesJoueurActuel["degatsTotaux"] += degatJoueur if degatJoueur > 0 else 1
                        
                    elif capaciteIA == "Farce":
                        donneesJoueurActuel["nbCapacitesUtilisees"] += 1
                        degatJoueur: int = randint(int(copieListeEnnemis[i].attaque*0.75), copieListeEnnemis[i].attaque)
                        boite.afficher(ecran, f"L'ennemi s'inflige\n{degatJoueur} dégât"+("s" if degatJoueur > 1 else "")+" à lui-même !")
                        pygame.time.delay(500)
                        copieListeEnnemis[i].animation("attaque", ecran, ecranCombat.emplacementEnnemis[i])
                        copieListeEnnemis[i].pointDeVie -= degatJoueur if degatJoueur > 0 else 1
                        joueur.capaciteDisponible = False
                    
                    elif capaciteIA == "Enchantement":
                        donneesJoueurActuel["nbCapacitesUtilisees"] += 1
                        boite.afficher(ecran, "Vous vous êtes\nenchanté !")
                        pygame.time.delay(500)  
                        attaque = False
                        Effet(joueur, 5, "pointDeVie", operator.add).appliquerEffet()
                        EffetTemporaire(joueur, operator.add, 2, 2, "attaque", operator.sub, 2)
                        EffetTemporaire(joueur, operator.add, 2, 2, "defense", operator.sub, 2)
                        EffetTemporaire(joueur, operator.add, 2, 2, "vitesse", operator.sub, 2)
                        joueur.capaciteDisponible = False
                        carteJouee = True
                        boite.afficher(ecran, "Choisissez une action")
                        pygame.time.delay(500)
                        indexWidgetSelectionne = -1
                    # Si la carte est une capacité spéciale de type Parade, on applique l'effet sur l'ennemi
                    elif capaciteIA == "Parade":
                        donneesJoueurActuel["nbCapacitesUtilisees"] += 1
                        boite.afficher(ecran, "Vous préparez une\nparade !")
                        pygame.time.delay(500)
                        attaque = False
                        critique = False
                        capaciteSpeciale = "Parade"
                        joueur.capaciteDisponible = False
                        tourJoueur = False
                        indexWidgetSelectionne = -1
                        pygame.time.delay(1000)
                        
                    elif capaciteIA not in ["Parade", "Fleche neutralisante", "Enchantement", "Farce"]:
                        temporaire = False
                        for t in range (0, len(joueur.cartes)):
                            if joueur.cartes[t].nom == capaciteIA and temporaire == False:
                                temporaire = True
                                indexWidgetSelectionne = t
                            if capaciteIA == "Fiole ATQ" and joueur.cartes[t].nom == "Fiole_ATQ":
                                temporaire = True
                                indexWidgetSelectionne = t
                        ###ERREUR PARFOIS    
                        if temporaire:    
                            donneesJoueurActuel["nbCartesJouees"] += 1
                            boite.afficher(ecran, f"Vous avez utilisé\nla carte {capaciteIA} !")
                            pygame.time.delay(500)
                            joueur.cartes[indexWidgetSelectionne].utiliser(None)
                            joueur.cartes.pop(indexWidgetSelectionne)
                            carteJouee = True
                        else : 
                            boite.afficher(ecran, "Vous n'avez pas\ncette carte")
                        pygame.time.delay(500)
                        boite.afficher(ecran, "Choisissez une action")
                        pygame.time.delay(500)
                        indexWidgetSelectionne = -1

                    if copieListeEnnemis[i].est_mort():
                        variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)] = donneesJoueurActuel
                        combatTermine = mortEnnemi(ecran, ecranCombat, boite, plat, case, joueurActuel, copieListeEnnemis, i, capaciteSpecialeUtilisee)
                        donneesJoueurActuel = variables_globales.donnees_joueurs[f"joueur_{joueurActuel+1}"]
                    else:
                        cibleCapacite = i
                        
                    # On terminer le tour du joueur
                    tourJoueur = False
                    joueur.capaciteDisponible = False
                    capaciteSpeciale = ""
                    
                    


                
            
            else :
                # On vérifie si le joueur a cliqué sur un bouton
                for event in pygame.event.get():
                    keys = pygame.key.get_pressed()
                    if (keys[pygame.K_LALT] or keys[pygame.K_RALT]) and keys[pygame.K_F4]:
                        pygame.quit()
                    if event.type == pygame.MOUSEBUTTONDOWN:

                        # Vérification de la sélection des cartes
                        for i in range(len(barreLaterale.widgetCartes)):
                            if barreLaterale.widgetCartes[i].estClique():
                                # Si oui, on enlève l'état selectionné à toutes les cartes et on l'ajoute à celle qui a été cliquée
                                indexWidgetSelectionne = i

                        # Vérification de la sélection des ennemis lors d'une attaque
                        for i in range(len(case.listeEnnemis)):
                            if pygame.Rect(400+ecranCombat.emplacementEnnemis[i][0]-(copieListeEnnemis[i].dimension[0]*copieListeEnnemis[i].scaling)/2,
                                        ecranCombat.emplacementEnnemis[i][1], copieListeEnnemis[i].dimension[0]*copieListeEnnemis[i].scaling,
                                        copieListeEnnemis[i].dimension[1]*copieListeEnnemis[i].scaling).collidepoint(pygame.mouse.get_pos()):

                                # Si la joueur attaque, on applique les dégâts à l'ennemi et on donne le tour à l'ennemi
                                if attaque or critique:
                                    if attaque:
                                        degatJoueur: int = randint(int(joueur.attaque*0.85), joueur.attaque) - copieListeEnnemis[i].defense - listeActionsEnnemis[i]*2
                                    elif critique:
                                        degatJoueur: int = joueur.attaque*2 - (copieListeEnnemis[i].defense//2)
                                    # Application des dégats et vérification de la réussite du coup critique
                                    if attaque or (critique and randint(0, 100) < joueur.vitesse*3-copieListeEnnemis[i].vitesse):
                                        donneesJoueurActuel["degatsTotaux"] += degatJoueur if degatJoueur > 0 else 1
                                        donneesJoueurActuel["nbAttaquesReussies"] += 1
                                        copieListeEnnemis[i].pointDeVie -= degatJoueur if degatJoueur > 0 else 1
                                        boite.afficher(ecran, f"Vous infligez\n{degatJoueur if degatJoueur > 0 else 1} dégât"+("s" if degatJoueur > 1 else "")+f" à\n{copieListeEnnemis[i].nom.replace('_', ' ')} !")
                                    else:
                                        donneesJoueurActuel["nbAttaquesRatees"] += 1
                                        boite.afficher(ecran, f"Vous ratez votre\nattaque critique !")
                                        EffetTemporaire(joueur, operator.truediv, 2, 1, "defense", operator.mul, 2)
                                    joueur.animation("attaque", ecran, ecranCombat.emplacementJoueur)
                                    updateAffichageCombat(ecran, barreLaterale, ecranCombat, [boutonAttaque, boutonCritique, boutonCarte],
                                                            boite, case, joueurActuel, carteJouee, indexWidgetSelectionne)

                                    # Si l'ennemi est mort, on l'enlève de la liste des ennemis et on donne le tour à l'ennemi
                                    variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)] = donneesJoueurActuel
                                    combatTermine = mortEnnemi(ecran, ecranCombat, boite, plat, case, joueurActuel, copieListeEnnemis, i, capaciteSpecialeUtilisee)
                                    donneesJoueurActuel = variables_globales.donnees_joueurs[f"joueur_{joueurActuel+1}"]
                                    tourJoueur = False
                                    attaque = False
                                # Si le joueur utilise une capacité spéciale de type Fleche neutralisante ou Farce, on applique les dégâts à l'ennemi
                                # et on donne le tour à l'ennemi
                                elif capaciteSpeciale != "":
                                    if capaciteSpeciale.replace("\n", " ") == "Fleche neutralisante":
                                        donneesJoueurActuel["nbCapacitesUtilisees"] += 1
                                        boite.afficher(ecran, "Vous étourdissez\nl'ennemi pendant\n1 tour !")
                                        joueur.animation("attaque", ecran, ecranCombat.emplacementJoueur)
                                        degatJoueur: int = randint(int(joueur.attaque*0.75), joueur.attaque)
                                    elif capaciteSpeciale == "Farce":
                                        donneesJoueurActuel["nbCapacitesUtilisees"] += 1
                                        degatJoueur: int = randint(int(copieListeEnnemis[i].attaque*0.75), copieListeEnnemis[i].attaque)
                                        boite.afficher(ecran, f"L'ennemi s'inflige\n{degatJoueur} dégât"+("s" if degatJoueur > 1 else "")+" à lui-même !")
                                        copieListeEnnemis[i].animation("attaque", ecran, ecranCombat.emplacementEnnemis[i])
                                    copieListeEnnemis[i].pointDeVie -= degatJoueur if degatJoueur > 0 else 1
                                    donneesJoueurActuel["degatsTotaux"] += degatJoueur if degatJoueur > 0 else 1

                                # On déselectionne la carte
                                break

                                    

                        # Vérification de la sélection des boutons
                        if boutonAttaque.estClique():
                            capaciteSpeciale = ""
                            attaque = True
                            critique = False
                            indexWidgetSelectionne = -1
                            boite.afficher(ecran, "Choisissez une cible")

                        elif boutonCritique.estClique():
                            capaciteSpeciale = ""
                            attaque = False
                            critique = True
                            indexWidgetSelectionne = -1
                            boite.afficher(ecran, "Choisissez une cible")

                        elif boutonCarte.estClique():
                            for widget in barreLaterale.widgetCartes:
                                if widget._selectionne == True and carteJouee == False:
                                    # On vérifie si la carte n'est pas une capacité spéciale
                                    if widget.nom.replace("\n", " ") not in ["Parade", "Fleche neutralisante", "Enchantement", "Farce"]:
                                        donneesJoueurActuel["nbCartesJouees"] += 1
                                        boite.afficher(ecran, f"Vous avez utilisé\nla carte {widget.nom} !")
                                        pygame.time.delay(1000)
                                        joueur.cartes[widget.index].utiliser(None)
                                        joueur.cartes.pop(widget.index)
                                        carteJouee = True
                                        boite.afficher(ecran, "Choisissez une action")
                                        indexWidgetSelectionne = -1
                                    # Si la carte est une capacité spéciale de type Enchantement, on applique l'effet sur le joueur
                                    elif widget.nom == "Enchantement":
                                        donneesJoueurActuel["nbCapacitesUtilisees"] += 1
                                        boite.afficher(ecran, "Vous vous êtes\nenchanté !")
                                        pygame.time.delay(1000)
                                        attaque = False
                                        Effet(joueur, 5, "pointDeVie", operator.add).appliquerEffet()
                                        EffetTemporaire(joueur, operator.add, 2, 2, "attaque", operator.sub, 2)
                                        EffetTemporaire(joueur, operator.add, 2, 2, "defense", operator.sub, 2)
                                        EffetTemporaire(joueur, operator.add, 2, 2, "vitesse", operator.sub, 2)
                                        joueur.capaciteDisponible = False
                                        carteJouee = True
                                        boite.afficher(ecran, "Choisissez une action")
                                        indexWidgetSelectionne = -1
                                    # Si la carte est une capacité spéciale de type Parade, on applique l'effet sur l'ennemi
                                    elif widget.nom == "Parade":
                                        donneesJoueurActuel["nbCapacitesUtilisees"] += 1
                                        boite.afficher(ecran, "Vous préparez une\nparade !")
                                        pygame.time.delay(1000)
                                        attaque = False
                                        critique = False
                                        capaciteSpeciale = widget.nom
                                        joueur.capaciteDisponible = False
                                        tourJoueur = False
                                        indexWidgetSelectionne = -1
                                    # Si la carte est une capacité spéciale de type Farce ou Flèche neutralisante, on demande à
                                    # l'utilisateur de choisir une cible
                                    else:
                                        attaque = False
                                        critique = False
                                        boite.afficher(ecran, "Choisissez une cible")
                                        capaciteSpeciale = widget.nom

                                    # On déselectionne la carte
                                    break
                    
                        elif boutonFuite.estClique():
                            donneesJoueurActuel["nbCombatsFuis"] += 1
                            boite.afficher(ecran, "Vous prenez la fuite")
                            pygame.time.delay(1000)
                            if joueur.argent>= 10:
                                combatTermine = True
                                joueur.argent -= 10
                            else:
                                boite.afficher(ecran, "Vous ne pouvez pas\nprendre la fuite")

                        elif boutonRetour.estClique():
                            menuPause()

        # Tour ennemis
        else:
            copieListeEnnemis: list[Ennemi] = case.listeEnnemis.copy()
            boite.afficher(ecran, "Tour de l'ennemi")
            for i in range(len(copieListeEnnemis)):
                # L'ennemi a 50% de chance d'attaquer et 50% de chance de se défendre (0 = attaque, 1 = défense)
                # Un ennemi ciblé par les capacités Flecne neutralisante ou Farce ne peut pas attaquer
                if i != cibleCapacite:
                    if listeActionsEnnemis[i] == 0:
                        boite.afficher(ecran, f"{copieListeEnnemis[i].nom.replace('_', ' ')}\nattaque !")
                        copieListeEnnemis[i].animation("attaque", ecran, ecranCombat.emplacementEnnemis[i], retourne=True)
                        # Si l'ennemi attaque et que le joueur a utilisé la capacité Parade, on applique les dégâts à l'ennemi
                        if capaciteSpeciale == "Parade":
                            degatsennemi = 2*randint(int(joueur.attaque*0.75), joueur.attaque)
                            donneesJoueurActuel["degatsTotaux"] += degatsennemi
                            donneesJoueurActuel["nbAttaquesReussies"] += 1
                            boite.afficher(ecran, f"Vous parez et infligez\n{degatsennemi} dégâts\nà {copieListeEnnemis[i].nom.replace('_', ' ')} !")
                            joueur.animation("attaque", ecran, ecranCombat.emplacementJoueur)
                            case.listeEnnemis[i].pointDeVie -= degatsennemi
                            updateAffichageCombat(ecran, barreLaterale, ecranCombat, [boutonAttaque, boutonCritique, boutonCarte],
                                                    boite, case, joueurActuel, carteJouee, indexWidgetSelectionne)
                            capaciteSpeciale = ""
                            variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)] = donneesJoueurActuel
                            combatTermine = mortEnnemi(ecran, ecranCombat, boite, plat, case, joueurActuel, copieListeEnnemis, i, capaciteSpecialeUtilisee)
                            donneesJoueurActuel = variables_globales.donnees_joueurs[f"joueur_{joueurActuel+1}"]
                        # Sinon, on calcule les dégâts subis par le joueur et sa chance d'esquive
                        else:
                            if not copieListeEnnemis[i].est_mort():
                                degatEnnemi: int = int(randint(int(copieListeEnnemis[i].attaque*0.75), copieListeEnnemis[i].attaque) - joueur.defense)
                                esquive: int = randint(0, 100)
                                difference_vitesse: int = joueur.vitesse - copieListeEnnemis[i].vitesse
                                if difference_vitesse > 0:
                                    esquive += randint(0, difference_vitesse)
                                elif difference_vitesse < 0:
                                    esquive -= randint(0, -difference_vitesse)
                                if esquive <= 75:
                                    donneesJoueurActuel["degatsRecus"] += degatEnnemi if degatEnnemi > 0 else 1
                                    joueur.pointDeVie -= degatEnnemi if degatEnnemi > 0 else 1
                                    boite.afficher(ecran, f"{copieListeEnnemis[i].nom.replace('_', ' ')}\nvous inflige {degatEnnemi if degatEnnemi > 0 else 1} dégât"+("s" if degatEnnemi > 1 else "")+" !")
                                    updateAffichageCombat(ecran, barreLaterale, ecranCombat, [boutonAttaque, boutonCritique, boutonCarte],
                                                            boite, case, joueurActuel, carteJouee, indexWidgetSelectionne)
                                    pygame.time.delay(1000)

                                    # CAPACITE SPECIALE ENNEMI : Vérification pour la capacité spéciale de l'araignée
                                    if copieListeEnnemis[i].nom == "Araignee" and copieListeEnnemis[i].niveau >= 4 and randint(0, 100) <= 20:
                                        donneesJoueurActuel["degatsRecus"] += 2
                                        boite.afficher(ecran, "L'araignée vous a empoisonné !")
                                        EffetTemporaire(joueur, operator.sub, 1, 2, "pointDeVie", None, None, True)

                                    # CAPACITE SPECIALE ENNEMI : Vérification pour la capacité spéciale du voleur
                                    if copieListeEnnemis[i].nom == "Voleur" and len(joueur.cartes) > 0:
                                        chance = 5 + 5*(1 if copieListeEnnemis[i].niveau >= 4 else 0)
                                        if randint(0, 100) <= chance:
                                            choix = randint(1,3)
                                            if ((choix == 1 or joueur.argent == 0) and len(joueur.cartes)):
                                                indexCarte = randint(0, len(joueur.cartes)-1)
                                                boite.afficher(ecran, f"Le voleur vous a volé\nla carte {joueur.cartes[indexCarte].nom} !")
                                                updateAffichageCombat(ecran, barreLaterale, ecranCombat, [boutonAttaque, boutonCritique, boutonCarte],
                                                                        boite, case, joueurActuel, carteJouee, indexWidgetSelectionne)
                                                joueur.cartes.pop(indexCarte)
                                            elif ((choix > 1 or len(joueur.cartes)) and joueur.argent > 0):
                                                argentVole = randint(1, 5)
                                                boite.afficher(ecran, f"Le voleur vous a volé\n{argentVole} pièce"+("s" if argentVole > 1 else "")+" !")
                                                updateAffichageCombat(ecran, barreLaterale, ecranCombat, [boutonAttaque, boutonCritique, boutonCarte],
                                                                        boite, case, joueurActuel, carteJouee, indexWidgetSelectionne)
                                                joueur.argent -= argentVole
                                else:
                                    boite.afficher(ecran, f"{copieListeEnnemis[i].nom.replace('_', ' ')} a raté\nson attaque !")
                                    pygame.time.delay(1000)
                    else:
                        # CAPACITE SPECIALE ENNEMI : Vérification pour la capacité spéciale de la sorcière
                        if copieListeEnnemis[i].nom == "Sorciere" and copieListeEnnemis[i].niveau >= 4:
                            copieListeEnnemis[i].pointDeVie += 2
                            boite.afficher(ecran, "La sorcière récupère\n2 points de vie !")
                            updateAffichageCombat(ecran, barreLaterale, ecranCombat, [boutonAttaque, boutonCritique, boutonCarte],
                                                    boite, case, joueurActuel, carteJouee, indexWidgetSelectionne)
                            pygame.time.delay(1000)

                    # CAPACITE SPECIALE ENNEMI : Vérication pour la capacité spéciale du boss
                    if copieListeEnnemis[i].nom == "Boss_Squelette":
                        # Le boss a 10% de chance de faire appparaitre un squelette après avoir perdu 25% de ses PV
                        if len(case.listeEnnemis) < 4 and case.listeEnnemis[0].pointDeVie < case.listeEnnemis[0].pointDeVieMax*0.75 and randint(0, 100) < 10:
                            case.listeEnnemis.append(TypesEnnemi.Squelette.creerEnnemi(joueur.niveauEnnemisRencontres))
                            boite.afficher(ecran, "Le boss invoque\nun squelette !")
                            case.listeEnnemis[-1].animation("mort", ecran, ecranCombat.emplacementEnnemis[len(case.listeEnnemis)-1], True, True)


                # CAPACITE SPECIALE ENNEMI : Vérification pour la capacité spéciale du zombie
                if copieListeEnnemis[i].nom == "Zombie" and copieListeEnnemis[i].niveau >= 4 and randint(0, 100) <= 50:
                    copieListeEnnemis[i].pointDeVie += 1

            # On vérifie si le joueur est mort
            if joueur.est_mort():
                boite.afficher(ecran, "Vous êtes vaincu !")
                joueur.animation("mort", ecran, ecranCombat.emplacementJoueur)
                combatTermine = True


            # Réinitialisation des variables pour le tour suivant
            capaciteSpeciale = ""
            cibleCapacite = -1
            carteJouee = False
            attaque = False
            critique = False
            listeActionsEnnemis = list(map(lambda _: randint(0, 1), range(len(case.listeEnnemis))))
            boite.afficher(ecran, "Utilisez une carte\nou\nchoisissez une action")
            tourJoueur = True

            # On décompte tous les compteurs actifs
            Compteur.decompterAll()

        # Mise à jour de l'affichage
        updateAffichageCombat(ecran, barreLaterale, ecranCombat, [boutonAttaque, boutonCritique, boutonCarte , boutonFuite , boutonRetour],
                                boite, case, joueurActuel, carteJouee, indexWidgetSelectionne)

        clock.tick(60)
        
    # Sauvegarde des données du joueur
    variables_globales.donnees_joueurs[f"joueur_{joueurActuel+1}"] = donneesJoueurActuel
    json.dump(variables_globales.donnees_joueurs, open(constant.REPERTOIRE_COURANT+"/donnees_joueurs.json", "w"), indent=4)