import plateau, json, constant, variables_globales
from boucles.fonctions.gainCarteJoueur import gainCarteJoueur
from case.Case import Case
from personnage.Ennemi import Ennemi
from personnage.Joueur import Joueur
from widgets.BoiteDeDialogue import BoiteDeDialogue
from widgets.EcranCombat import EcranCombat


import pygame


from random import randint


def mortEnnemi(ecran: pygame.Surface, ecranCombat: EcranCombat, boite: BoiteDeDialogue, plat: plateau.Plateau,
               case: Case, joueurActuel: int, listeEnnemis: list[Ennemi], indexEnnemi: int,
               capaciteSpecialeUtilisee: bool) -> bool:
    """
    Vérifie si l'ennemi est mort et effectue les actions nécessaires si c'est le cas.

    Args:
     - ecran (pygame.Surface): L'écran servant à l'affichage.
     - ecranCombat (EcranCombat): L'écran de combat.
     - boite (BoiteDeDialogue): La boîte de dialogue pour afficher les messages.
     - plat (plateau.Plateau): Le plateau de jeu.
     - case (Case): La case sur laquelle se déroule le combat.
     - joueurActuel (int): L'indice du joueur actuel.
     - copieListeEnnemis (list[Ennemi]): La liste des ennemis sur la case.
     - indexEnnemi (int): L'indice de l'ennemi à vérifier.
     - capaciteSpecialeUtilisee (bool): Indique si la capacité spéciale du Squelette a été utilisée.

    Returns:
        bool: True si le combat est terminé, False sinon.
    """
    donneesJoueurActuel = variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)]
    if listeEnnemis[indexEnnemi].est_mort():
        joueur = Joueur.getAllJoueur()[joueurActuel]
        boite.afficher(ecran, f"Vous avez vaincu\n{listeEnnemis[indexEnnemi].nom.replace('_', ' ')} !")
        listeEnnemis[indexEnnemi].animation("mort", ecran, ecranCombat.emplacementEnnemis[indexEnnemi], retourne=True)

        # CAPACITE SPECIALE ENNEMI : Vérification pour la capacité spéciale du Squelette
        if listeEnnemis[indexEnnemi].nom == "Squelette" and randint(0, 100) <= 20 and listeEnnemis[indexEnnemi].niveau >= 4 and not capaciteSpecialeUtilisee:
            listeEnnemis[indexEnnemi].pointDeVie = listeEnnemis[indexEnnemi].pointDeVieMax//2
            boite.afficher(ecran, f"{listeEnnemis[indexEnnemi].nom} est revenu\nà la vie !")
            listeEnnemis[indexEnnemi].animation("mort", ecran, ecranCombat.emplacementEnnemis[indexEnnemi], retourne=True, inverse=True)
            capaciteSpecialeUtilisee = True
        else:
            # joueur.pointDeVie += 2
            joueur.nbEnnemisVaincus += 1
            donneesJoueurActuel["nbEnnemisTues"] = joueur.nbEnnemisVaincus
            donneesJoueurActuel["argentGagne"] += listeEnnemis[indexEnnemi].gainArgent
            joueur.pointExperience += int(listeEnnemis[indexEnnemi].gainExperience * (joueur.niveauEnnemisRencontres/joueur.niveau))
            joueur.argent += listeEnnemis[indexEnnemi].gainArgent
            print(joueur.argent)
            case.listeEnnemis.pop(indexEnnemi)
            gainCarteJoueur(ecran, boite, plat, joueurActuel)

        if len(case.listeEnnemis) == 0:
            donneesJoueurActuel["nbCombatsGagnes"] += 1
            boite.afficher(ecran, "Le combat est terminé !")
            pygame.time.delay(1000)
            
            # sauvegarde des données du joueur
            variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)] = donneesJoueurActuel
            json.dump(variables_globales.donnees_joueurs, open(constant.REPERTOIRE_COURANT+"/donnees_joueurs.json", "w"), indent=4)
            
            return True
        return False