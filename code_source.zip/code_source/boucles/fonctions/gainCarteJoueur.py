# Fonctions de gestion des boucles de jeu
import plateau
from cartes.ListeCartes import ListeCartes
from personnage.Joueur import Joueur
from widgets.BoiteDeDialogue import BoiteDeDialogue


import pygame


def gainCarteJoueur(ecran: pygame.Surface, boite: BoiteDeDialogue, plat: plateau.Plateau, joueurActuel: int):
    """
    Ajoute une nouvelle carte aléatoire au joueur actuel s'il a moins de 10 cartes dans sa main.

    Args:
     - ecran (pygame.Surface): La surface de l'écran.
     - boite (BoiteDeDialogue): La boîte de dialogue pour afficher les messages.
     - plat (plateau.Plateau): Le plateau de jeu.
     - joueurActuel (int): L'indice du joueur actuel.
    """
    joueur = Joueur.getAllJoueur()[joueurActuel]
    if len(joueur.cartes) < 10:
        while not joueur.nouvelleCarte(ListeCartes.genererCarteAleatoire(plat, joueurActuel)):
            pass
        boite.afficher(ecran, f"Vous avez obtenu\nla carte {joueur.cartes[-1].nom.replace('_', ' ')} !")
        pygame.time.delay(1000)