

from plateau import Plateau
from widgets.CaseCliquable import CaseCliquable
from widgets.De6 import De6
from widgets.Bouton import Bouton
from widgets.ObjetAnime import ObjetAnime
from widgets.BarreLaterale import BarreLaterale
from widgets.BoiteDeDialogue import BoiteDeDialogue
from widgets.InfoJoueurs import InfoJoueurs
from affichage.updateAffichage import updateAffichage
from personnage.Joueur import Joueur
from menus.menuPause import menuPause

import pygame

def boucleChoixDeplacement(ecran: pygame.Surface, plat: Plateau, de1: De6, boutonPause : Bouton , boutonDe: Bouton, boutonMagasin: Bouton, feudecamp: ObjetAnime, portail: ObjetAnime, barre_lat: BarreLaterale, boite: BoiteDeDialogue, infoJoueurs: InfoJoueurs, joueurActuel: int, nbCartesJouees: int, index_widget_select: int, choixDeplacement: bool):
    choix = None
    
    while choix is None:
        for event in pygame.event.get():
            keys = pygame.key.get_pressed()
            if ((keys[pygame.K_LALT] or keys[pygame.K_RALT]) and keys[pygame.K_F4]) or event.type == pygame.QUIT:
                pygame.quit()
                
            if event.type == pygame.QUIT:
                pygame.quit()

            # Si pygame détecte un clic
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.type == pygame.QUIT:
                    pygame.quit()
                    
                elif CaseCliquable.getCaseClick() is not None:
                    if plat.listeCases[CaseCliquable.getCaseClick()].deplacementPossible:
                        choix = CaseCliquable.getCaseClick()
                        break
        
            if boutonPause.estClique():
                menuPause(ecran, plat, False, False)
        if choix is None:
            updateAffichage(ecran, plat, de1, boutonPause , boutonDe, boutonMagasin, feudecamp, portail, barre_lat, boite, infoJoueurs, joueurActuel, nbCartesJouees, index_widget_select, choixDeplacement)
            
    return (choix - Joueur.getAllJoueur()[joueurActuel].emplacement) % len(plat.listeCases)