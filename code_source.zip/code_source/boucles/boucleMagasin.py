
from personnage.Joueur import Joueur
from cartes.TypeCarte import TypeCarte
from widgets.PageMagasin import PageMagasin
from widgets.BarreLateraleMagasin import BarreLateraleMagasin, AffichageBarreLaterale
from plateau import Plateau
import pygame, json, constant, variables_globales

def boucleMagasin(ecran: pygame.Surface, plat: Plateau, joueurActuel: int):
    donneesJoueurActuel = variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)]
    barre_lat = BarreLateraleMagasin()
    pageMagasin = PageMagasin(plat, joueurActuel)
    pageMagasin.bouton.actif = True
    affichageBarreLat: AffichageBarreLaterale = AffichageBarreLaterale.PLATEAU
    selected: int = None
    selectedInBarLat: bool = False
    selectedInStats: bool = False
    
    barre_lat.afficher(ecran, joueurActuel, selected if selectedInBarLat == True else None, False)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            elif event.type == pygame.MOUSEBUTTONDOWN:
                mouse_pos: tuple[int, int] = (pygame.mouse.get_pos()[0]-400, pygame.mouse.get_pos()[1])
                for i in range(len(pageMagasin.widgets)):
                    if pageMagasin.widgets[i][0].estClique(mouse_pos) and Joueur.getAllJoueur()[joueurActuel].argent >= pageMagasin.cartes[i].valeur:
                        if (pageMagasin.cartes[i].typeCarte in [TypeCarte.Plateau, TypeCarte.Case, TypeCarte.Utilisable, TypeCarte.Placable] and Joueur.getAllJoueur()[joueurActuel].nombreCartePlateau() < 5) or (pageMagasin.cartes[i].typeCarte == TypeCarte.Consommable and Joueur.getAllJoueur()[joueurActuel].nombreCarteCombat() < 5):    
                            selected = i
                            selectedInBarLat = False
                            selectedInStats = False
                            pageMagasin.bouton.actif = False
                        
                for i in range(len(barre_lat.widgetCartes)):
                    if barre_lat.widgetCartes[i].estClique():
                        selectedInBarLat = True
                        selectedInStats = False
                        pageMagasin.bouton.actif = False
                        selected = i
                            
                for i in range(len(pageMagasin.boutonsStats)):
                    if pageMagasin.boutonsStats[i][0].estClique(mouse_pos) and Joueur.getAllJoueur()[joueurActuel].argent >= pageMagasin.boutonsStats[i][0].prix:
                        selected = i
                        selectedInBarLat = False
                        selectedInStats = True
                        pageMagasin.bouton.actif = False
                    
                
                for j in range(len(barre_lat.widgetCartes)):
                    barre_lat.widgetCartes[j].selectionne = True if j == selected and selectedInBarLat == True and selectedInStats == False else False
                for j in range(len(pageMagasin.widgets)):
                    pageMagasin.widgets[j][0].selectionne = True if j == selected and selectedInBarLat == False and selectedInStats == False else False
                for j in range(len(pageMagasin.boutonsStats)):
                    pageMagasin.boutonsStats[j][0].selectionne = True if j == selected and selectedInBarLat == False and selectedInStats == True else False
                
                if barre_lat.boutonPlateau.estClique():
                    barre_lat.boutonPlateau.actif = True
                    barre_lat.boutonCombat.actif = False
                    barre_lat.boutonStatistiques.actif = False
                    affichageBarreLat = AffichageBarreLaterale.PLATEAU
                    
                if barre_lat.boutonCombat.estClique():
                    barre_lat.boutonPlateau.actif = False
                    barre_lat.boutonCombat.actif = True
                    barre_lat.boutonStatistiques.actif = False
                    affichageBarreLat = AffichageBarreLaterale.COMBAT
                    
                if barre_lat.boutonStatistiques.estClique():
                    barre_lat.boutonPlateau.actif = False
                    barre_lat.boutonCombat.actif = False
                    barre_lat.boutonStatistiques.actif = True
                    affichageBarreLat = AffichageBarreLaterale.STATS
                
                if pageMagasin.bouton.estClique(mouse_pos):
                    if selected != None:
                        if selectedInBarLat == False and selectedInStats == False:
                            donneesJoueurActuel["argentDepense"] += pageMagasin.cartes[selected].valeur
                            Joueur.getAllJoueur()[joueurActuel].payer(pageMagasin.cartes[selected].valeur)
                            Joueur.getAllJoueur()[joueurActuel].cartes.append(pageMagasin.cartes[selected])
                            pageMagasin.widgets[selected][1] = True
                        elif selectedInBarLat == False and selectedInStats == True:
                            donneesJoueurActuel["argentDepense"] += pageMagasin.boutonsStats[selected][0].prix
                            Joueur.getAllJoueur()[joueurActuel].payer(pageMagasin.boutonsStats[selected][0].prix)
                            pageMagasin.boutonsStats[selected][0].donnerBonus(Joueur.getAllJoueur()[joueurActuel])
                            pageMagasin.boutonsStats[selected][1] = True
                        else:
                            donneesJoueurActuel["argentGagne"] += int(Joueur.getAllJoueur()[joueurActuel].cartes[selected].valeur * 0.7)
                            selected = barre_lat.widgetCartes[selected].index
                            Joueur.getAllJoueur()[joueurActuel].argent += int(Joueur.getAllJoueur()[joueurActuel].cartes[selected].valeur * 0.7)
                            Joueur.getAllJoueur()[joueurActuel].cartes.pop(selected)
                            selectedInBarLat = False

                        selected = None
                        
                        for i in range(len(barre_lat.widgetCartes)):
                            barre_lat.widgetCartes[i].selectionne = False
                        for i in range(len(pageMagasin.widgets)):
                            pageMagasin.widgets[i][0].selectionne = False
                        for i in range(len(pageMagasin.boutonsStats)):
                            pageMagasin.boutonsStats[i][0].selectionne = False
                            
                        pageMagasin.bouton.actif = True
                            
                if pageMagasin.boutonQuitter.estClique(mouse_pos):
                    ecran.fill(pygame.Color(156,219,67))
                    
                    # Sauvegarde des données
                    variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)] = donneesJoueurActuel
                    json.dump(variables_globales.donnees_joueurs, open(constant.REPERTOIRE_COURANT+"/donnees_joueurs.json", "w"), indent=4)
                    return
        
        barre_lat.afficher(ecran, joueurActuel, selected if selectedInBarLat == True else None, affichageBarreLat, False)
        pageMagasin.afficher(ecran, selectedInBarLat)
        pygame.display.flip()
    