import json, variables_globales
from boucles.boucleCombat import boucleCombat
from boucles.boucleChoixDeplacement import boucleChoixDeplacement
import constant, plateau, menus.menuFinSolo as menuFinSolo
import menus.menuVictoireBoss as menuVictoireBoss
from affichage.initAffichageJeu import initAffichageJeu
from cartes.TypeCarte import TypeCarte
from cartes.ListeCartes import ListeCartes
from case.CaseSpeciale import CaseSpeciale
from affichage.updateAffichage import updateAffichage
from util.Compteur import Compteur
from personnage.Joueur import Joueur
from personnage.JoueurIA import JoueurIA
from personnage.TypesEnnemi import TypesEnnemi
from widgets.CaseCliquable import CaseCliquable
from affichage.affichageMortJoueur import affichageMortJoueur
import menus.menuPause as menuPause
from boucles.boucleMagasin import boucleMagasin

import pygame
from random import randint

def boucleJeu(ecran: pygame.Surface):
    """
    Gère la boucle de jeu nécessaire au bon déroulement de la partie.
    
    Args:
    - ecran: pygame.Surface - la surface sur laquelle le jeu est affiché
    """
    plat: plateau.Plateau = plateau.Plateau()

    # Donne une carte case à chaque joueur
    for joueur in Joueur.getAllJoueur():
        cartesCase: list[ListeCartes] = list(filter(lambda x: x.value[1] == TypeCarte.Case, list(ListeCartes)[1:]))
        joueur.cartes.append(cartesCase[randint(0, len(cartesCase)-1)].genererCarte(plat, 0))
    
    ecran.fill(pygame.Color(156,219,67))
    clock = pygame.time.Clock()
    # Initialisation de l'affichage
    de1, boutonPause , boutonDe, boutonMagasin, barre_lat, feudecamp, portail, boite, infoJoueurs = initAffichageJeu(ecran)
    
    if not Joueur.getAllJoueur()[0].isIA:
        boutonDe.afficher(ecran)
        boutonPause.afficher(ecran)

    solo: bool = False
    if len(Joueur.getAllJoueur()) == 1:
        solo = True

    # Variables utiles à la gestion de la boucle
    joueurActuel: int = 0
    joueur: Joueur = Joueur.getAllJoueur()[joueurActuel]
    tourTermine: bool = False
    partieTerminee: bool = False
    nbCartesJouees: int = 0   # Nombre de cartes utilisées par le joueur pendant son tour
    nb_deplacements: int = 0    # Nombre de déplacements que le joueur doit effectuer
    delai_depl: int             # Délai pour l'affichage du déplacement
    index_widget_select: int = -1
    joueurBossDebloque: list[int] = []
    choixDeplacement: bool = False
    variables_globales.donnees_joueurs = json.load(open(constant.REPERTOIRE_COURANT+"/donnees_joueurs.json", "r"))
    donneesJoueurActuel = variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)]

    updateAffichage(ecran, plat, de1, boutonPause, boutonDe, boutonMagasin, feudecamp, portail, barre_lat, boite, infoJoueurs, joueurActuel, nbCartesJouees, index_widget_select)

    while not partieTerminee:
        # On vérifie si un déplacement n'est pas en cours
        if nb_deplacements != 0:
                if delai_depl == 0:
                    # À la fin du délai on déplace le joueur
                    joueur.emplacement += 1
                    joueur.nbDeplacements += 1
                    donneesJoueurActuel["nbDeplacements"] += 1
                    if joueur.emplacement == constant.TAILLE_PLATEAU:
                        joueur.emplacement = 0
                    plat.listeCases[joueur.emplacement].deplacementPossible = False
                    Compteur.decompterAll() # Décompte de tous les compteurs actifs
                    

                    # Si la case sur laquelle se trouve le joueur est une case spéciale avec un effet, on donne l'effet au joueur
                    if isinstance(plat.listeCases[joueur.emplacement], CaseSpeciale):
                        if plat.listeCases[joueur.emplacement].effets != None:
                            plat.listeCases[joueur.emplacement].donnerEffet(joueurActuel)

                    if plat.listeCases[joueur.emplacement].piege == "bombe":
                        joueur.pointDeVie -= 2
                        donneesJoueurActuel["degatsRecus"] += 2
                        plat.listeCases[joueur.emplacement].piege = ""

                    if plat.listeCases[joueur.emplacement].piege == "piege_a_ours":
                        plat.listeCases[joueur.emplacement].piege = ""
                        nb_deplacements = 0
                    else:
                        nb_deplacements -= 1 # On réduit de 1 le nombre de déplacements à réaliser
                    delai_depl = 10

                    # On vérifie s'il y a un portail de boss sur la case et s'il appartient au joueur
                    if plat.listeCases[joueur.emplacement].portail and joueur.numero in plat.listeCases[joueur.emplacement].numeroJoueurPortail:
                        plat.listeCases[joueur.emplacement].listeEnnemis.append(TypesEnnemi.Boss_Squelette.creerEnnemi())
                        variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)] = donneesJoueurActuel
                        boucleCombat(ecran, barre_lat, plat, plat.listeCases[joueur.emplacement], joueurActuel)
                        donneesJoueurActuel = variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)]
                        ecran.fill(pygame.Color(156,219,67))

                        if joueur.est_mort():
                            plat.listeCases[joueur.emplacement].listeEnnemis = []
                            plat.listeCases[joueur.emplacement].portail = False
                            Joueur.getAllJoueur().pop(joueurActuel)
                            # Affiche un message disant que le joueur est mort pendant 3 secondes
                            affichageMortJoueur(ecran, joueur.nom)
                            ecran.fill(pygame.Color(156,219,67))

                        else:
                            # Menu de fin de partie en cas de victoire contre le boss
                            variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)] = donneesJoueurActuel
                            json.dump(variables_globales.donnees_joueurs, open(constant.REPERTOIRE_COURANT+"/donnees_joueurs.json", "w"), indent=4)
                            partieTerminee, tourTermine = menuVictoireBoss.menuVictoireBoss(ecran, plat, solo, joueurActuel, partieTerminee, tourTermine)
                            ecran.fill(pygame.Color(156,219,67))

                    # Lorsqu'il n'y a plus de déplacement à réaliser, on lance le combat si des ennemis sont présents puis
                    # on termine le tour
                    if nb_deplacements == 0:
                        if len(plat.listeCases[joueur.emplacement].listeEnnemis) > 0:
                            variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)] = donneesJoueurActuel
                            boucleCombat(ecran, barre_lat, plat, plat.listeCases[joueur.emplacement], joueurActuel)
                            donneesJoueurActuel = variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)]
                            ecran.fill(pygame.Color(156,219,67))

                        # On vérifie si le joueur est mort après le combat
                        if joueur.est_mort():
                            # Bloc if pour éviter les erreurs d'indexation (Le joueur peut déjà avoir été rétiré
                            # de la liste après un combat contre un boss)
                            if joueur in Joueur.getAllJoueur():
                                Joueur.getAllJoueur().pop(joueurActuel)
                            # Affiche un message disant que le joueur est mort pendant 3 secondes
                            affichageMortJoueur(ecran, joueur.nom)
                            ecran.fill(pygame.Color(156,219,67))

                        # Si le joueur n'est pas mort et que la case sur laquelle se trouve le joueur a un coffre,
                        # on lui donne les effets suivants
                        elif plat.listeCases[joueur.emplacement].coffre:
                            joueur.pointExperience += 10
                            joueur.pointDeVie += 5
                            for _ in range(2):
                                while not joueur.nouvelleCarte(ListeCartes.genererCarteAleatoire(plat, joueurActuel)):
                                    pass
                            plat.listeCases[joueur.emplacement].coffre = False

                        if joueur.niveau == 5 and joueur.numero not in joueurBossDebloque:
                            joueurBossDebloque.append(joueur.numero)
                            indexCase = (joueur.emplacement+constant.TAILLE_PLATEAU//2)%constant.TAILLE_PLATEAU
                            indexCase = indexCase if indexCase != 0 else 1
                            plat.ajouterPortail(indexCase, joueur.numero)

                        tourTermine = True
                else:
                    delai_depl -= 1
                    
        elif joueur.isIA:
            joueur: JoueurIA = joueur
            choix = joueur.jouer_aleatoire(2)
            if nbCartesJouees >= 2:
                choix = 1
            if choix == 1 :
                de1.afficherLancer(ecran)
                nb_deplacements = joueur.choosenbdeplacements(plat.listeCases,de1.valeur, joueur.emplacement,len(plat.listeCases))
                delai_depl = 30
            elif choix == 2 :
                index_widget_select = joueur.choosecardIA(len(barre_lat.widgetCartes)-1)
                caserandomIA= CaseCliquable.getCaseRandom()
                if caserandomIA not in [None, 0] and index_widget_select != -1:
                    indexcarteIA = joueur.choosecardIA(len(barre_lat.widgetCartes)-1)
                    ix = 0
                    for widget in barre_lat.widgetCartes:
                        if ix == indexcarteIA and nbCartesJouees < 2:

                            # Placement du piège à ours
                            if widget.nom == "Piege a ours":
                                if plat.listeCases[caserandomIA].piege == "":
                                    plat.listeCases[caserandomIA].piege = "piege_a_ours"
                                    joueur.capaciteDisponible = False
                                    nbCartesJouees += 1
                                    index_widget_select = -1
                                    break

                            # Placement de la bombe
                            elif widget.nom == "Bombe":
                                if plat.listeCases[caserandomIA].piege == "":
                                    # Si des ennemis sont sur la case, on les retire
                                    if len(plat.listeCases[caserandomIA].listeEnnemis) > 0:
                                        plat.listeCases[caserandomIA].listeEnnemis = []

                                    # Sinon si des joueurs son sur la case, on leur retire 2 points de vie
                                    elif caserandomIA in list(map(lambda x: x.emplacement, Joueur.getAllJoueur())):
                                        for j in Joueur.getAllJoueur():
                                            if j.emplacement == caserandomIA:
                                                j.pointDeVie -= 2
                                                if j.est_mort():
                                                    Joueur.getAllJoueur().pop(Joueur.getAllJoueur().index(j))
                                                    # Affiche un message disant que le joueur est mort pendant 3 secondes
                                                    affichageMortJoueur(ecran, joueur.nom)
                                                    ecran.fill(pygame.Color(156,219,67))

                                    # Sinon on place la bombe sur case
                                    else:
                                        joueur.cartes[widget.index].utiliser(caserandomIA)
                                    joueur.cartes.pop(widget.index)
                                    nbCartesJouees += 1
                                    index_widget_select = -1
                                    break
                            else:
                                # Vérification de la possibilité d'utiliser la carte sur la case en fonction des restrictions
                                # de chaque type de cartes
                                if not (joueur.cartes[widget.index].typeCarte in [TypeCarte.Case] and isinstance(plat.listeCases[caserandomIA], CaseSpeciale)) and not (joueur.cartes[widget.index].nom == "Demolition" and not isinstance(plat.listeCases[caserandomIA], CaseSpeciale)) and not (widget.nom == "Teleportation" and len(plat.listeCases[caserandomIA].listeEnnemis) > 0):
                                    joueur.cartes[widget.index].utiliser(caserandomIA)
                                    joueur.cartes.pop(widget.index)
                                    nbCartesJouees += 1
                                    index_widget_select = -1
                                    break
                        ix += 1
        testrandom = False
        if testrandom == True:
            pass

        # Si le joueur ne se déplace pas, on vérifie les évènements recueillis par pygame
        else:
            for event in pygame.event.get():
                keys = pygame.key.get_pressed()
                if ((keys[pygame.K_LALT] or keys[pygame.K_RALT]) and keys[pygame.K_F4]) or event.type == pygame.QUIT:
                    pygame.quit()

                if event.type == pygame.QUIT:
                    pygame.quit()
                    
                # Si pygame détecte un clic
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    # On vérifie si l'un des cartes a été cliquée
                    for i in range(len(barre_lat.widgetCartes)):
                        # barre_lat.widgetCartes[i]._selectionne = False
                        if barre_lat.widgetCartes[i].estClique():
                            # Si oui, on enlève l'état selectionné à toutes les cartes et on l'ajoute à celle qui a été cliquée
                            index_widget_select = i

                    # On vérifie si une des cases a été cliquée
                    if CaseCliquable.getCaseClick() not in [None, 0]:
                            # Si oui, on vérifie si une des cartes est sélectionnée et si oui on l'utilise sur la case en question
                            for widget in barre_lat.widgetCartes:
                                if widget._selectionne == True and nbCartesJouees < 2:

                                    # Placement du piège à ours
                                    if widget.nom == "Piege a ours":
                                        if plat.listeCases[CaseCliquable.getCaseClick()].piege == "":
                                            plat.listeCases[CaseCliquable.getCaseClick()].piege = "piege_a_ours"
                                            donneesJoueurActuel["nbCapacitesUtilisees"] += 1
                                            joueur.capaciteDisponible = False
                                            nbCartesJouees += 1
                                            index_widget_select = -1
                                            break

                                    # Placement de la bombe
                                    elif widget.nom == "Bombe":
                                        if plat.listeCases[CaseCliquable.getCaseClick()].piege == "":
                                            donneesJoueurActuel["nbCartesJouees"] += 1
                                            # Si des ennemis sont sur la case, on les retire
                                            if len(plat.listeCases[CaseCliquable.getCaseClick()].listeEnnemis) > 0:
                                                plat.listeCases[CaseCliquable.getCaseClick()].listeEnnemis = []

                                            # Sinon si des joueurs sont sur la case, on leur retire 2 points de vie
                                            elif CaseCliquable.getCaseClick() in list(map(lambda x: x.emplacement, Joueur.getAllJoueur())):
                                                for j in Joueur.getAllJoueur():
                                                    if j.emplacement == CaseCliquable.getCaseClick():
                                                        j.pointDeVie -= 2
                                                        variables_globales.donnees_joueurs["joueur_"+str(j.numero)]["degatsRecus"] += 2
                                                        donneesJoueurActuel["degatsTotaux"] += 2
                                                        if j.est_mort():
                                                            Joueur.getAllJoueur().pop(Joueur.getAllJoueur().index(j))
                                                            # Affiche un message disant que le joueur est mort pendant 3 secondes
                                                            affichageMortJoueur(ecran, joueur.nom)
                                                            ecran.fill(pygame.Color(156,219,67))

                                            # Sinon on place la bombe sur case
                                            else:
                                                joueur.cartes[widget.index].utiliser(CaseCliquable.getCaseClick())
                                            joueur.cartes.pop(widget.index)
                                            nbCartesJouees += 1
                                            index_widget_select = -1
                                            break
                                    else:
                                        # Vérification de la possibilité d'utiliser la carte sur la case en fonction des restrictions
                                        # de chaque type de cartes
                                        if not (joueur.cartes[widget.index].typeCarte in [TypeCarte.Case] and isinstance(plat.listeCases[CaseCliquable.getCaseClick()], CaseSpeciale)) and not (joueur.cartes[widget.index].nom == "Demolition" and not isinstance(plat.listeCases[CaseCliquable.getCaseClick()], CaseSpeciale)) and not (widget.nom == "Teleportation" and len(plat.listeCases[CaseCliquable.getCaseClick()].listeEnnemis) > 0):
                                            donneesJoueurActuel["nbCartesJouees"] += 1
                                            joueur.cartes[widget.index].utiliser(CaseCliquable.getCaseClick())
                                            joueur.cartes.pop(widget.index)
                                            nbCartesJouees += 1
                                            index_widget_select = -1
                                            break

                    # On vérifie si le bouton associé au lancer de dés est cliqué et si oui on lance le déplacement du joueur
                    if boutonDe.estClique():
                        de1.afficherLancer(ecran)
                        nb_deplacements = de1.valeur
                        for i in range(nb_deplacements):
                            plat.listeCases[(joueur.emplacement+i+1)%len(plat.listeCases)].deplacementPossible = True
                        
                        choixDeplacement = True
                        nb_deplacements = boucleChoixDeplacement(ecran, plat, de1, boutonPause, boutonDe, boutonMagasin, feudecamp, portail, barre_lat, boite, infoJoueurs, joueurActuel, nbCartesJouees, index_widget_select, choixDeplacement)
                        choixDeplacement = False
                        
                        for i in range(len(plat.listeCases)):
                            plat.listeCases[i].deplacementPossible = False
                        
                        delai_depl = 10


                    if boutonPause.estClique() or keys[pygame.K_ESCAPE]:
                        # Sauvegarde des données
                        variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)] = donneesJoueurActuel
                        json.dump(variables_globales.donnees_joueurs, open(constant.REPERTOIRE_COURANT+"/donnees_joueurs.json", "w"))
                        
                        menuPause.menuPause(ecran, plat, solo, partieTerminee)
                        
                    
                    if boutonMagasin.estClique():
                        if joueur.emplacement == 0:
                            variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)] = donneesJoueurActuel
                            boucleMagasin(ecran, plat, joueurActuel)
                            donneesJoueurActuel = variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)]

        # Lorque le tour est terminé
        if tourTermine:
            # S'il ne reste qu'un seul joueur (hors solo),
            # on annonce la fin de la partie, sinon on change de joueur
            if (len(Joueur.getAllJoueur()) == 1 and not solo) or (len(Joueur.getAllJoueur()) == 0 and solo):
                # Menu de fin de partie en cas de seul joueur restant
                variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)] = donneesJoueurActuel
                json.dump(variables_globales.donnees_joueurs, open(constant.REPERTOIRE_COURANT+"/donnees_joueurs.json", "w"), indent=4)
                partieTerminee = menuFinSolo.menuFinSolo(ecran, solo, partieTerminee)

            else:
                variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)] = donneesJoueurActuel
                nb_deplacements = 0
                if not joueur.est_mort():
                    joueurActuel += 1
                if joueurActuel >= len(Joueur.getAllJoueur()):
                    joueurActuel = 0
                joueur = Joueur.getAllJoueur()[joueurActuel]
                index_widget_select = -1
                nbCartesJouees = 0
                tourTermine = False
                donneesJoueurActuel = variables_globales.donnees_joueurs["joueur_"+str(joueurActuel+1)]

        # Mise à jour de l'affichage
        if not partieTerminee:
            updateAffichage(ecran, plat, de1, boutonPause, boutonDe, boutonMagasin, feudecamp, portail, barre_lat, boite, infoJoueurs, joueurActuel, nbCartesJouees, index_widget_select)

        clock.tick(60) # FPS = 60