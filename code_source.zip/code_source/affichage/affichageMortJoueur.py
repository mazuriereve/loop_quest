import constant


import pygame


def affichageMortJoueur(ecran: pygame.Surface, nomJoueur: int):
    """
    Affiche un message indiquant que le joueur est mort pendant le jeu.

    Args:
        ecran (pygame.Surface): La surface de l'écran sur laquelle afficher le message.
        nomJoueur (int): Le numéro du joueur qui est mort.
    """
    texte = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 40).render(f"{nomJoueur} est mort !", True, (255, 0, 0))
    ecran.fill(pygame.Color(0, 0, 0))
    ecran.blit(texte, (ecran.get_width()/2-texte.get_width()/2, ecran.get_height()/2-texte.get_height()/2))
    pygame.display.flip()
    pygame.time.wait(3000)
    ecran.fill(pygame.Color(156,219,67))