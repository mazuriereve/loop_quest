import constant
from personnage.Joueur import Joueur
from widgets.BarreLaterale import BarreLaterale
from widgets.BoiteDeDialogue import BoiteDeDialogue
from widgets.Bouton import Bouton
from widgets.CaseCliquable import CaseCliquable
from widgets.De6 import De6
from widgets.InfoJoueurs import InfoJoueurs
from widgets.ListeObjetsAnimees import ListeObjetsAnimees
from widgets.ObjetAnime import ObjetAnime


import pygame


def initAffichageJeu(ecran: pygame.Surface) -> tuple[De6, Bouton, Bouton, Bouton, BarreLaterale, ObjetAnime, ObjetAnime, BoiteDeDialogue, InfoJoueurs]:
    """Initialise l'affichage du jeu

    Args:
        ecran (pygame.Surface): L'écran sur lequel afficher les éléments

    Returns:
        tuple[De6, Bouton, Bouton, BarreLaterale, ObjetAnime, ObjetAnime, BoiteDeDialogue, InfoJoueurs]: Un tuple contenant les éléments suivants:
            - Le premier dé
            - Le bouton de lancement des dés
            - Le bouton d'information
            - Le bouton de pause
            - La barre latérale
            - L'objet animé "Feu de camp"
            - L'objet animé "Portail"
            - La boîte de dialogue
            - Les informations des joueurs
    """
    # Initialisation de l'affichage
    CaseCliquable.init_cases()
    barreLat: BarreLaterale = BarreLaterale()
    infoJoueurs: InfoJoueurs = InfoJoueurs((1280-barreLat.rect.width, (80 if len(Joueur.getAllJoueur()) > 2 else 50)), (barreLat.rect.width, 0))
    de1: De6 = De6((816, 220))
    boutonDe: Bouton = Bouton(" Lancer ", (100, 100, 100), (255, 255, 255), (0, 275))
    
    boutonMagasin: Bouton = Bouton(" Magasin ", (100, 100, 100), (255, 255, 255), (0, 325))
    boutonMagasin.rect.x = (ecran.get_width()-(17*32*constant.SCALING_CASE)+((12*32*constant.SCALING_CASE)-boutonMagasin.rect.width)/2)
    
    boutonPause= Bouton(" Pause ", (100, 100, 100), (255, 255, 255), (0, 0))
    boutonPause.position = (ecran.get_width()-boutonPause.rect.width-10, ecran.get_height()-boutonPause.rect.height-10)

    boutonDe.rect.x = (ecran.get_width()-(17*32*constant.SCALING_CASE)+((12*32*constant.SCALING_CASE)-boutonDe.rect.width)/2)
    feudecamp: ObjetAnime = ListeObjetsAnimees.FeuDeCamp.creerObjetAnime()
    boutonPause.afficher(ecran)
    portail: ObjetAnime = ListeObjetsAnimees.Portail.creerObjetAnime()
    boite: BoiteDeDialogue = BoiteDeDialogue((480, 150), (1280-(17*32*constant.SCALING_CASE)+((12*32*constant.SCALING_CASE)-480)/2, 375))
    return de1, boutonPause, boutonDe, boutonMagasin, barreLat, feudecamp, portail, boite, infoJoueurs
