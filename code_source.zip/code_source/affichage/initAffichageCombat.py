from widgets.BoiteDeDialogue import BoiteDeDialogue
from widgets.Bouton import Bouton
from widgets.EcranCombat import EcranCombat


def initAffichageCombat() -> tuple[EcranCombat, Bouton, Bouton, Bouton, Bouton , Bouton , BoiteDeDialogue]:
    """
    Initialise l'affichage du combat

    Returns:
    tuple[EcranCombat, Bouton, Bouton, Bouton, BoiteDeDialogue]: un tuple contenant les éléments suivant:
        - EcranCombat: une instance de la classe EcranCombat
        - Bouton: une instance de la classe Bouton représentant le bouton "Attaque"
        - Bouton: une instance de la classe Bouton représentant le bouton "Attaque critique"
        - Bouton: une instance de la classe Bouton représentant le bouton "Utiliser carte"
        - Bouton: une instance de la classe Bouton représentant le bouton "Fuite"
        - BoiteDeDialogue: une instance de la classe BoiteDeDialogue
    """
    ecranCombat: EcranCombat = EcranCombat()
    boutonAttaque: Bouton = Bouton(" Attaque ", (100, 100, 100), (255, 255, 255), (410, 500))
    boutonDefense: Bouton = Bouton(" A. Critique ", (100, 100, 100), (255, 255, 255), (410, 550))
    boutonCarte: Bouton = Bouton(" Utiliser carte ", (100, 100, 100), (255, 255, 255), (410, 600))
    boutonFuite: Bouton = Bouton(" Fuite ", (100, 100, 100), (255, 255, 255), (410, 650))

    boutonRetour: Bouton = Bouton(" X ", (100, 100, 100), (255, 255, 255), (1200, 20))

    boite: BoiteDeDialogue = BoiteDeDialogue((850-boutonCarte.rect.width, 150), (400+boutonCarte.rect.width+20, 540))
    return ecranCombat, boutonAttaque, boutonDefense, boutonCarte,boutonFuite,boutonRetour, boite