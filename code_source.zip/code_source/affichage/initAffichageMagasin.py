

from widgets.InfoJoueurs import InfoJoueurs


import pygame


def initAffichageMagasin(ecran: pygame.Surface, infoJoueurs: InfoJoueurs):
    width: int = 880
    height: int = 172-infoJoueurs.taille[1]
    
    surface = pygame.Surface((width, height))
    
    