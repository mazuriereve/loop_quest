from case.Case import Case
from widgets.BoiteDeDialogue import BoiteDeDialogue
from widgets.EcranCombat import EcranCombat
from widgets.BarreLaterale import BarreLaterale
from widgets.Bouton import Bouton
from widgets.fonctions import contourRect

import pygame

def updateAffichageCombat(ecran: pygame.Surface, barreLaterale: BarreLaterale, ecranCombat: EcranCombat, boutons: list[Bouton], boite: BoiteDeDialogue, case: Case, joueurActuel: int, carteJouee: bool, index_widget_select: int = None):
    """
    Met à jour l'affichage de l'écran de combat

    Args:
        ecran (pygame.Surface): L'écran sur lequel afficher les éléments
        barreLaterale (BarreLaterale): La barre latérale
        ecranCombat (EcranCombat): L'écran de combat
        boutons (list[Bouton]): La liste des boutons
        boite (BoiteDeDialogue): La boîte de dialogue
        case (Case): La case sur laquelle se déroule le combat
        joueurActuel (int): L'indice du joueur actuel
        carteJouee (bool): Indique si une carte a été jouée
        index_widget_select (int, optional): L'indice du widget sélectionné. Defaults to None.
    """
    from personnage.Joueur import Joueur
    barreLaterale.afficher(ecran, joueurActuel, index_widget_select, combat=True)
    ecranCombat.afficher(ecran, case, joueurActuel)
    if not Joueur.getAllJoueur()[joueurActuel].isIA:
        for i in range(len(boutons)-(1 if carteJouee else 0)):
            boutons[i].afficher(ecran)

    boite.afficher(ecran)

    pygame.display.flip()


