import plateau
from widgets.BarreLaterale import BarreLaterale
from widgets.BoiteDeDialogue import BoiteDeDialogue
from widgets.Bouton import Bouton
from widgets.CaseCliquable import CaseCliquable
from widgets.De6 import De6
from widgets.InfoJoueurs import InfoJoueurs
from widgets.ObjetAnime import ObjetAnime
from personnage.Joueur import Joueur


import pygame


def updateAffichage(ecran: pygame.Surface, plat: plateau.Plateau, de1: De6, boutonPause : Bouton , boutonDe: Bouton, boutonMagasin: Bouton, feudecamp: ObjetAnime, portail: ObjetAnime, barre_lat: BarreLaterale, boite: BoiteDeDialogue, infoJoueurs: InfoJoueurs, joueurActuel: int, nbCartesJouees: int, index_widget_select: int = None, choixDeplacement: bool = False):
    """Met à jour l'affichage de l'écran

    Args:
     - ecran (pygame.Surface): L'écran sur lequel afficher les éléments
     - plat (plateau.Plateau): Le plateau de jeu
     - de1 (De6): Le premier dé
     - boutonPause (BoutonPause) : Le bouton pour mettre le jeu en pause
     - boutonDe (Bouton): Le bouton pour lancer les dés
     - boutonInfo (Bouton): Le bouton pour afficher les informations
     - feudecamp (ObjetAnime): Le feu de camp
     - portail (ObjetAnime): Le portail
     - barre_lat (BarreLaterale): La barre latérale
     - boite (BoiteDeDialogue): La boîte de dialogue
     - joueurActuel (int): L'indice du joueur actuel
     - nbCartesJouees (int): Le nombre de cartes jouées
     - index_widget_select (int, optional): L'indice du widget sélectionné. Defaults to None.
     - infos (bool, optional): Indique si les informations des joueurs doivent être affichées. Defaults to False.
     - choixDeplacement (bool, optional): Indique si le joueur doit choisir sa case de déplacement. Defaults to False.
    """
    CaseCliquable.afficherCases(ecran, plat, feudecamp, portail)
    barre_lat.afficher(ecran, joueurActuel, index_widget_select)
    infoJoueurs.afficher(ecran, joueurActuel)

    de1.afficher(ecran)
    
    if not Joueur.getAllJoueur()[joueurActuel].isIA:
        boutonDe.afficher(ecran)
        boutonPause.afficher(ecran)
    
    if choixDeplacement:
        boite.afficher(ecran, "Cliquez sur une case\npour vous déplacer.")
    
    elif nbCartesJouees < 2:
        boite.afficher(ecran, f"Utilisez {2-nbCartesJouees} carte"+("s" if nbCartesJouees == 0 else "")+"\nou\nlancez le dé.")
        
    else:
        boite.afficher(ecran, "Lancez le dé.")
        
    if Joueur.getAllJoueur()[joueurActuel].emplacement == 0 and choixDeplacement == False:
        boutonMagasin.afficher(ecran)
    else:
        cover = pygame.Surface((boutonMagasin.rect.width, boutonMagasin.rect.height+2))
        cover.fill(pygame.Color(156,219,67))
        ecran.blit(cover, (boutonMagasin.rect.x, boutonMagasin.rect.y))

    # Affiche le contour de la case sur laquelle se trouve le joueur
    # bords = contourRect(CaseCliquable.getListeCaseCliquable()[Joueur.getAllJoueur()[joueurActuel].emplacement].rect, (255, 0, 0), 2)
    # for bord, pos in bords:
    #     ecran.blit(bord, pos)
    pygame.display.flip()