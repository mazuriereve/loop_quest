

from widgets.PageMagasin import PageMagasin
import pygame


def updateAffichageMagasin(ecran: pygame.Surface, page: PageMagasin):
    page.initAffichage(ecran)
    pygame.display.flip()
    