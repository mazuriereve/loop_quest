from __future__ import annotations
from case.TypesCase import TypesCase
from personnage.Joueur import Joueur
import plateau
from cartes.Carte import Carte
from cartes.TypeCarte import TypeCarte
# from cartes.Carte import Carte1, Soin, ModifAttaque, DetruireCaseSpe, AjouterCimetiere, AjouterMarais, AjouterNid, AjouterVillage

import operator
from enum import Enum
from random import choice, randint


class ListeCartes(Enum):
    """
    Enumération contenant toutes les cartes du jeu.
    """
    Teleportation = ("Teleportation", TypeCarte.Utilisable, "emplacement", "Teleporte le joueur\nsur une case", 10)
    Potion = ("Potion", TypeCarte.Consommable, (5, "pointDeVie", operator.add), "Rend 5 PV au joueur\n(Utilisée auto. si\nPV = 0)", 2)
    Fiole_ATQ = ("Fiole_ATQ", TypeCarte.Consommable, (operator.add, 2, 2, "attaque", operator.sub, 2, False), "Augmente l'ATQ de\n2 pendant 2 tours", 4)
    Village = ("Village", TypeCarte.Case, (TypesCase.caseVillage, "listeCases", None), "Ennemi : Voleur\n\nEffet : Rend 2 PV\nau joueur", 5)
    Cimetiere = ("Cimetiere", TypeCarte.Case, (TypesCase.caseCimetiere, "listeCases", None), "Ennemi : Squelette\n\nEffet : Un coffre\npeut apparaître", 8)
    Marais = ("Marais", TypeCarte.Case, (TypesCase.caseMarais, "listeCases", None), "Ennemi : Sorcière\n\nEffet : Reduit la DEF\nde 2 pendant 2 tours", 6)
    Nid = ("Nid", TypeCarte.Case, (TypesCase.caseNid, "listeCases", None), "Ennemi : Araignée\n\nEffet : Reduit la VIT\nde 2 pendant 2 tours", 3)
    Bombe = ("Bombe", TypeCarte.Placable, ("bombe", "piege", None), "Tue les ennemis ou\nfait perdre 2 PV\nau joueur", 7)
    Demolition = ("Demolition", TypeCarte.Plateau, "Detruit une case\nspéciale", 3)

    def genererCarte(self: ListeCartes, p: plateau.Plateau = None, joueurActuel: int = None) -> Carte:
        """
        Génère une carte avec les effets spécifiés.

        Args:
        - p: le plateau de jeu
        - joueurActuel: l'indice du joueur actuel

        Returns:
        - La carte générée.
        """
        if self.value[1] == TypeCarte.Case:
            return Carte(self.value[0], self.value[1], [(p, self.value[2][0], self.value[2][1], self.value[2][2])], self.value[3], self.value[4])
        if self.value[1] == TypeCarte.Consommable:
            if len(self.value[2]) == 3:
                return Carte(self.value[0], self.value[1], [(Joueur.getAllJoueur()[joueurActuel], self.value[2][0], self.value[2][1], self.value[2][2])], self.value[3], self.value[4])
            elif len(self.value[2]) == 7:
                return Carte(self.value[0], self.value[1], [(Joueur.getAllJoueur()[joueurActuel], self.value[2][0], self.value[2][1], self.value[2][2], self.value[2][3], self.value[2][4], self.value[2][5], self.value[2][6])], self.value[3], self.value[4])
        if self.value[1] == TypeCarte.Plateau:
            if self.value[0] == "Demolition":
                return Carte(self.value[0], self.value[1], [(None, None, None, p.detruireCase)], self.value[2], self.value[3])
        if self.value[1] == TypeCarte.Utilisable:
            return Carte(self.value[0], self.value[1], [(Joueur.getAllJoueur()[joueurActuel], None, self.value[2], None)], self.value[3], self.value[4])
        if self.value[1] == TypeCarte.Placable:
            return Carte(self.value[0], self.value[1], [(p, self.value[2][0], self.value[2][1], None)], self.value[3], self.value[4])

    @staticmethod
    def genererCarteAleatoire(p: plateau.Plateau, joueurActuel: int) -> Carte:
        """
        Génère une carte aléatoire parmi toutes les cartes du jeu.

        Args:
        - p: Le plateau de jeu
        - joueurActuel: L'indice du joueur actuel

        Returns:
        - Une carte générée aléatoirement.
        """
        choixTypeCarte: int = randint(0, 2)
        # Si 0, return une carte placable au hasard
        if choixTypeCarte > 0:
            return choice(list(filter(lambda x: x.value[1] in [TypeCarte.Plateau, TypeCarte.Utilisable, TypeCarte.Case, TypeCarte.Placable], list(ListeCartes)[1:]))).genererCarte(p, joueurActuel)
        else:
            return choice(list(filter(lambda x: x.value[1] == TypeCarte.Consommable, list(ListeCartes)[1:]))).genererCarte(p, joueurActuel)