from enum import Enum


class TypeCarte(Enum):
    Placable = 0
    Consommable = 1
    Utilisable = 2
    Case = 3
    Plateau = 4