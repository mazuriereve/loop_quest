from __future__ import annotations
from cartes.TypeVar import Effet, EffetTemporaire
from cartes.TypeCarte import TypeCarte
from typing_extensions import Union


class Carte:
    """
    Classe représentant une carte du jeu.

    Attributs:
    - nom (str): Le nom de la carte
    - typeCarte (TypeCarte): Le type de la carte
    - effets (list[Union[Effet, EffetTemporaire]]): La liste des effets de la carte
    - description (str): La description de la carte
    """
    def __init__(self: Carte, nom: str, typeCarte: TypeCarte, effets: list[Union[Effet, EffetTemporaire]], description: str, valeur: int):
        super().__init__()
        self._nom: str = nom
        self._typeCarte: TypeCarte = typeCarte
        self._effets: list[Union[Effet, EffetTemporaire]] = effets # Contient les paramètres nécessaires aux constructeurs des effets
        self._description: str = description
        self._valeur: int = valeur

    # Getters et setters
    @property
    def nom(self: Carte) -> str: return self._nom

    @nom.setter
    def nom(self: Carte, nom: str): self._nom = nom

    @property
    def typeCarte(self: Carte) -> TypeCarte: return self._typeCarte

    @typeCarte.setter
    def typeCarte(self: Carte, typeCarte: TypeCarte): self._typeCarte = typeCarte

    @property
    def effets(self: Carte) -> str: return self._effets

    @effets.setter
    def effets(self: Carte, effets: str): self._effets = effets

    @property
    def description(self: Carte) -> str: return self._description

    @description.setter
    def description(self: Carte, description: str): self._description = description

    @property
    def valeur(self: Carte) -> int: return self._valeur
    
    @valeur.setter
    def valeur(self: Carte, valeur: int): self._valeur = valeur

    # Méthodes
    def utiliser(self: Carte, index: int = None):
            """
            Applique les effets de la carte.

            Args:
            - index (int): L'indice de la case sur laquelle la carte est utilisée. Defaults to None.
            """
            from util.Effet import Effet
            from util.EffetTemporaire import EffetTemporaire

            for effet in self._effets:
                if self._typeCarte == TypeCarte.Case:
                    e = Effet(effet[0], effet[1].creer_case_speciale(index, effet[0].listeCases[index].listeEnnemis), effet[2], effet[3])
                    e.appliquerEffet(index)
                if self._typeCarte == TypeCarte.Consommable:
                    if len(effet) == 4:
                        e = Effet(effet[0], effet[1], effet[2], effet[3])
                        e.appliquerEffet()
                    if len(effet) == 8:
                        e = EffetTemporaire(cible=effet[0], operateur=effet[1], valeur=effet[2], duree=effet[3], attributCible=effet[4], operateurInv=effet[5], valeurInv=effet[6], repetition=effet[7])
                if self._typeCarte == TypeCarte.Plateau:
                    e = Effet(effet[0], index, effet[2], effet[3])
                    e.appliquerEffet()
                if self._typeCarte == TypeCarte.Utilisable:
                    e = Effet(effet[0], index, effet[2], effet[3])
                    e.appliquerEffet()
                if self._typeCarte == TypeCarte.Placable:
                    e = Effet(effet[0].listeCases[index], effet[1], effet[2], effet[3])
                    e.appliquerEffet()