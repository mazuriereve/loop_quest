from __future__ import annotations

from typing_extensions import Callable, TypeVar, TypeAlias

O = TypeVar("O")
Effet: TypeAlias = tuple[O, O, str, Callable]
EffetTemporaire: TypeAlias = tuple[O, O, Callable, int, str, Callable, O, bool]

