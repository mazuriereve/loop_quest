# Luc DELAGE
# TD1-TPA
# SAE S3C1

# importations
from __future__ import annotations

import constant
from case.Case import Case
from case.CaseSpeciale import CaseSpeciale
from case.TypesCase import TypesCase
from util.ProprietaireCompteur import ProprietaireCompteur
from util.Compteur import Compteur
from personnage.TypesEnnemi import TypesEnnemi
from personnage.Joueur import Joueur
from random import randint
from functools import reduce

class Plateau(ProprietaireCompteur):
    """Classe modélisant le plateau de jeu"""
    def __init__(self: Plateau):
        import personnage
        
        self._compteurZombie: Compteur = Compteur(15)
        self._compteurZombie.ajouterProprietaire(self)
        self._listeCases: list[Case] = []
        self._listeCases.append(TypesCase.caseFeuDeCamp.creer_case_speciale(0, []))
        for i in range(constant.TAILLE_PLATEAU-1):
            self._listeCases.append(Case(i, []))
            if i in [3, 8, 15, 20]:
                self._listeCases[i].listeEnnemis.append(TypesEnnemi.Zombie.creerEnnemi())
            
    @property
    def listeCases(self: Plateau) -> list[Case]: return self._listeCases
    
    @listeCases.setter
    def listeCases(self: Plateau, listeCases: list[Case]): self._listeCases = listeCases
    
    @property
    def compteurZombie(self: Plateau) -> Compteur: return self._compteurZombie
    
    @compteurZombie.setter
    def compteurZombie(self: Plateau, compteurZombie: Compteur): self._compteurZombie = compteurZombie
    
    # Méthodes
    def compteurModifie(self: Plateau):
        """Si le compteur de zombie est à 0, on fait apparaître 2 zombies aléatoirement sur le plateau"""
        import personnage
        
        nbEnnemis = reduce(lambda x, y: x + len(y.listeEnnemis), self._listeCases, 0)
        
        if self._compteurZombie.valeur == 0 and nbEnnemis <= (constant.TAILLE_PLATEAU-1-len(Joueur.getAllJoueur()))*4 - 2:
            for _ in range(2):
                ok: bool = False
                while not ok:
                    case: Case = self._listeCases[randint(1, len(self._listeCases)-1)]
                    if len(case.listeEnnemis) < 4 and not case.portail and case.piege != "piege_a_ours":
                        if len(Joueur.getAllJoueur()) != 0:
                            if self._listeCases.index(case) not in list(map(lambda x: x.emplacement, Joueur.getAllJoueur())):
                                case.listeEnnemis.append(TypesEnnemi.Zombie.creerEnnemi())
                                ok = True
                        else:
                            case.listeEnnemis.append(TypesEnnemi.Zombie.creerEnnemi())
                            ok = True
                        
    def detruireCase(self: Plateau, index: int) -> bool:
        """Remplace une case spéciale du plateau par une case normale, renvoie True si la case a été détruite, False sinon"""
        if index == 0:
            return False
        elif isinstance(self._listeCases[index], CaseSpeciale):
            copieListeEnnemis = self._listeCases[index].listeEnnemis.copy()
            self._listeCases[index].compteurEnnemi.retirerCompteur()
            self._listeCases[index] = Case(copieListeEnnemis)
            return True
        else:
            return False
        
    def ajouterPortail(self: Plateau, index: int, joueur: int):
            """
            Ajoute un portail sur la case d'index donné et détruit la case existante.

            Args:
                self (Plateau): Instance de la classe Plateau.
                index (int): Index de la case sur laquelle ajouter le portail.
                joueur (int): Numéro du joueur qui ajoute le portail.
            """
            self.detruireCase(index)
            self.listeCases[index].listeEnnemis = []
            self.listeCases[index].portail = True
            self.listeCases[index].numeroJoueurPortail.append(joueur)

