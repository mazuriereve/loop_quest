
from affichage.initAffichageJeu import initAffichageJeu
from personnage.Joueur import Joueur
from boucles.boucleMagasin import boucleMagasin
import pygame
from plateau import Plateau
from cartes.ListeCartes import ListeCartes
from personnage.CapaciteSpeciale import CapaciteSpeciale




if __name__ == "__main__":
    pygame.init()
    pygame.font.init()
    
    plat = Plateau()
    joueur = Joueur("test", 1, 1, 1, 1, CapaciteSpeciale.Fleche_neutralisante, None, None, None)
    joueur.argent = 4
    joueur.capaciteDisponible = False
    
    for i in range(8):
        joueur.nouvelleCarte(ListeCartes.genererCarteAleatoire(plat, 0))
    
    ecran = pygame.display.set_mode((1280, 720))
    
    initAffichageJeu(ecran)
    boucleMagasin(ecran, plat, 0)
    
    pygame.quit()