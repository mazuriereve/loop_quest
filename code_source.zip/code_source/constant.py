import os

# emplacement du répertoire courant
REPERTOIRE_COURANT = os.path.dirname(os.path.abspath(__file__))

#------------------------------------------------------#
#            Éléments des différents menus             #
#------------------------------------------------------#
TITRE_JEU = "Loop Quest"
CHEMIN_FOND_MENU = None
CHEMIN_IMAGE_CREDITS = fr"{REPERTOIRE_COURANT}/ressources/menus/credits.png"

#------------------------------------------------------#
#                 Polices d'écriture                   #
#------------------------------------------------------#
CHEMIN_POLICE_NORMAL = fr"{REPERTOIRE_COURANT}/ressources/font/yoster.ttf"
CHEMIN_POLICE_TITRE = fr"{REPERTOIRE_COURANT}/ressources\font\OldEnglishGothicPixelRegular-ow2Bo.ttf"

#------------------------------------------------------#
#                  Affichage des cases                 #
#------------------------------------------------------#
CHEMIN_CASE_NORMALE = fr"{REPERTOIRE_COURANT}/ressources/textures/case.png"
CHEMIN_CASE_COIN = fr"{REPERTOIRE_COURANT}/ressources/textures/case_coin.png"
CHEMIN_PIEGE_A_OURS = fr"{REPERTOIRE_COURANT}/ressources/sprites/piege_a_ours.png"
CHEMIN_BOMBE = fr"{REPERTOIRE_COURANT}/ressources/sprites/bombe.png"
CHEMIN_COFFRE = fr"{REPERTOIRE_COURANT}/ressources/sprites/coffre.png"

TAILLE_PLATEAU = 24
SCALING_CASE = 1.25 # 32px -> 40px
SCALING_PIEGE = 0.75 # 32px -> 24px
SCALING_VILLAGE = 5/6 # 48px -> 40px

DIMENSION_COFFRE = (54, 54)
SCALING_COFFRE = 0.40 # 54px -> 24px

CHEMIN_FEUDECAMP = fr"{REPERTOIRE_COURANT}/ressources/sprites/feu_de_camp.png"
DIMENSION_FEUDECAMP = (50, 86)
SCALING_FEUDECAMP = 0.5 # 50px -> 25px

CHEMIN_PORTAIL = fr"{REPERTOIRE_COURANT}/ressources/sprites/portail.png"
DIMENSION_PORTAIL = (47, 46)
SCALING_PORTAIL = 1

CHEMIN_DE6 = fr"{REPERTOIRE_COURANT}/ressources/sprites/de6.png"
SCALING_DE6 = 3 # 16px -> 48px

#------------------------------------------------------#
#               Affichages des personnages             #
#------------------------------------------------------#
CHEMIN_CHEVALIER = fr"{REPERTOIRE_COURANT}/ressources/sprites/chevalier.png"
CHEMIN_ARCHER = fr"{REPERTOIRE_COURANT}/ressources/sprites/archer.png"
CHEMIN_MAGICIEN = fr"{REPERTOIRE_COURANT}/ressources/sprites/magicien.png"
CHEMIN_CHASSEUR = fr"{REPERTOIRE_COURANT}/ressources/sprites/chasseur.png"
CHEMIN_FARCEUR = fr"{REPERTOIRE_COURANT}/ressources/sprites/farceur.png"

DIMENSION_CHEVALIER = (135, 49)
DIMENSION_ARCHER = (100, 45)
DIMENSION_MAGICIEN = (231, 105)
DIMENSION_CHASSEUR = (150, 66)
DIMENSION_FARCEUR = (100, 100)

ECART_CHEVALIER = 24
ECART_ARCHER = 24
ECART_MAGICIEN = 24
ECART_CHASSEUR = 24
ECART_FARCEUR = 0

# Hauteur = 270px
SCALING_CHEVALIER = 2 # 135px/49px -> 270px/98px
SCALING_ARCHER = 2 # 100px/45px -> 200px/90px
SCALING_MAGICIEN = 1 # 231px/105px -> 231px/105px
SCALING_CHASSEUR = 1.8 # 150px/66px -> 270px/118px
SCALING_FARCEUR = 0.8 # 100px/100px -> 80px/80px

CHEMIN_ARAIGNEE = fr"{REPERTOIRE_COURANT}/ressources/sprites/araignee.png"
CHEMIN_ZOMBIE = fr"{REPERTOIRE_COURANT}/ressources/sprites/zombie.png"
CHEMIN_SQUELETTE = fr"{REPERTOIRE_COURANT}/ressources/sprites/squelette.png"
CHEMIN_VOLEUR = fr"{REPERTOIRE_COURANT}/ressources/sprites/voleur.png"
CHEMIN_SORCIERE = fr"{REPERTOIRE_COURANT}/ressources/sprites/sorciere.png"
CHEMIN_BOSS = fr"{REPERTOIRE_COURANT}/ressources/sprites/boss_squelette.png"

DIMENSION_ARAIGNEE = (32, 32)
DIMENSION_ZOMBIE = (32, 32)
DIMENSION_SQUELETTE = (64, 40)
DIMENSION_VOLEUR = (150, 55)
DIMENSION_SORCIERE = (128, 73)
DIMENSION_BOSS = (96, 96)

# Hauteur = 64px
SCALING_ARAIGNEE = 2 # 32px -> 64px
SCALING_ZOMBIE = 2 # 32px -> 64px
SCALING_SQUELETTE = 2 # 34px/36px -> 68px/72px
SCALING_VOLEUR = 1.8 # 50px/45px -> 90px/81px
SCALING_SORCIERE = 1.2 # 50px/72px -> 60px/86px
SCALING_BOSS = 1.5 # 37px/70px -> 56px/105px

CHEMIN_MINI_FIGURES = fr"{REPERTOIRE_COURANT}/ressources/sprites/mini_figures.png"
CHEMIN_PION = fr"{REPERTOIRE_COURANT}/ressources/sprites/pion.png"

DIMENSION_MINI_FIGURES = (8, 10)
DIMENSION_PION = (11, 19)
SCALING_MINI_FIGURES = 2 # 8px -> 16px