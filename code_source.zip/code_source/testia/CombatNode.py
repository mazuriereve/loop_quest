from random import randint
from anytree import Node, RenderTree
from personnage.Joueur import Joueur
from personnage.Ennemi import Ennemi
from personnage.CapaciteSpeciale import CapaciteSpeciale
from cartes.Carte import Carte
from cartes.TypeCarte import TypeCarte

def generate_sommet(liste):
    if liste == []:
        return 'a'

    alphabet = 'abcdefghijklmnopqrstuvwxyz'
    for char in alphabet:
        if char not in liste:
            return char

    i = 1
    while True:
        for char in alphabet:
            nouvellelettre = char + str(alphabet[i-1])
            if nouvellelettre not in liste:
                return nouvellelettre
        i += 1



class CombatNode:
    def __init__(self, joueur, ennemi, joueur_actions, ennemi_actions):
        self.joueur = joueur
        self.ennemi = ennemi
        self.joueur_actions = joueur_actions
        self.ennemi_actions = ennemi_actions
        self.children = []

    def generate_combat_tree(self, depth):
        if depth == 0:
            return
        for action in self.joueur_actions:
            new_joueur_hp, new_ennemi_hp = self.simulate_action(action)
            new_node = CombatNode(new_joueur_hp, new_ennemi_hp, self.joueur_actions, self.ennemi_actions)
            self.children.append(new_node)
            new_node.generate_combat_tree(depth - 1)

    def simulate_action(self, action):
        if action == 0:  # Attaque
            new_ennemi_hp -= ((self.joueur.attaque*0.85) + self.joueur.attaque)/2 - self.ennemi.defense


class CombatNode:
    def __init__(self, joueur_hp, ennemi_hp, joueur_actions=None, ennemi_actions=None):
        self.joueur_hp = joueur_hp
        self.ennemi_hp = ennemi_hp
        self.joueur_actions = joueur_actions if joueur_actions else []
        self.ennemi_actions = ennemi_actions if ennemi_actions else []
        self.children = []

def generate_combat_tree(joueur : Joueur, ennemi : list[Ennemi], joueur_hp : int, ennemi_hp : list[int], listecarte : list[Carte], joueur_actions=None, ennemi_actions=None, depth=2, listeActionsEnnemis : list[int] = None, i : int = 0, cartejouee : bool = False, capacitespecialedispo : bool = False):
    ennemimorts = 0
    for qa in ennemi_hp:
        if qa <= 0:
            ennemiorts +=1
    if depth == 0 or joueur_hp <= 0 or ennemimorts == len(ennemi):
        return CombatNode(joueur, ennemi, joueur_hp, ennemi_hp, joueur_actions, ennemi_actions)

    joueur_actions = joueur_actions if joueur_actions else []
    ennemi_actions = ennemi_actions if ennemi_actions else []

    root = CombatNode(joueur_hp, ennemi_hp, joueur_actions, ennemi_actions)

    for joueur_action in range(4):
        for ennemi_action in range(2):
            for q in 0,len(ennemi):
                new_joueur_hp = joueur_hp[q]
                new_ennemi_hp = ennemi_hp[q]

                # Simulation des actions du joueur et de l'ennemi
                if joueur_action == 0:  # Attaque
                    new_ennemi_hp -= ((joueur.attaque*0.85) + joueur.attaque)/2 - ennemi.defense - listeActionsEnnemis[i]*2
                elif joueur_action == 1:  # Attaque critique
                    new_ennemi_hp -= joueur.attaque*2 - (ennemi.defense//2)
                elif not cartejouee:
                    if capacitespecialedispo:
                        if joueur.capaciteSpeciale == CapaciteSpeciale.Parade:
                            return ["capaciteSpeciale", "Parade"]
                    for t in listecarte: 
                        if t.nom == "Potion" and joueur.pointDeVie <= joueur.pointDeVieMax - 5:
                            return ["capaciteSpeciale","Potion"]
                        elif t.nom == "Fiole ATQ" and ennemi.pointDeVie >= joueur.attaque*0.85 - ennemi.defense:
                            return ["capaciteSpeciale","Fiole_ATQ"]

                if ennemi_action == 0:  # Attaque
                    new_joueur_hp -= randint(5, 10)  # Dommages moyens de l'attaque ennemie
                elif ennemi_action == 1:  # Défense
                    pass
                newlisteennemis = []
                if new_ennemi_hp <= 0:
                    for ro in 0,len(ennemi):
                        if ro == q:
                            pass
                        else :
                            newlisteennemis.append(ennemi[ro])
                            
                newlisteennemishp = []
                for d in 0,len(ennemi_hp):
                    if d == q and new_ennemi_hp <= 0:
                        pass
                    else:
                        newlisteennemishp.append(ennemi_hp[d])
                        
                        
                generate_combat_tree(joueur : Joueur, ennemi : list[Ennemi], joueur_hp : int, ennemi_hp : list[int], listecarte : list[Carte], joueur_actions=None, ennemi_actions=None, depth=2, listeActionsEnnemis : list[int] = None, i : int = 0, cartejouee : bool = False, capacitespecialedispo : bool = False):
                child_node = generate_combat_tree(joueur, newlisteennemis, new_joueur_hp, newlisteennemishp, joueur_actions + [joueur_action], ennemi_actions + [ennemi_action], depth - 1)
                root.children.append(child_node)

    return root



def alpha_beta(node, depth, alpha, beta, maximizing_player):
    if depth == 0 or not node.children:
        return node.joueur_hp - node.ennemi_hp, node.joueur_actions, node.ennemi_actions

    if maximizing_player:
        value = float('-inf')
        best_joueur_actions = []
        best_ennemi_actions = []
        for child in node.children:
            child_value, child_joueur_actions, child_ennemi_actions = alpha_beta(child, depth - 1, alpha, beta, False)
            if child_value > value:
                value = child_value
                best_joueur_actions = child_joueur_actions
                best_ennemi_actions = child_ennemi_actions
            alpha = max(alpha, value)
            if alpha >= beta:
                break
        return value, best_joueur_actions, best_ennemi_actions
    else:
        value = float('inf')
        best_joueur_actions = []
        best_ennemi_actions = []
        for child in node.children:
            child_value, child_joueur_actions, child_ennemi_actions = alpha_beta(child, depth - 1, alpha, beta, True)
            if child_value < value:
                value = child_value
                best_joueur_actions = child_joueur_actions
                best_ennemi_actions = child_ennemi_actions
            beta = min(beta, value)
            if alpha >= beta:
                break
        return value, best_joueur_actions, best_ennemi_actions

# Utilisation :
arbre_combat = generate_combat_tree(50, 10)
best_value, best_joueur_actions, best_ennemi_actions = alpha_beta(arbre_combat, 2, float('-inf'), float('inf'), True)
print("Meilleure valeur trouvée par Alpha-Beta:", best_value)
print("Actions du joueur:", best_joueur_actions)
print("Actions de l'ennemi:", best_ennemi_actions)


# # Exemple d'utilisation :
# arbre_combat = generate_combat_tree(100, 100)

# best_value, best_path = alpha_beta(arbre_combat, 4, float('-inf'), float('inf'), True)
# print("Meilleure valeur trouvée par Alpha-Beta:", best_value)
# print("Chemin correspondant:", "->".join(best_path))

# for pre, fill, node in RenderTree(arbre_combat):
#     print("%s%s" % (pre, node.name))
print(RenderTree(arbre_combat))

