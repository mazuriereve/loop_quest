# Luc DELAGE
# TD1-TPA
# SAE S3C1

# importations
from __future__ import annotations
from personnage.Ennemi import Ennemi

class Case:
    """
    Classe modélisant une case normale
    
    Attributs:
    - index (int): L'indice de la case
    - listeEnnemis (list[Ennemi]): La liste des ennemis présents sur la case
    - coffre (bool): Indique si la case contient un coffre
    - piege (str): Le type de piège présent sur la case
    - portail (bool): Indique si la case contient un portail
    - numeroJoueurPortail (list[int]): Le numéro du joueur qui a posé le portail
    """
    def __init__(self: Case, index: int, listeEnnemis: list[Ennemi] = []) -> None:
        self._index: int = index
        self._listeEnnemis: list[Ennemi] = listeEnnemis
        self._coffre: bool = False
        self._piege: str = ""
        self._portail: bool = False
        self._numeroJoueurPortail: list[int] = [] # Sous forme de liste si le portail de plusieurs joueurs est sur la même case
        self._deplacementPossible: bool = False
        
    # Getters et setters
    @property
    def index(self: Case) -> int: return self._index
    
    @index.setter
    def index(self: Case, index: int): self._index = index
    
    @property
    def listeEnnemis(self: Case) -> list[Ennemi]: return self._listeEnnemis
    
    @listeEnnemis.setter
    def listeEnnemis(self: Case, listeEnnemis: list[Ennemi]): self._listeEnnemis = listeEnnemis
    
    @property
    def coffre(self: Case) -> bool: return self._coffre
    
    @coffre.setter
    def coffre(self: Case, coffre: bool): self._coffre = coffre
    
    @property
    def piege(self: Case) -> str: return self._piege
    
    @piege.setter
    def piege(self: Case, piege: str): self._piege = piege
    
    @property
    def portail(self: Case) -> bool: return self._portail
    
    @portail.setter
    def portail(self: Case, portail: bool): self._portail = portail
    
    @property
    def numeroJoueurPortail(self: Case) -> list[int]: return self._numeroJoueurPortail
    
    @numeroJoueurPortail.setter
    def numeroJoueurPortail(self: Case, numeroJoueurPortail: list[int]): self._numeroJoueurPortail = numeroJoueurPortail
    
    @property
    def deplacementPossible(self: Case) -> bool: return self._deplacementPossible
    
    @deplacementPossible.setter
    def deplacementPossible(self: Case, deplacementPossible: bool): self._deplacementPossible = deplacementPossible
    
    # Méthodes
    def retirer_ennemis(self: Case):
        """Retire les ennemis présents sur la case"""
        self._listeEnnemis = []