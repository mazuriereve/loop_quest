from __future__ import annotations
import personnage.Ennemi
import personnage.TypesEnnemi
from case.CaseSpeciale import CaseSpeciale


import operator
from enum import Enum


class TypesCase(Enum):
    """Enumération des types de cases"""
    caseCimetiere = ("cimetiere", 20, personnage.TypesEnnemi.TypesEnnemi.Squelette, None, True)
    caseFeuDeCamp = ("feu_de_camp", None, None, [(None, 5, "pointDeVie", operator.add), (None, True, "capaciteDisponible", None)], False)
    caseVillage = ("village", 20, personnage.TypesEnnemi.TypesEnnemi.Voleur, [(None, 2, "pointDeVie", operator.add)], False)
    caseMarais = ("marais", 25, personnage.TypesEnnemi.TypesEnnemi.Sorciere, [(None, operator.sub, 2, 2, "defense", operator.add, 2, False)], False)
    caseNid = ("nid", 15, personnage.TypesEnnemi.TypesEnnemi.Araignee, [(None, operator.sub, 2, 2, "vitesse", operator.add, 2, False)], False)

    def creer_case_speciale(self: TypesCase, index: int, listeEnnemis: list[personnage.Ennemi.Ennemi]) -> CaseSpeciale:
        """Crée une case spéciale à partir d'un type de case

        Returns:
            CaseSpeciale: Une instance de case spéciale
        """
        return CaseSpeciale(index, self.value[0], self.value[1], self.value[2], self.value[3], self.value[4], listeEnnemis)