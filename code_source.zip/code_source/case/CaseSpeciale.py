from __future__ import annotations
from personnage.Ennemi import Ennemi
from personnage.Joueur import Joueur
from personnage.TypesEnnemi import TypesEnnemi
from util.Compteur import Compteur
from util.Effet import Effet
from util.EffetTemporaire import EffetTemporaire
from util.ProprietaireCompteur import ProprietaireCompteur
from case.Case import Case


class CaseSpeciale(Case, ProprietaireCompteur):
    """
    Sous-classe héritant de Case modélisant une case spéciale

    Attributs:
    - typeCase (str): Le type de la case
    - compteurEnnemi (Compteur): Le compteur de la case
    - typeEnnemi (TypesEnnemi): Le type d'ennemi présent sur la case
    - effets (list[tuple]): La liste des effets de la case
    - cheminTextureCase (str): Le chemin vers la texture de la case
    - apparitionCoffre (bool): Indique si la case peut faire apparaître un coffre
    - compteurCoffre (Compteur): Le compteur de la case pour l'apparition du coffre
    """
    # Constructeur
    def __init__(self: CaseSpeciale, index: int, typeCase: str, valeurCompteurEnnemi: (int|None), typeEnnemi: TypesEnnemi, effets: list[tuple], apparitionCoffre: bool = False, listeEnnemis: list[Ennemi] = []):
        super().__init__(index, listeEnnemis)
        self._typeCase = typeCase.lower()
        if valeurCompteurEnnemi == None:
            self._compteurEnnemi: (Compteur|None) = None
        else:
            self._compteurEnnemi: (Compteur|None) = Compteur(valeurCompteurEnnemi)
            self._compteurEnnemi.ajouterProprietaire(self)
        self._typeEnnemi: TypesEnnemi = typeEnnemi
        self._effets: list[tuple] = effets
        self._apparitionCoffre: bool = apparitionCoffre
        if self._apparitionCoffre:
            self._compteurCoffre = Compteur(50)
            self._compteurCoffre.ajouterProprietaire(self)

    # Getter et setter
    @property
    def typeCase(self: CaseSpeciale) -> str: return self._typeCase

    @typeCase.setter
    def typeCase(self: CaseSpeciale, typeCase: str): self._typeCase = typeCase

    @property
    def compteurEnnemi(self: CaseSpeciale) -> Compteur: return self._compteurEnnemi

    @compteurEnnemi.setter
    def compteurEnnemi(self: CaseSpeciale, compteurEnnemi: Compteur): self._compteurEnnemi = compteurEnnemi

    @property
    def typeEnnemi(self: CaseSpeciale) -> TypesEnnemi: return self._typeEnnemi

    @typeEnnemi.setter
    def typeEnnemi(self: CaseSpeciale, typeEnnemi: TypesEnnemi): self._typeEnnemi = typeEnnemi

    @property
    def apparitionCoffre(self: CaseSpeciale) -> bool: return self._apparitionCoffre

    @apparitionCoffre.setter
    def apparitionCoffre(self: CaseSpeciale, apparitionCoffre: bool): self._apparitionCoffre = apparitionCoffre

    @property
    def compteurCoffre(self: CaseSpeciale) -> Compteur: return self._compteurCoffre

    @compteurCoffre.setter
    def compteurCoffre(self: CaseSpeciale, compteurCoffre: Compteur): self._compteurCoffre = compteurCoffre

    @property
    def effets(self: CaseSpeciale) -> str: return self._effets

    @effets.setter
    def effets(self: CaseSpeciale, effets: str): self._effets = effets

    @property
    def cheminTextureCase(self: CaseSpeciale) -> str: return self._cheminTextureCase

    @cheminTextureCase.setter
    def cheminTextureCase(self: CaseSpeciale, cheminTextureCase: str): self._cheminTextureCase = cheminTextureCase

    # Méthodes
    def compteurModifie(self: CaseSpeciale):
        """Si le compteur de l'ennemi est à 0, on fait apparaître l'ennemi sur la case"""
        if self._compteurEnnemi.valeur == 0 and len(self._listeEnnemis) < 4 and self._index not in (list(map(lambda x: x.emplacement, Joueur.getAllJoueur()))):
            self._listeEnnemis.append(self.typeEnnemi.creerEnnemi())

        if self._apparitionCoffre:
            if self._compteurCoffre.valeur == 0:
                self._coffre = True

    def donnerEffet(self: CaseSpeciale, index: int):
        """Donne les effets de la case spéciale à un joueur"""
        for effet in self._effets:
            if len(effet) == 4:
                Effet(Joueur.getAllJoueur()[index], effet[1], effet[2], effet[3]).appliquerEffet()
            if len(effet) == 8:
                EffetTemporaire(Joueur.getAllJoueur()[index], effet[1], effet[2], effet[3], effet[4], effet[5], effet[6], effet[7])