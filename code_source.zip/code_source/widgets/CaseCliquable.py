from __future__ import annotations
from case.CaseSpeciale import CaseSpeciale
import constant
from personnage.Joueur import Joueur
import plateau
from widgets.ObjetAnime import ObjetAnime
from widgets.OrientationCase import OrientationCase
import random


import pygame


class CaseCliquable:
    """Classe modélisant une case cliquable et gérant son affichage"""

    # Listes statiques de toutes les cases cliquables
    listeCaseCliquable: list[CaseCliquable] = []

    @staticmethod
    def getListeCaseCliquable() -> list[CaseCliquable]: return CaseCliquable.listeCaseCliquable

    # Constructeur
    def __init__(self: CaseCliquable, orientation: OrientationCase, position: tuple[int, int]):
        """Constructeur

        Args:
            orientation (OrientationCase): L'orientation de la case
            position (tuple[int, int]): La position de la case sur l'écrans
        """
        match orientation:
            case OrientationCase.Horizontal:
                self._texture = pygame.transform.scale_by(pygame.image.load(constant.CHEMIN_CASE_NORMALE), constant.SCALING_CASE)
            case OrientationCase.Vertical:
                self._texture = pygame.transform.scale_by(pygame.transform.rotate(pygame.image.load(constant.CHEMIN_CASE_NORMALE), 90), constant.SCALING_CASE)
            case OrientationCase.Coin_Bas_Droit:
                self._texture = pygame.transform.scale_by(pygame.image.load(constant.CHEMIN_CASE_COIN), constant.SCALING_CASE)
            case OrientationCase.Coin_Haut_Droit:
                self._texture = pygame.transform.scale_by(pygame.transform.rotate(pygame.image.load(constant.CHEMIN_CASE_COIN), 90), constant.SCALING_CASE)
            case OrientationCase.Coin_Haut_Gauche:
                self._texture = pygame.transform.scale_by(pygame.transform.rotate(pygame.image.load(constant.CHEMIN_CASE_COIN), 180), constant.SCALING_CASE)
            case OrientationCase.Coin_Bas_Gauche:
                self._texture = pygame.transform.scale_by(pygame.transform.rotate(pygame.image.load(constant.CHEMIN_CASE_COIN), 270), constant.SCALING_CASE)

        self._rect = self._texture.get_rect()
        self._rect.x = position[0] ; self._rect.y = position[1]
        self._position = position
        self._orientation = orientation

        CaseCliquable.listeCaseCliquable.append(self)

    # Getters et setters
    @property
    def texture(self: CaseCliquable) -> pygame.Surface: return self._texture

    @texture.setter
    def texture(self: CaseCliquable, texture: pygame.Surface): self._texture = texture

    @property
    def position(self: CaseCliquable) -> tuple[int, int]: return self._position

    @position.setter
    def position(self: CaseCliquable, position: tuple[int, int]): self._position = position

    @property
    def rect(self: CaseCliquable) -> pygame.Rect: return self._rect

    @rect.setter
    def rect(self: CaseCliquable, rect: pygame.Rect): self._rect = rect

    @property
    def orientation(self: CaseCliquable) -> OrientationCase: return self._orientation

    @orientation.setter
    def orientation(self: CaseCliquable, orientation: OrientationCase): self._orientation = orientation

    # Méthodes statiques    
    @staticmethod
    def afficherCases(ecran: pygame.Surface, plat: plateau.Plateau, feudecamp: ObjetAnime, portail: ObjetAnime):
        """Affiche toutes les cases cliquables sur l'écran et les différents personnages et objets

        Args:
        ecran (pygame.Surface): La surface sur laquelle on affiche les cases
        plat (plateau.Plateau): Le plateau de jeu
        feudecamp (ObjetAnime): L'objet animé représentant le feu de camp
        portail (ObjetAnime): L'objet animé représentant le portail du boss
        """
        # On itère sur la liste des cases cliquables et on affiche la texture de la case correspondante
        for i in range(len(CaseCliquable.getListeCaseCliquable())):
            ecran.blit(CaseCliquable.getListeCaseCliquable()[i].texture, CaseCliquable.getListeCaseCliquable()[i].rect)

            # Si la case cliquable est une case spéciale sur le plateau, on affiche la texture de la case spéciale
            if isinstance(plat.listeCases[i], CaseSpeciale):
                if plat.listeCases[i].typeCase != "feu_de_camp":
                    texture = pygame.image.load(fr"{constant.REPERTOIRE_COURANT}/ressources/textures/{plat.listeCases[i].typeCase}_{CaseCliquable.getListeCaseCliquable()[i].orientation.name.lower()}.png")
                match plat.listeCases[i].typeCase:
                    case "village":
                        texture = pygame.transform.scale_by(texture, constant.SCALING_VILLAGE)
                        ecran.blit(texture, CaseCliquable.getListeCaseCliquable()[i].rect)
                    case "feu_de_camp":
                        texture = feudecamp.envoiSprite()
                        ecran.blit(texture,
                                   (CaseCliquable.getListeCaseCliquable()[i].rect.x+((CaseCliquable.getListeCaseCliquable()[i].rect.width)/2)-(texture.get_width()/2),
                                    CaseCliquable.getListeCaseCliquable()[i].rect.y+((CaseCliquable.getListeCaseCliquable()[i].rect.height)/2)-(texture.get_height()/1.5)))
                    case _:
                        texture = pygame.transform.scale_by(texture, constant.SCALING_CASE)
                        ecran.blit(texture, CaseCliquable.getListeCaseCliquable()[i].rect)

            # Affichage du portail du boss
            if plat.listeCases[i].portail:
                ecran.blit(portail.envoiSprite(),
                           (CaseCliquable.getListeCaseCliquable()[i].rect.x+((CaseCliquable.getListeCaseCliquable()[i].rect.width)/2)-(portail.envoiSprite().get_width()/2),
                            CaseCliquable.getListeCaseCliquable()[i].rect.y+((CaseCliquable.getListeCaseCliquable()[i].rect.height)/2)-(portail.envoiSprite().get_height()/2)))

            # Si la case a un piège, on affiche la texture du piège au centre de la case
            if plat.listeCases[i].piege != "":
                match plat.listeCases[i].piege:
                    case "piege_a_ours": texture = pygame.image.load(constant.CHEMIN_PIEGE_A_OURS).subsurface(0, 0, 32, 32)
                    case "bombe": texture = pygame.image.load(constant.CHEMIN_BOMBE)
                texture = pygame.transform.scale_by(texture, constant.SCALING_PIEGE)
                ecran.blit(texture,
                           (CaseCliquable.getListeCaseCliquable()[i].rect.x+((CaseCliquable.getListeCaseCliquable()[i].rect.width)/2)-(texture.get_width()/2),
                            CaseCliquable.getListeCaseCliquable()[i].rect.y+((CaseCliquable.getListeCaseCliquable()[i].rect.height)/2)-(texture.get_height()/2)+10))

            # Si la case a un coffre, on affiche la texture du coffre au centre de la case
            if plat.listeCases[i].coffre:
                texture = pygame.image.load(constant.CHEMIN_COFFRE)
                texture = pygame.transform.scale_by(texture, constant.SCALING_COFFRE)
                ecran.blit(texture,
                           (CaseCliquable.getListeCaseCliquable()[i].rect.x+((CaseCliquable.getListeCaseCliquable()[i].rect.width)/2)-(texture.get_width()/2),
                            CaseCliquable.getListeCaseCliquable()[i].rect.y+((CaseCliquable.getListeCaseCliquable()[i].rect.height)/2)-(texture.get_height()/2)-10))

            # On affiche les pions des joueurs sur les cases cliquables
            for j in range(len(Joueur.getAllJoueur())):
                if Joueur.getAllJoueur()[j].emplacement == i:
                    pion = pygame.image.load(constant.CHEMIN_PION)
                    pion = pion.subsurface((j*11, 0, 11, 19))
                    if j < 2:
                        ecran.blit(pion,
                                   (CaseCliquable.getListeCaseCliquable()[i].rect.x+((CaseCliquable.getListeCaseCliquable()[i].rect.width)/2)-22+(j*3*11),
                                    CaseCliquable.getListeCaseCliquable()[i].rect.y+((CaseCliquable.getListeCaseCliquable()[i].rect.height)/2)-19))
                    else:
                        ecran.blit(pion,
                                   (CaseCliquable.getListeCaseCliquable()[i].rect.x+((CaseCliquable.getListeCaseCliquable()[i].rect.width)/2)-22+((j-2)*3*11),
                                    CaseCliquable.getListeCaseCliquable()[i].rect.y+((CaseCliquable.getListeCaseCliquable()[i].rect.height)/2)))

            # On affiche les mini-figures des ennemis sur les cases cliquables
            for j in range(len(plat.listeCases[i].listeEnnemis)):
                spriteEnnemi = pygame.transform.scale_by(pygame.image.load(fr"{constant.REPERTOIRE_COURANT}/ressources/sprites/mini_{plat.listeCases[i].listeEnnemis[j].nom.lower()}.png"),
                                                         constant.SCALING_MINI_FIGURES)
                if j < 2:
                    ecran.blit(spriteEnnemi,
                               (CaseCliquable.getListeCaseCliquable()[i].rect.x+((CaseCliquable.getListeCaseCliquable()[i].rect.width)/2)-22+(j*2*16),
                                CaseCliquable.getListeCaseCliquable()[i].rect.y+((CaseCliquable.getListeCaseCliquable()[i].rect.height)/2)-24))
                else:
                    ecran.blit(spriteEnnemi, 
                               (CaseCliquable.getListeCaseCliquable()[i].rect.x+((CaseCliquable.getListeCaseCliquable()[i].rect.width)/2)-22+((j-2)*2*16),
                                CaseCliquable.getListeCaseCliquable()[i].rect.y+((CaseCliquable.getListeCaseCliquable()[i].rect.height)/2)))

            # Affichage des cercles indiquant les déplacements possibles
            if plat.listeCases[i].deplacementPossible:
                pygame.draw.circle(ecran,
                                   pygame.Color(255,0,0),
                                   center=(CaseCliquable.getListeCaseCliquable()[i].rect.x+((CaseCliquable.getListeCaseCliquable()[i].rect.width)/2),
                                    CaseCliquable.getListeCaseCliquable()[i].rect.y+((CaseCliquable.getListeCaseCliquable()[i].rect.height)/2)),
                                   radius=30, width=1)


    @staticmethod
    def getCaseClick() -> int|None:
        """
        Renvoie l'indice de la case cliquée

        Returns:
        int|None: L'indice de la case cliquée ou None si aucune case n'a été cliquée
        """
        for i in range(len(CaseCliquable.getListeCaseCliquable())):
            if CaseCliquable.getListeCaseCliquable()[i].rect.collidepoint(pygame.mouse.get_pos()):
                return i
        return None

    @staticmethod
    def init_cases():
        """Initialise toutes les cases cliquables. Non dynamique, il faut modifier les coordonnées à la main pour apporter des
        modifications à la disposition des cases."""
        for i in range(constant.TAILLE_PLATEAU):
            if (i >= 0 and i <= 2):
                CaseCliquable(OrientationCase.Horizontal, (840+(i*64*constant.SCALING_CASE), 520))
            elif i == 3:
                CaseCliquable(OrientationCase.Coin_Bas_Droit, (1080, 520))
            elif (i >= 4 and i <= 7):
                CaseCliquable(OrientationCase.Vertical, (1080, 440-((i-4)*64*constant.SCALING_CASE)))
            elif i == 8:
                CaseCliquable(OrientationCase.Coin_Haut_Droit, (1080, 80))
            elif (i >= 9 and i <= 14):
                CaseCliquable(OrientationCase.Horizontal, (1000-((i-9)*64*constant.SCALING_CASE), 80))
            elif i == 15:
                CaseCliquable(OrientationCase.Coin_Haut_Gauche, (480, 80))
            elif (i >= 16 and i <= 19):
                CaseCliquable(OrientationCase.Vertical, (480, 200+((i-16)*64*constant.SCALING_CASE)))
            elif (i == 20):
                CaseCliquable(OrientationCase.Coin_Bas_Gauche, (480, 520))
            elif (i >= 21 and i <= 23):
                CaseCliquable(OrientationCase.Horizontal, (600+((i-21)*64*constant.SCALING_CASE), 520))
                
    @staticmethod
    def getCaseRandom() -> int|None:
        """
        Renvoie l'indice d'une case cliquable choisi au hasard

        Returns:
        int|None: L'indice de la case cliquée ou None si aucune case n'a été cliquée
        """
        return random.choice(range(len(CaseCliquable.getListeCaseCliquable())))