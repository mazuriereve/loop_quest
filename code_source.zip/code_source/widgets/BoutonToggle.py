from __future__ import annotations
from widgets.Bouton import Bouton
import pygame

class BoutonToggle(Bouton):
    """Classe modélisant un bouton toggle héritant de la classe Bouton"""
    
    def __init__(self: BoutonToggle, texte: str, couleurSurface: tuple[int, int, int], couleurPolice: tuple[int, int, int], position: tuple[int, int]):
        """Constructeur

        Args:
         - texte (str): Texte à afficher sur le bouton
         - couleurSurface (tuple[int, int, int]): Couleur de fond du bouton
         - couleurPolice (tuple[int, int, int]): Couleur du texte du bouton
         - position (tuple[int, int]): Position du bouton sur l'écran
        """
        super().__init__(texte, couleurSurface, couleurPolice, position)
        self._active: bool = False
        self._couleurInactive: tuple[int, int, int] = (255, 0, 0)
        self._couleurActive: tuple[int, int, int] = (150, 150, 150)
        self._couleurSurface = self._couleurInactive
        
        
    
    @property
    def active(self: BoutonToggle) -> bool: return self._active
    
    def estClique(self: BoutonToggle) -> bool:
        if super().estClique():
            self._active = not self._active
            
        self.mettreAJourSurface()
        
        return self._active

    def mettreAJourSurface(self: BoutonToggle):
        """Met à jour la surface du bouton en fonction de son état"""
        bord1 = pygame.Surface((self._rect.width, 2))
        bord1.fill((150, 150, 150) if self._active else (255, 255, 255))
        bord2 = pygame.Surface((2, self._rect.height+2))
        bord2.fill((50, 50, 50) if self._active else (255, 255, 255))
        bord3 = pygame.Surface((self._rect.width, 2))
        bord3.fill((50, 50, 50) if self._active else (255, 255, 255))
        bord4 = pygame.Surface((2, self._rect.height+2))
        bord4.fill((150, 150, 150) if self._active else (255, 255, 255))

        self._couleurSurface = self._couleurActive if self._active else self._couleurInactive

        self._surface.fill(self._couleurSurface)
        self._surface.blit(bord1, (0, 0))
        self._surface.blit(bord2, (0, 0))
        self._surface.blit(bord3, (0, self._rect.height))
        self._surface.blit(bord4, (self._rect.width-2, 0))
        self._surface.blit(self._font.render(self._texte, True, self._couleurPolice), (2, 2))
