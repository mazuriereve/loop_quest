from __future__ import annotations

from personnage.Joueur import Joueur
from cartes.Carte import Carte
from cartes.ListeCartes import ListeCartes
from cartes.TypeCarte import TypeCarte
from plateau import Plateau
from widgets.WidgetCarte import WidgetCarte
from widgets.Bouton import Bouton
from widgets.genererBoutonRandom import genererBoutonRandom
from widgets.MagasinBoutonStat import MagasinBoutonStat
import constant

import pygame
class PageMagasin:  
    
    def __init__(self: PageMagasin, plat: Plateau, joueurActuel: int):
        self._surface: pygame.Surface = pygame.Surface((880, 720))
        self._cartes: list[Carte] = [ListeCartes.genererCarteAleatoire(plat, joueurActuel) for _ in range(4)]
        self._joueurActuel: int = joueurActuel
        self._widgets: list[list[WidgetCarte], bool] = []
        self._boutonsStats: list[list[MagasinBoutonStat, bool]] = []
        self._bouton: Bouton = Bouton(" Acheter ", (100, 100, 100), (255, 255, 255), (0, 650))
        self._boutonQuitter: Bouton = Bouton(" Quitter ", (100, 100, 100), (255, 255, 255), (0, 10))
        self._boutonQuitter.position = (870-self._boutonQuitter.rect.width, 10)
        
        for i in range(len(self._cartes)):
            self._widgets.append(
                [
                    WidgetCarte(
                        self._cartes[i].nom.replace("_", " "),
                        self._cartes[i].description,
                        i,
                        fr"{constant.REPERTOIRE_COURANT}/ressources/icones/icone_{self._cartes[i].nom.lower()}.png",
                        (204, 102, 0) if self._cartes[i].typeCarte in [TypeCarte.Plateau, TypeCarte.Case, TypeCarte.Utilisable, TypeCarte.Placable] else (0, 204, 102),
                        selectionne=False
                    ),
                    False
                ]
            )
        
        joueur = Joueur.getAllJoueur()[self._joueurActuel]
        for i in range(4):
            self._boutonsStats.append([genererBoutonRandom((100, 100), (0 , 0), joueur.attaque, joueur.defense, joueur.pointDeVieMax, joueur.vitesse), False])
        
    @property
    def surface(self: PageMagasin) -> pygame.Surface: return self._surface
    
    @property
    def cartes(self: PageMagasin) -> list[Carte]: return self._cartes
    
    @cartes.setter
    def cartes(self: PageMagasin, cartes: list[Carte]): self._cartes = cartes
    
    @property
    def widgets(self: PageMagasin) -> list[tuple[WidgetCarte], int, bool]: return self._widgets
    
    @widgets.setter
    def widgets(self: PageMagasin, widgets: list[tuple[WidgetCarte], int, bool]): self._widgets = widgets
    
    @property
    def boutonsStats(self: PageMagasin) -> list[list[MagasinBoutonStat, bool]]: return self._boutonsStats
    
    @boutonsStats.setter
    def boutonsStats(self: PageMagasin, boutonStats: list[list[MagasinBoutonStat, bool]]): self._boutonsStats = boutonStats
    
    @property
    def bouton(self: PageMagasin) -> Bouton: return self._bouton
    
    @bouton.setter
    def bouton(self: PageMagasin, bouton: Bouton): self._bouton = bouton
    
    @property
    def boutonQuitter(self: PageMagasin) -> Bouton: return self._boutonQuitter
    
    @boutonQuitter.setter
    def boutonQuitter(self: PageMagasin, boutonQuitter: Bouton): self._boutonQuitter = boutonQuitter
    
    def afficher(self: PageMagasin, ecran: pygame.Surface, selectedInBarLat: bool):
        # Initialisation de la surface, de la police et de l'icône de pièce
        self._surface.fill(pygame.Color(200, 200, 200))
        font = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 30)
        original_icone_piece = pygame.image.load(fr"{constant.REPERTOIRE_COURANT}/ressources/icones/icone_piece.png")
        original_icone_piece = pygame.transform.scale(original_icone_piece, (30, 30))
        
        pygame.draw.line(self._surface, pygame.Color(0, 0, 0), (self._surface.get_width()//2, 100), (self._surface.get_width()//2, self._surface.get_height()-100), 4)
        
        argentJoueur = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 50).render(f"{Joueur.getAllJoueur()[self._joueurActuel].argent} ", True, pygame.Color(0, 0, 0))
        self._surface.blit(argentJoueur, (20, 20))
        icone_piece = pygame.transform.scale(original_icone_piece, (50, 50))
        self._surface.blit(icone_piece, (20+argentJoueur.get_rect().width, 20))
        
        # Affichage des cartes
        for i in range(len(self._widgets)):
            if self._widgets[i][1]:
                self._widgets[i][0].couleur = pygame.Color(100, 100, 100)
                self._widgets[i][0].icone = pygame.transform.grayscale(self._widgets[i][0].icone)
                texte = font.render(f"{self._cartes[i].valeur} ", True, pygame.Color(50, 50, 50))
                icone_piece = pygame.transform.grayscale(original_icone_piece)
            else:
                texte = font.render(f"{self._cartes[i].valeur} ", True, pygame.Color(0, 0, 0) if self._cartes[i].valeur <= Joueur.getAllJoueur()[self._joueurActuel].argent else pygame.Color(255, 0, 0))
                icone_piece = original_icone_piece
            self._widgets[i][0].afficher(self._surface, ((400-60)//2, (720-150-40)//3), (32+(34+170)*(i%2), 140+((i//2)*(16+(16+176+40)*(i//2)))))
            # texte = font.render(f"{self._cartes[i].valeur} ", True, pygame.Color(0, 0, 0) if self._cartes[i].valeur <= Joueur.getAllJoueur()[self._joueurActuel].argent else pygame.Color(255, 0, 0))
            self._surface.blit(texte, (32+(170-texte.get_rect().width-30)//2+(34+170)*(i%2), 150+((i//2)*(16+(16+176+40)*(i//2)))+170))
            self._surface.blit(icone_piece, (32+(170-texte.get_rect().width+30)//2+(34+170)*(i%2), 150+((i//2)*(16+(16+176+40)*(i//2)))+170))
        
        for i in range(len(self._boutonsStats)):
            self._boutonsStats[i][0].position = (
                self._surface.get_width()-(self._surface.get_width()//2-2*self._boutonsStats[i][0].taille[0])*(2-(i%2)*1)/3-(2-(i%2)*1)*self._boutonsStats[i][0].taille[0],
                200+((i//2)*200)
            )
            self._boutonsStats[i][0].afficher(self._surface)
            
            if self._boutonsStats[i][1]:
                texte = font.render(f"{self._boutonsStats[i][0].valeurBonus} {self._boutonsStats[i][0].nom}", True, pygame.Color(50, 50, 50))
                texte2 = font.render(f"{self._boutonsStats[i][0].prix} ", True, pygame.Color(50, 50, 50))
                icone_piece = pygame.transform.grayscale(original_icone_piece)
            else:
                texte = font.render(f"{self._boutonsStats[i][0].valeurBonus} {self._boutonsStats[i][0].nom}", True, pygame.Color(0, 0, 0) if self._boutonsStats[i][0].prix <= Joueur.getAllJoueur()[self._joueurActuel].argent else pygame.Color(255, 0, 0))
                texte2 = font.render(f"{self._boutonsStats[i][0].prix} ", True, pygame.Color(0, 0, 0) if self._boutonsStats[i][0].prix <= Joueur.getAllJoueur()[self._joueurActuel].argent else pygame.Color(255, 0, 0))
                icone_piece = original_icone_piece
            self._surface.blit(
                texte,
                (
                    self._surface.get_width()-(self._surface.get_width()//2-2*self._boutonsStats[i][0].taille[0])*(2-(i%2)*1)/3-(2-(i%2)*1)*self._boutonsStats[i][0].taille[0]+(self._boutonsStats[i][0].taille[0]-texte.get_rect().width+original_icone_piece.get_width())//2,
                    205+((i//2)*200)+self._boutonsStats[i][0].taille[1]
                )
            )
            self._surface.blit(
                texte2,
                (
                    self._surface.get_width()-(self._surface.get_width()//2-2*self._boutonsStats[i][0].taille[0])*(2-(i%2)*1)/3-(2-(i%2)*1)*self._boutonsStats[i][0].taille[0]+(self._boutonsStats[i][0].taille[0]-texte2.get_rect().width+30)//2,
                    235+((i//2)*200)+self._boutonsStats[i][0].taille[1]
                )
            )
            self._surface.blit(
                icone_piece, 
                (
                    self._surface.get_width()-(self._surface.get_width()//2-2*self._boutonsStats[i][0].taille[0])*(2-(i%2)*1)/3-(2-(i%2)*1)*self._boutonsStats[i][0].taille[0]+(self._boutonsStats[i][0].taille[0]-texte2.get_rect().width+30)//2-30,
                    235+((i//2)*200)+self._boutonsStats[i][0].taille[1]
                )
            )
        
        # Affichage des boutons
        if selectedInBarLat == False:
            self._bouton = Bouton(" Acheter ", (100, 100, 100), (255, 255, 255), (0, 650))
        else:
            self._bouton = Bouton(" Vendre ", (100, 100, 100), (255, 255, 255), (0, 650))
        self._bouton.position = (self._surface.get_width()//2-self._bouton.rect.width//2, 650)
        
        self._bouton.afficher(self._surface)
        self._boutonQuitter.afficher(self._surface)
        
        ecran.blit(self._surface, (400, 0))
        pygame.display.flip()
        
