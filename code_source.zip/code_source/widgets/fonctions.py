# ------------------ CLASSES -------------------- #
# Classes permettant de modéliser différents      #
# widgets à afficher sur l'écran de jeu et        #
# permettant l'interaction avec l'utilisateur     #
# ----------------------------------------------- #
from __future__ import annotations



import pygame


# ------------------ FONCTIONS -------------------- #
# Fonctions permettant de gérer certains aspects de #
# l'affichage.                                      #
# ------------------------------------------------- #

def contourRect(rect: pygame.Rect, couleur: pygame.Color, largeur: int) -> list[tuple[pygame.Surface, tuple[int, int]]]:
    """
    Retourne une liste de tuples contenant chacun une surface et une position, permettant de dessiner les contours d'un rectangle.

    Args:
    - rect: un objet pygame.Rect représentant le rectangle à contourner
    - couleur: un objet pygame.Color représentant la couleur du contour
    - largeur: un entier représentant la largeur du contour

    Returns:
    - Une liste de tuples contenant chacun une surface et une position, permettant de dessiner les contours d'un rectangle.
    """
    bord1 = pygame.Surface((rect.width, largeur)) ; bord1.fill(couleur)
    bord2 = pygame.Surface((rect.width, largeur)) ; bord2.fill(couleur)
    bord3 = pygame.Surface((largeur, rect.height)) ; bord3.fill(couleur)
    bord4 = pygame.Surface((largeur, rect.height)) ; bord4.fill(couleur)
    return [(bord1, (rect.x, rect.y)), (bord2, (rect.x, rect.y+rect.height-largeur)), (bord3, (rect.x, rect.y)), (bord4, (rect.x+rect.width-largeur, rect.y))]
