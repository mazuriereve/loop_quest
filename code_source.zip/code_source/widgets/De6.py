from __future__ import annotations
import constant


import pygame


from random import randint


class De6:
    """Classe modélisant un dé à 6 faces et gérant son affichage"""
    # Constructeur
    def __init__(self: De6, position: tuple[int, int] = (0, 0)):
        """Constructeur

        Args:
         - position (tuple[int, int], optional): Position du dé sur l'écran. Par défaut (0, 0).
        """
        self._spriteSheetNormal = pygame.image.load(constant.CHEMIN_DE6).subsurface(0, 0, 6*16, 16)
        self._spriteSheetLancer = pygame.image.load(constant.CHEMIN_DE6).subsurface(0, 14*16, 6*16, 16)
        self._position = position
        self._valeur = 1

    # Getters et setters
    @property
    def spriteSheetNormal(self: De6) -> pygame.Surface: return self._spriteSheetNormal

    @property
    def spriteSheetLancer(self: De6) -> pygame.Surface: return self._spriteSheetLancer

    @property
    def position(self: De6) -> tuple[int, int]: return self._position

    @position.setter
    def position(self: De6, position: tuple[int, int]): self._position = position

    @property
    def valeur(self: De6) -> int: return self._valeur

    @valeur.setter
    def valeur(self: De6, valeur: int): self._valeur = valeur

    # Méthodes
    def lancer(self: De6):
        """Lance le dé et modifie sa valeur"""
        self._valeur = randint(1, 6)

    def afficher(self: De6, ecran: pygame.Surface):
            """
            Affiche le dé sur l'écran.

            Args:
             - ecran (pygame.Surface): Surface de l'écran sur laquelle afficher le dé.
            """
            texture = pygame.transform.scale_by(self.spriteSheetNormal.subsurface((self._valeur-1)*16, 0, 16, 16), constant.SCALING_DE6)
            ecran.blit(texture, self._position)

    def afficherLancer(self: De6, ecran: pygame.Surface):
            """
            Gère l'animation du lancer du dé et le changement de sa valeur.

            Args:
             - ecran (pygame.Surface): Surface sur laquelle le dé sera affiché.
            """
            self.lancer()
            for i in range(6):
                pygame.draw.rect(ecran, pygame.Color(156,219,67), pygame.Rect(self.position[0], self.position[1], 48, 48))
                texture = pygame.transform.scale_by(self.spriteSheetLancer.subsurface(i*16, 0, 16, 16), constant.SCALING_DE6)
                ecran.blit(texture, self.position)
                pygame.display.flip()
                pygame.time.delay(100)
            self.afficher(ecran)