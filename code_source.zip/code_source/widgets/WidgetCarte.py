from __future__ import annotations
import constant


import pygame


class WidgetCarte:
    """Classe modélisant un widget représentatif d'une carte"""
    def __init__(self: WidgetCarte, nom: str, description: str, index: int, cheminIcone: str, couleur: tuple[int, int, int], selectionne: bool = False):
        """
        Initialise un widget représentatif d'une carte

        Args:
            nom (str): Le nom de la carte.
            description (str): La description de la carte.
            index (int): L'index de la carte dans la liste des cartes.
            cheminIcone (str): Le chemin vers l'icône de la carte.
            couleur (tuple[int, int, int]): La couleur de la carte.
            selectionne (bool, optional): Si la carte est sélectionnée ou non. Par défaut False.
        """
        self._fontNom = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 20)
        self._nom = nom
        self._fontDesc = pygame.font.SysFont("arial", 15, True)
        self._description = description
        self._index = index
        self._icone = pygame.image.load(cheminIcone)
        self._couleur = pygame.Color(couleur[0], couleur[1], couleur[2])
        self._fondIcone: pygame.Surface
        self._fondCarte: pygame.Surface
        self._contourCarte: pygame.Surface
        self._rect: pygame.Rect
        self._surface: pygame.Surface
        self._selectionne: bool = selectionne

    @property
    def nom(self: WidgetCarte) -> str: return self._nom

    @nom.setter
    def nom(self: WidgetCarte, nom: str): self._nom = nom

    @property
    def index(self: WidgetCarte) -> int: return self._index

    @index.setter
    def index(self: WidgetCarte, index: int): self._index = index

    @property
    def icone(self: WidgetCarte) -> pygame.Surface: return self._icone

    @icone.setter
    def icone(self: WidgetCarte, icone: pygame.Surface): self._icone = icone

    @property
    def couleur(self: WidgetCarte) -> pygame.Color: return self._couleur

    @couleur.setter
    def couleur(self: WidgetCarte, couleur: pygame.Color): self._couleur = couleur

    @property
    def fondIcone(self: WidgetCarte) -> pygame.Surface: return self._fondIcone

    @fondIcone.setter
    def fondIcone(self: WidgetCarte, fondIcone: pygame.Surface): self._fondIcone = fondIcone

    @property
    def fondCarte(self: WidgetCarte) -> pygame.Surface: return self._fondCarte

    @fondCarte.setter
    def fondCarte(self: WidgetCarte, fondCarte: pygame.Surface): self._fondCarte = fondCarte

    @property
    def contourCarte(self: WidgetCarte) -> pygame.Surface: return self._contourCarte

    @contourCarte.setter
    def contourCarte(self: WidgetCarte, contourCarte: pygame.Surface): self._contourCarte = contourCarte

    @property
    def rect(self: WidgetCarte) -> pygame.Rect: return self._rect

    @rect.setter
    def rect(self: WidgetCarte, rect: pygame.Rect): self._rect = rect
    
    @property
    def selectionne(self: WidgetCarte) -> bool: return self._selectionne
    
    @selectionne.setter
    def selectionne(self: WidgetCarte, selectionne: bool): self._selectionne = selectionne

    def afficher(self: WidgetCarte, ecran: pygame.Surface, taille: tuple[int, int], position: tuple[int, int]):
        """Affiche le widget représentatif d'une carte à l'écran

        Args:
            ecran (pygame.Surface): La surface sur laquelle afficher la carte
            taille (tuple[int, int]): La taille de la carte
            position (tuple[int, int]): La position de la carte sur la surface
        """
        self._surface = pygame.Surface(taille)
        self._rect = self._surface.get_rect()
        self._rect.x = position[0] ; self._rect.y = position[1]
        self._fondCarte = pygame.Surface((taille[0]-6, taille[1]-6))
        self._fondCarte.fill(self._couleur)
        self._contourCarte = pygame.Surface((taille[0], taille[1]))
        if self._selectionne:
            self._contourCarte.fill(pygame.Color(255, 255, 0))
        else:
            self._contourCarte.fill(pygame.Color(0, 0, 0))
        self._surface.blit(self._contourCarte, (0, 0))
        self._surface.blit(self._fondCarte, (3, 3))
        lignesNom = self._nom.split("\n")
        for i in range(len(lignesNom)):
            lignesNomRend = self._fontNom.render(lignesNom[i], True, (255, 255, 255))
            self._surface.blit(lignesNomRend, (self._rect.width/2-lignesNomRend.get_width()/2, 5+(i*15)))
        # self._surface.blit(self._fontNom.render(self._nom, True, (255, 255, 255)), (self._rect.width/2-self._fontNom.render(self._nom, True, (255, 255, 255)).get_width()/2, 5))
        self._fondIcone = pygame.Surface((self._fondCarte.get_width()-20, self._icone.get_height()+10))
        self._fondIcone.fill(pygame.Color(255, 255, 255))
        self._surface.blit(self._fondIcone, (12, self._fontNom.render(self._nom, True, (255, 255, 255)).get_height()*(len(lignesNom))+10))
        self._surface.blit(self._icone, (self._rect.width/2-self._icone.get_width()/2, self._fontNom.render(self._nom, True, (255, 255, 255)).get_height()*(len(lignesNom))+15))
        lignesDesc = self._description.split("\n")
        for i in range(len(lignesDesc)):
            lignesDescRend = self._fontDesc.render(lignesDesc[i], True, (0, 0, 0))
            self._surface.blit(
                lignesDescRend,
                (
                    self._rect.width/2-lignesDescRend.get_width()/2,
                    self._fontNom.render(self._nom, True, (255, 255, 255)).get_height()*(len(lignesNom))+self._icone.get_height()+25+(i*15)
                )
            )
        ecran.blit(self._surface, position)

    def estClique(self: WidgetCarte, pos: tuple[int, int] = None) -> bool:
        """Vérifie si la souris se trouve sur la carte.

        Returns:
            bool: Le résultat de la vérification
        """
        if pos is None:
            pos = pygame.mouse.get_pos()
        
        return self._rect.collidepoint(pos)