from enum import Enum


class OrientationCase(Enum):
    """Orientation possible d'une case cliquable"""
    Horizontal = 0
    Vertical = 1
    Coin_Bas_Droit = 2
    Coin_Haut_Droit = 3
    Coin_Haut_Gauche = 4
    Coin_Bas_Gauche = 5