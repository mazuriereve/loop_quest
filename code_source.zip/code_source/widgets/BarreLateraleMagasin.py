from __future__ import annotations

import pygame
from enum import Enum

from cartes.TypeCarte import TypeCarte
from widgets.BarreLaterale import BarreLaterale
from widgets.Bouton import Bouton
from personnage.Joueur import Joueur
from widgets.WidgetCarte import WidgetCarte
import constant


class AffichageBarreLaterale(Enum):
    PLATEAU = 1
    COMBAT = 2
    STATS = 3

class BarreLateraleMagasin(BarreLaterale):
    def __init__(self: BarreLateraleMagasin):
        super().__init__()
        
        self._boutonPlateau: Bouton = Bouton(" Plateau ", (100, 100, 100), (255, 255, 255), (0, 0))
        self._boutonPlateau.actif = True
        self._boutonCombat: Bouton = Bouton(" Combat ", (100, 100, 100), (255, 255, 255), (0, 0))
        self._boutonStatistiques: Bouton = Bouton(" Stats ", (100, 100, 100), (255, 255, 255), (0, 0))
        
    @property
    def boutonPlateau(self: BarreLateraleMagasin) -> Bouton: return self._boutonPlateau
    
    @boutonPlateau.setter
    def boutonPlateau(self: BarreLateraleMagasin, boutonPlateau: Bouton): self._boutonPlateau = boutonPlateau
    
    @property
    def boutonCombat(self: BarreLateraleMagasin) -> Bouton: return self._boutonCombat
    
    @boutonCombat.setter
    def boutonCombat(self: BarreLateraleMagasin, boutonCombat: Bouton): self._boutonCombat = boutonCombat
    
    @property
    def boutonStatistiques(self: BarreLateraleMagasin) -> Bouton: return self._boutonStatistiques
    
    @boutonStatistiques.setter
    def boutonStatistiques(self: BarreLateraleMagasin, boutonStatistiques: Bouton): self._boutonStatistiques = boutonStatistiques
    
    def afficher(self: BarreLateraleMagasin, ecran: pygame.Surface, joueurActuel: int, index_widget_select: int = None, affichage: AffichageBarreLaterale = AffichageBarreLaterale.PLATEAU, capacite: bool = True):
        """Affiche la barre latérale et les différents widgets la composant à l'écran

        Args:
            ecran (pygame.Surface): La surface sur laquelle afficher la barre latérale
            joueurActuel (int): Le numéro du joueur actuel
            combat (bool, optional): Sert à vérifier quelle carte afficher. Defaults to False.
        """
        # Affichage de la barre
        self._texteEntete = self._fontEntete.render(f"{Joueur.getAllJoueur()[joueurActuel].nom} - {Joueur.getAllJoueur()[joueurActuel].niveau}", True, (255, 255, 255))
        self._surface.fill(pygame.Color(50,50,50))
        self._surface.blit(self._texteEntete, (self._rect.width/2-self._texteEntete.get_width()/2, 5))
        self._surface.blit(self._labelBDV, (10, 50))
        self._barreDeVie.fill(pygame.Color(255, 0, 0))
        self._barreDeVie.fill(
            pygame.Color(0, 255, 0),
            pygame.Rect(0, 0, (self._rect.width-20-self._labelBDV.get_width())*(Joueur.getAllJoueur()[joueurActuel].pointDeVie/Joueur.getAllJoueur()[joueurActuel].pointDeVieMax), 30)
        )
        self._surface.blit(self._barreDeVie, (self._labelBDV.get_width()+10, 50))
        self._surface.blit(self._labelEXP, (10, 90))
        self._barreEXP.fill(pygame.Color(0, 0, 153))
        self._barreEXP.fill(
            pygame.Color(0, 255, 255),
            pygame.Rect(0, 0, (self._rect.width-20-self._labelEXP.get_width())*(Joueur.getAllJoueur()[joueurActuel].pointExperience/Joueur.getAllJoueur()[joueurActuel]._pointExperienceMax), 30))
        self._surface.blit(self._barreEXP, (self._labelEXP.get_width()+10, 90))
        ecran.blit(self._surface, self._rect)

        # Récupération des différents widgets cartes.
        self._widgetCartes = []
        if affichage == AffichageBarreLaterale.PLATEAU:
            for i in range(len(Joueur.getAllJoueur()[joueurActuel].cartes)):
                c = Joueur.getAllJoueur()[joueurActuel].cartes[i]
                if c.typeCarte in [TypeCarte.Plateau, TypeCarte.Case, TypeCarte.Utilisable, TypeCarte.Placable]:
                    self._widgetCartes.append(WidgetCarte(
                        c.nom.replace("_", " "),
                        c.description,
                        i,
                        fr"{constant.REPERTOIRE_COURANT}/ressources/icones/icone_{c.nom.lower()}.png",
                        (204, 102, 0),
                        (len(self._widgetCartes) == index_widget_select)
                    ))
        elif affichage == AffichageBarreLaterale.COMBAT:
            for i in range(len(Joueur.getAllJoueur()[joueurActuel].cartes)):
                c = Joueur.getAllJoueur()[joueurActuel].cartes[i]
                if c.typeCarte in [TypeCarte.Consommable]:
                    self._widgetCartes.append(WidgetCarte(
                        c.nom.replace("_", " "),
                        c.description,
                        i,
                        fr"{constant.REPERTOIRE_COURANT}/ressources/icones/icone_{c.nom.lower()}.png",
                        (0, 204, 102),
                        (len(self._widgetCartes) == index_widget_select)
                    ))
        elif affichage == AffichageBarreLaterale.STATS:
            texteClasse = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 30).render(f"Classe : {Joueur.getAllJoueur()[joueurActuel].nomClasse}", True, (250, 250, 250))
            texteAttaque = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 30).render(f"Attaque : {Joueur.getAllJoueur()[joueurActuel].attaque}", True, (250, 250, 250))
            texteDefense = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 30).render(f"Défense : {Joueur.getAllJoueur()[joueurActuel].defense}", True, (250, 250, 250))
            texteVitesse = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 30).render(f"Vitesse : {Joueur.getAllJoueur()[joueurActuel].vitesse}", True, (250, 250, 250))
            textePointDeVie = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 30).render(f"PV : {Joueur.getAllJoueur()[joueurActuel].pointDeVie} - Max : {Joueur.getAllJoueur()[joueurActuel].pointDeVieMax}", True, (250, 250, 250))
            texteCapacite = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 30).render(f"Capacité spéciale :", True, (250, 250, 250))
            texteCapacite2 = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 30).render(f"•{Joueur.getAllJoueur()[joueurActuel].capaciteSpeciale.name.replace('_', ' ')}", True, (250, 250, 250))
            texteCapacite3 = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 30).render(f"•{'Disponible' if Joueur.getAllJoueur()[joueurActuel].capaciteDisponible else 'Indisponible'}", True, (0, 250, 0) if Joueur.getAllJoueur()[joueurActuel].capaciteDisponible else (250, 0, 0))
            
            ecran.blit(texteClasse, (10, 150))
            ecran.blit(texteAttaque, (10, 200))
            ecran.blit(texteDefense, (10, 250))
            ecran.blit(texteVitesse, (10, 300))
            ecran.blit(textePointDeVie, (10, 350))
            ecran.blit(texteCapacite, (10, 400))
            ecran.blit(texteCapacite2, (10, 440))
            ecran.blit(texteCapacite3, (10, 480))

        # Affichage des widgets de cartes sur trois lignes et deux colonnes
        for i in range(len(self._widgetCartes)):
            self._widgetCartes[i].afficher(ecran, ((400-60)//2, (720-150-40)//3), (10+((i%2)*(20+(400-30)//2)), 150+((i//2)*(10+(720-150-40)//3))))
            
        # Affichage des boutons
        self._boutonPlateau.position = (400-(self._boutonPlateau.rect.width+(200-self._boutonPlateau.rect.width)//2), 550)
        self._boutonPlateau.afficher(ecran)
        
        self._boutonCombat.position = (400-(self._boutonCombat.rect.width+(200-self._boutonCombat.rect.width)//2), 600)
        self._boutonCombat.afficher(ecran)
        
        self._boutonStatistiques.position = (400-(self._boutonStatistiques.rect.width+(200-self._boutonStatistiques.rect.width)//2), 650)
        self._boutonStatistiques.afficher(ecran)