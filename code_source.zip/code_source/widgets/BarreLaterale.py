from __future__ import annotations
from cartes.TypeCarte import TypeCarte
import constant
from personnage.Joueur import Joueur
from personnage.CapaciteSpeciale import CapaciteSpeciale
from widgets.WidgetCarte import WidgetCarte


import pygame


class BarreLaterale:
    """Classe gérant la structure et l'affichage de la barre latérale à l'écran."""
    # Constructeur
    def __init__(self: BarreLaterale):
        self._surface = pygame.Surface((400, 720))
        self._surface.fill(pygame.Color(156,219,67))
        self._rect = self._surface.get_rect()
        self._rect.x = 0 ; self._rect.y = 0
        self._fontEntete = pygame.font.Font(constant.CHEMIN_POLICE_TITRE, 40)
        self._fontNormal = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 30)
        self._texteEntete = self._fontEntete.render("", True, (255, 255, 255))
        self._labelBDV = self._fontNormal.render("PV ", True, (255, 255, 255))
        self._barreDeVie = pygame.Surface((self._rect.width-20-self._labelBDV.get_width(), 30))
        self._labelEXP = self._fontNormal.render("EXP ", True, (255, 255, 255))
        self._barreEXP = pygame.Surface((self._rect.width-20-self._labelEXP.get_width(), 30))
        self._widgetCartes: list[WidgetCarte]

    # Getters et setters
    @property
    def surface(self: BarreLaterale) -> pygame.Surface: return self._surface

    @surface.setter
    def surface(self: BarreLaterale, surface: pygame.Surface): self._surface = surface

    @property
    def rect(self: BarreLaterale) -> pygame.Rect: return self._rect

    @rect.setter
    def rect(self: BarreLaterale, rect: pygame.Rect): self._rect = rect

    @property
    def fontEntete(self: BarreLaterale) -> pygame.font.Font: return self._fontEntete

    @fontEntete.setter
    def fontEntete(self: BarreLaterale, fontEntete: pygame.font.Font): self._fontEntete = fontEntete

    @property
    def fontNormal(self: BarreLaterale) -> pygame.font.Font: return self._fontNormal

    @fontNormal.setter
    def fontNormal(self: BarreLaterale, fontNormal: pygame.font.Font): self._fontNormal = fontNormal

    @property
    def texteEntete(self: BarreLaterale) -> str: return self._texteEntete

    @texteEntete.setter
    def texteEntete(self: BarreLaterale, texteEntete: str): self._texteEntete = texteEntete

    @property
    def texte(self: BarreLaterale) -> str: return self._texte

    @texte.setter
    def texte(self: BarreLaterale, texte: str): self._texte = texte

    @property
    def widgetCartes(self: BarreLaterale) -> list[WidgetCarte]: return self._widgetCartes

    @widgetCartes.setter
    def widgetCartes(self: BarreLaterale, widgetCartes: list[WidgetCarte]): self._widgetCartes = widgetCartes

    # Méthodes
    def afficher(self: BarreLaterale, ecran: pygame.Surface, joueurActuel: int, index_widget_select: int = None, combat: bool = False, capacite: bool = True):
        """Affiche la barre latérale et les différents widgets la composant à l'écran

        Args:
            ecran (pygame.Surface): La surface sur laquelle afficher la barre latérale
            joueurActuel (int): Le numéro du joueur actuel
            combat (bool, optional): Sert à vérifier quelle carte afficher. Defaults to False.
        """
        # Affichage de la barre
        self._texteEntete = self._fontEntete.render(f"{Joueur.getAllJoueur()[joueurActuel].nom} - {Joueur.getAllJoueur()[joueurActuel].niveau}", True, (255, 255, 255))
        self._surface.fill(pygame.Color(50,50,50))
        self._surface.blit(self._texteEntete, (self._rect.width/2-self._texteEntete.get_width()/2, 5))
        self._surface.blit(self._labelBDV, (10, 50))
        self._barreDeVie.fill(pygame.Color(255, 0, 0))
        self._barreDeVie.fill(
            pygame.Color(0, 255, 0),
            pygame.Rect(0, 0, (self._rect.width-20-self._labelBDV.get_width())*(Joueur.getAllJoueur()[joueurActuel].pointDeVie/Joueur.getAllJoueur()[joueurActuel].pointDeVieMax), 30)
        )
        self._surface.blit(self._barreDeVie, (self._labelBDV.get_width()+10, 50))
        self._surface.blit(self._labelEXP, (10, 90))
        self._barreEXP.fill(pygame.Color(0, 0, 153))
        self._barreEXP.fill(
            pygame.Color(0, 255, 255),
            pygame.Rect(0, 0, (self._rect.width-20-self._labelEXP.get_width())*(Joueur.getAllJoueur()[joueurActuel].pointExperience/Joueur.getAllJoueur()[joueurActuel]._pointExperienceMax), 30))
        self._surface.blit(self._barreEXP, (self._labelEXP.get_width()+10, 90))
        ecran.blit(self._surface, self._rect)

        # Récupération des différents widgets cartes.
        self._widgetCartes = []
        if not combat:
            if Joueur.getAllJoueur()[joueurActuel].capaciteSpeciale == CapaciteSpeciale.Piege_a_ours and Joueur.getAllJoueur()[joueurActuel].capaciteDisponible and capacite:
                self._widgetCartes.append(WidgetCarte(
                    Joueur.getAllJoueur()[joueurActuel].capaciteSpeciale.name.replace("_", " "),
                    Joueur.getAllJoueur()[joueurActuel].capaciteSpeciale.value,
                    None,
                    fr"{constant.REPERTOIRE_COURANT}/ressources/icones/icone_{Joueur.getAllJoueur()[joueurActuel].capaciteSpeciale.name.lower()}.png",
                    (51, 153, 255),
                    (len(self._widgetCartes) == index_widget_select)
                ))
            for i in range(len(Joueur.getAllJoueur()[joueurActuel].cartes)):
                c = Joueur.getAllJoueur()[joueurActuel].cartes[i]
                if c.typeCarte in [TypeCarte.Plateau, TypeCarte.Case, TypeCarte.Utilisable, TypeCarte.Placable]:
                    self._widgetCartes.append(WidgetCarte(
                        c.nom.replace("_", " "),
                        c.description,
                        i,
                        fr"{constant.REPERTOIRE_COURANT}/ressources/icones/icone_{c.nom.lower()}.png",
                        (204, 102, 0),
                        (len(self._widgetCartes) == index_widget_select)
                    ))
        else:
            if Joueur.getAllJoueur()[joueurActuel].capaciteSpeciale != CapaciteSpeciale.Piege_a_ours and Joueur.getAllJoueur()[joueurActuel].capaciteDisponible and capacite:
                self._widgetCartes.append(WidgetCarte(
                    Joueur.getAllJoueur()[joueurActuel].capaciteSpeciale.name.replace("_", "\n"),
                    Joueur.getAllJoueur()[joueurActuel].capaciteSpeciale.value,
                    None,
                    fr"{constant.REPERTOIRE_COURANT}/ressources/icones/icone_{Joueur.getAllJoueur()[joueurActuel].capaciteSpeciale.name.lower()}.png",
                    (51, 153, 255),
                    (len(self._widgetCartes) == index_widget_select)
                ))
            for i in range(len(Joueur.getAllJoueur()[joueurActuel].cartes)):
                c = Joueur.getAllJoueur()[joueurActuel].cartes[i]
                if c.typeCarte in [TypeCarte.Consommable]:
                    self._widgetCartes.append(WidgetCarte(
                        c.nom.replace("_", " "),
                        c.description,
                        i,
                        fr"{constant.REPERTOIRE_COURANT}/ressources/icones/icone_{c.nom.lower()}.png",
                        (0, 204, 102),
                        (len(self._widgetCartes) == index_widget_select)
                    ))

        # Affichage des widgets de cartes sur trois lignes et deux colonnes
        for i in range(len(self._widgetCartes)):
            self._widgetCartes[i].afficher(ecran, ((400-60)//2, (720-150-40)//3), (10+((i%2)*(20+(400-30)//2)), 150+((i//2)*(10+(720-150-40)//3))))