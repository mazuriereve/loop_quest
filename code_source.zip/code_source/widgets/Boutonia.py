from __future__ import annotations
from widgets.Bouton import Bouton
import pygame

class BoutonIa(Bouton):
    """Classe modélisant un bouton qui affiche un nombre croissant de 0 à 3, puis revient à 0"""
    # Constructeur
    def __init__(self: BoutonIa, texte:str, couleurSurface: tuple[int, int, int], couleurPolice: tuple[int, int, int], position: tuple[int, int]):
        """Constructeur

        Args:
         - position (tuple[int, int]): Position du bouton sur l'écran
        """
        super().__init__(texte, couleurSurface, couleurPolice, position)
        self._click_count = 0
        self._active: bool = False 
        self._couleurPolice: tuple[int, int, int] = (255, 255, 255)
        self._couleurInactive: tuple[int, int, int] = (0, 0, 0)
        self._couleurActive1: tuple[int, int, int] = (0, 255, 0)
        self._couleurActive2: tuple[int, int, int] = (255, 255, 0)
        self._couleurActive3: tuple[int, int, int] = (255, 0, 0)
        
    @property
    def active(self: BoutonIa) -> bool: return self._active
        
    def estClique(self: BoutonIa) -> bool:
        if super().estClique():
            if self._click_count == 0:
                self._active = not self._active
            self._click_count += 1
            if self._click_count > 3:
                self._click_count = 0
                self._active = not self._active
        self._texte = " " + str(self._click_count)
        self.update_button_color()
        return self._active

    def difficulte(self: BoutonIa) -> int:
        return self._click_count
    
    
    def update_button_color(self: BoutonIa):
        """Met à jour la couleur du bouton en fonction du nombre de clics"""
        colors = [self._couleurInactive, self._couleurActive1, self._couleurActive2, self._couleurActive3]
        self._couleurSurface = colors[self._click_count]

        # bord1 = pygame.Surface((self._rect.width, 2))
        # bord1.fill((150, 150, 150) if self._active else (255, 255, 255))
        # bord2 = pygame.Surface((2, self._rect.height+2))
        # bord2.fill((50, 50, 50) if self._active else (255, 255, 255))
        # bord3 = pygame.Surface((self._rect.width, 2))
        # bord3.fill((50, 50, 50) if self._active else (255, 255, 255))
        # bord4 = pygame.Surface((2, self._rect.height+2))
        # bord4.fill((150, 150, 150) if self._active else (255, 255, 255))

        # self._couleurSurface = self._couleurActive if self._active else self._couleurInactive

        # self._surface.fill(self._couleurSurface)
        # self._surface.blit(bord1, (0, 0))
        # self._surface.blit(bord2, (0, 0))
        # self._surface.blit(bord3, (0, self._rect.height))
        # self._surface.blit(bord4, (self._rect.width-2, 0))
        # self._surface.blit(self._font.render(self._texte, True, self._couleurPolice), (2, 2))

        