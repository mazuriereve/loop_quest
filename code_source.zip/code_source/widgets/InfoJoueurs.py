from __future__ import annotations
import constant
from personnage.Joueur import Joueur


import pygame


class InfoJoueurs:
    def __init__(self: InfoJoueurs, taille: tuple[int, int], position: tuple[int, int]):
        self._taille = taille
        self._position = position

    @property
    def taille(self: InfoJoueurs) -> tuple[int, int]: return self._taille

    @taille.setter
    def taille(self: InfoJoueurs, taille: tuple[int, int]): self._taille = taille

    @property
    def position(self: InfoJoueurs) -> tuple[int, int]: return self._position

    @position.setter
    def position(self: InfoJoueurs, position: tuple[int, int]): self._position = position

    def afficher(self: InfoJoueurs, ecran: pygame.Surface, joueurActuel: int):
        surface = pygame.Surface(self._taille)
        surface.fill(pygame.Color(0, 0, 0))
        surface.set_alpha(200)
        font = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 30)
        pions = pygame.image.load(constant.CHEMIN_PION)
        for i in range(len(Joueur.getAllJoueur())):
            pion = pions.subsurface((i*constant.DIMENSION_PION[0], 0, constant.DIMENSION_PION[0], constant.DIMENSION_PION[1]))
            if i == joueurActuel:
                texte = font.render(f"{Joueur.getAllJoueur()[i].nom} - Niveau {Joueur.getAllJoueur()[i].niveau}", True, (255, 0, 0))
            else:
                texte = font.render(f"{Joueur.getAllJoueur()[i].nom} - Niveau {Joueur.getAllJoueur()[i].niveau}", True, (255, 255, 255))
            if i%2 == 0:
                surface.blit(pion, (10, 10+(i//2)*10+(i//2)*constant.DIMENSION_PION[1]))
                surface.blit(texte, (10+constant.DIMENSION_PION[0]+10, 10+(i//2)*10+(i//2)*constant.DIMENSION_PION[1]))
            else:
                surface.blit(pion, (self.taille[0]-10-constant.DIMENSION_PION[0], 10+(i//2)*10+(i//2)*constant.DIMENSION_PION[1]))
                surface.blit(texte, (self.taille[0]-10-constant.DIMENSION_PION[0]-10-texte.get_width(), 10+(i//2)*10+(i//2)*constant.DIMENSION_PION[1]))


        ecran.blit(surface, self._position)
        pygame.display.flip()