from __future__ import annotations
from case.Case import Case
from personnage.Joueur import Joueur


import pygame


class EcranCombat:
    # Constructeur
    def __init__(self: EcranCombat):
        self._surface: pygame.Surface = pygame.Surface((880, 720))
        self._emplacementJoueur: int = (200, 300)
        self._emplacementEnnemis: list[int] = [(550, 240), (650, 400), (650, 106), (740, 260)]

    # Getters et setters
    @property
    def surface(self: EcranCombat) -> pygame.Surface: return self._surface

    @surface.setter
    def surface(self: EcranCombat, surface: pygame.Surface): self._surface = surface

    @property
    def emplacementJoueur(self: EcranCombat) -> int: return self._emplacementJoueur

    @emplacementJoueur.setter
    def emplacementJoueur(self: EcranCombat, emplacementJoueur: int): self._emplacementJoueur = emplacementJoueur

    @property
    def emplacementEnnemis(self: EcranCombat) -> list[int]: return self._emplacementEnnemis

    @emplacementEnnemis.setter
    def emplacementEnnemis(self: EcranCombat, emplacementEnnemis: list[int]): self._emplacementEnnemis = emplacementEnnemis

    # Méthode
    def afficher(self: EcranCombat, ecran: pygame.Surface, case: Case, joueurActuel: int):
        self._surface.fill(pygame.Color(0, 0, 0))

        # Affichage du joueur
        joueur = pygame.transform.scale_by(Joueur.getAllJoueur()[joueurActuel].recupererSprite(), Joueur.getAllJoueur()[joueurActuel].scaling)
        self._surface.blit(joueur, (self._emplacementJoueur[0]-joueur.get_width()/2, self._emplacementJoueur[1]))

        # Affichage des ennemis et de leur barre de vie
        for i in range(len(case.listeEnnemis)):
            spriteEnnemi = pygame.transform.flip(pygame.transform.scale_by(case.listeEnnemis[i].recupererSprite(), case.listeEnnemis[i].scaling), True, False)
            self._surface.blit(spriteEnnemi, (self._emplacementEnnemis[i][0]-spriteEnnemi.get_width()/2, self._emplacementEnnemis[i][1]))
            fondBarreDeVie = pygame.Surface((64, 10))
            fondBarreDeVie.fill(pygame.Color(255, 0, 0))
            barreDeVie = pygame.Surface((64*((case.listeEnnemis[i].pointDeVie if case.listeEnnemis[i].pointDeVie >= 0 else 0)/case.listeEnnemis[i].pointDeVieMax), 10))
            barreDeVie.fill(pygame.Color(0, 255, 0))
            fondBarreDeVie.blit(barreDeVie, (0, 0))
            self._surface.blit(fondBarreDeVie, (self._emplacementEnnemis[i][0]-fondBarreDeVie.get_width()/2, self._emplacementEnnemis[i][1]-10))

        # Affichage de l'écran de combat sur l'écran principal
        ecran.blit(self._surface, (400, 0))