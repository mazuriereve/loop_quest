from __future__ import annotations
import constant


import pygame


class Bouton:
    """Classe modélisant un bouton contenant un texte et d'une certaine couleur"""
    # Constructeur
    def __init__(self: Bouton, texte: str, couleurSurface: tuple[int, int, int], couleurPolice: tuple[int, int, int], position: tuple[int, int]):
        """Constructeur

        Args:
         - texte (str): Texte à afficher sur le bouton
         - couleurSurface (tuple[int, int, int]): Couleur de fond du bouton
         - couleurPolice (tuple[int, int, int]): Couleur du texte du bouton
         - position (tuple[int, int]): Position du bouton sur l'écran
        """
        self._texte: str = texte
        self._couleurPolice: tuple[int, int, int] = couleurPolice
        self._couleurSurface: tuple[int, int, int] = couleurSurface
        self._font = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 40)
        self._rect = self._font.render(self._texte, True, self._couleurPolice).get_rect()
        self._rect.x = position[0] ; self._rect.y = position[1]
        self._actif: bool = False

    # Getters et setters
    @property
    def texte(self: Bouton) -> str: return self._texte

    @texte.setter
    def texte(self: Bouton, texte: str): self._texte = texte

    @property
    def couleur(self: Bouton) -> tuple[int, int, int]: return self._couleurPolice

    @couleur.setter
    def couleur(self: Bouton, couleur: tuple[int, int, int]): self._couleurPolice = couleur

    @property
    def position(self: Bouton) -> tuple[int, int]: return self._position

    @position.setter
    def position(self: Bouton, position: tuple[int, int]):
        self._position = position
        self._rect.x = position[0] ; self._rect.y = position[1]

    @property
    def font(self: Bouton) -> pygame.font.Font: return self._font

    @font.setter
    def font(self: Bouton, font: pygame.font.Font): self._font = font

    @property
    def rect(self: Bouton) -> pygame.Rect: return self._rect

    @rect.setter
    def rect(self: Bouton, rect: pygame.Rect): self._rect = rect
    
    @property
    def actif(self: Bouton) -> bool: return self._actif
    
    @actif.setter
    def actif(self: Bouton, actif: bool): self._actif = actif

    # Méthodes
    def afficher(self: Bouton, ecran: pygame.Surface):
        """Affiche le bouton sur l'écran

        Args:
         - ecran (pygame.Surface): L'écran sur lequel afficher le bouton
        """
        # Style du bouton
        self._surface = pygame.Surface((self._rect.width, self._rect.height+2))
        self._surface.fill(self._couleurSurface if not self._actif else (self._couleurSurface[0]-75, self._couleurSurface[1]-75, self._couleurSurface[2]-75))
        bord1 = pygame.Surface((self._rect.width, 2))
        bord1.fill((150, 150, 150))
        bord2 = pygame.Surface((2, self._rect.height+2))
        bord2.fill((50, 50, 50))
        bord3 = pygame.Surface((self._rect.width, 2))
        bord3.fill((50, 50, 50))
        bord4 = pygame.Surface((2, self._rect.height+2))
        bord4.fill((150, 150, 150))

        self._surface.blit(bord1, (0, 0))
        self._surface.blit(bord2, (0, 0))
        self._surface.blit(bord3, (0, self._rect.height))
        self._surface.blit(bord4, (self._rect.width-2, 0))
        self._surface.blit(self._font.render(self._texte, True, self._couleurPolice if not self._actif else (self._couleurPolice[0]-100, self._couleurPolice[1]-100, self._couleurPolice[2]-100)), (2, 2))
        
        ecran.blit(self._surface, self._rect)

    def estClique(self: Bouton, pos: tuple[int, int] = None) -> bool:
        """Renvoie True si le bouton est cliqué, False sinon

        Returns:
            bool: True si le bouton est cliqué, False sinon
        """
        if pos is None:
            pos = pygame.mouse.get_pos()
            
        return self._rect.collidepoint(pos)
