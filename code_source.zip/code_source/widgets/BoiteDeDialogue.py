from __future__ import annotations
import constant
from widgets.fonctions import contourRect


import pygame


class BoiteDeDialogue:
    def __init__(self: BoiteDeDialogue, taille: tuple[int, int], position: tuple[int, int]):
        self._taille = taille
        self._position = position
        self._texte = "Texte"

    @property
    def taille(self: BoiteDeDialogue) -> tuple[int, int]: return self._taille

    @taille.setter
    def taille(self: BoiteDeDialogue, taille: tuple[int, int]): self._taille = taille

    @property
    def position(self: BoiteDeDialogue) -> tuple[int, int]: return self._position

    @position.setter
    def position(self: BoiteDeDialogue, position: tuple[int, int]): self._position = position

    @property
    def texte(self: BoiteDeDialogue) -> str: return self._texte

    @texte.setter
    def texte(self: BoiteDeDialogue, texte: str): self._texte = texte

    def afficher(self: BoiteDeDialogue, ecran: pygame.Surface, texte: str = None):
        if texte != None:
            self._texte = texte
        surface: pygame.Surface = pygame.Surface(self._taille)
        rect = surface.get_rect()
        font = pygame.font.Font(constant.CHEMIN_POLICE_NORMAL, 40)

        for bord, pos in contourRect(rect, (255, 255, 255), 4):
            surface.blit(bord, pos)

        lignesTexte = self._texte.split("\n")
        for i in range(len(lignesTexte)):
            ligne = font.render(lignesTexte[i], True, (255, 255, 255))
            surface.blit(ligne, (10, 10+(i*40)))

        ecran.blit(surface, self._position)
        pygame.display.flip()