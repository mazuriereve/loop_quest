from __future__ import annotations

from abc import ABC, abstractmethod

import pygame
from personnage.Joueur import Joueur
import constant
from widgets.fonctions import contourRect


class MagasinBoutonStat(ABC):
    def __init__(self: MagasinBoutonStat, nom: str, taille: tuple[int, int], position: tuple[int, int], prix: int, valeurBonus: int = 1):
        self.nom: str = nom
        self.taille: tuple[int, int] = taille
        self.position: tuple[int, int] = position
        self.valeurBonus: int = valeurBonus
        self.prix: int = prix
        self.selectionne: bool = False
        self.surface: pygame.Surface = pygame.Surface(taille)
    
    def estClique(self: MagasinBoutonStat, positionSouris: tuple[int, int]) -> bool:
        return self.position[0] <= positionSouris[0] <= self.position[0] + self.taille[0] and self.position[1] <= positionSouris[1] <= self.position[1] + self.taille[1]
    
    def afficher(self: MagasinBoutonStat, ecran: pygame.Surface):
        self.surface.fill(pygame.Color(0, 0, 0))
        
        icone = pygame.image.load(f"ressources/icones/{self.nom.lower()}.png")
        icone = pygame.transform.scale(icone, self.taille)
        self.surface.blit(icone, (0, 0))
        ecran.blit(self.surface, self.position)
        
        contours = contourRect(pygame.Rect(self.position, self.taille), pygame.Color(255, 255, 0) if self.selectionne else pygame.Color(255, 255, 255), 2)
        for contour in contours:
            ecran.blit(contour[0], contour[1])
            
    @abstractmethod
    def donnerBonus(self: MagasinBoutonStat, joueur: Joueur):
        pass
    
    
class MagasinBoutonAtq(MagasinBoutonStat):
    def __init__(self: MagasinBoutonAtq, taille: tuple[int, int], position: tuple[int, int], prix: int, valeurBonus: int = 1):
        super().__init__("Atq", taille, position, prix, valeurBonus)
    
    def donnerBonus(self: MagasinBoutonStat, joueur: Joueur):

        joueur.attaque += self.valeurBonus
    
class MagasinBoutonDef(MagasinBoutonStat):
    def __init__(self: MagasinBoutonDef, taille: tuple[int, int], position: tuple[int, int], prix: int, valeurBonus: int = 1):
        super().__init__("Def", taille, position, prix, valeurBonus)
    
    def donnerBonus(self: MagasinBoutonStat, joueur: Joueur):

        joueur.defense += self.valeurBonus
    
class MagasinBoutonVie(MagasinBoutonStat):
    def __init__(self: MagasinBoutonVie, taille: tuple[int, int], position: tuple[int, int], prix: int, valeurBonus: int = 1):
        super().__init__("PV", taille, position, prix, valeurBonus)
    
    def donnerBonus(self: MagasinBoutonStat, joueur: Joueur):

        joueur.pointDeVieMax += self.valeurBonus
        joueur.pointDeVie += self.valeurBonus

class MagasinBoutonVitesse(MagasinBoutonStat):
    def __init__(self: MagasinBoutonVitesse, taille: tuple[int, int], position: tuple[int, int], prix: int, valeurBonus: int = 1):
        super().__init__("Vit", taille, position, prix, valeurBonus)
    
    def donnerBonus(self: MagasinBoutonStat, joueur: Joueur):

        joueur.vitesse += self.valeurBonus
    
# class MagasinBoutonReload