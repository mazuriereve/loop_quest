from widgets.MagasinBoutonStat import MagasinBoutonStat, MagasinBoutonAtq, MagasinBoutonDef, MagasinBoutonVie, MagasinBoutonVitesse

from random import randint

def genererBoutonRandom(taille: tuple[int, int], position: tuple[int, int], atq: int, defense: int, pv: int, vit: int) -> MagasinBoutonStat:
    """
    Fonction qui génère un bouton pour générer un nombre aléatoire
    """
    match randint(0, 3):
        case 0:
            return MagasinBoutonAtq(taille, position, atq+1)
        case 1:
            return MagasinBoutonDef(taille, position, defense+1)
        case 2:
            return MagasinBoutonVie(taille, position, pv+1, 5)
        case 3:
            return MagasinBoutonVitesse(taille, position, vit+1)