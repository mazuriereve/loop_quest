from __future__ import annotations
import pygame


from abc import ABC


class ObjetAnime(ABC):
    """Classe abstraite permettant de gérer l'affichage des différents sprites d'un objet animé"""
    # Constructeur
    def __init__(self: ObjetAnime, cheminSpriteSheet: str, dimension: tuple[int, int], scaling: float, delai: int):
        """
        Initialise un objet animé compte tenu de son sprite sheet, de ses dimensions, de son scaling et de son délai

        Args:
        - cheminSpriteSheet (str): le chemin vers le sprite sheet de l'objet animé
        - dimension (tuple[int, int]): les dimensions d'un sprite de l'objet animé
        - scaling (float): le scaling de l'objet animé
        - delai (int): le délai entre chaque sprite de l'objet animé
        """
        self._spriteSheet = pygame.image.load(cheminSpriteSheet)
        self._dimension = dimension
        self._scaling = scaling
        self._numeroSprite = 0
        self._delai = delai
        self._delaiDepart = delai

    # Getters et setters
    @property
    def spriteSheet(self: ObjetAnime) -> pygame.Surface: return self._spriteSheet

    @spriteSheet.setter
    def spriteSheet(self: ObjetAnime, spriteSheet: pygame.Surface): self._spriteSheet = spriteSheet

    @property
    def dimension(self: ObjetAnime) -> tuple[int, int]: return self._dimension

    @dimension.setter
    def dimension(self: ObjetAnime, dimension: tuple[int, int]): self._dimension = dimension

    @property
    def scaling(self: ObjetAnime) -> float: return self._scaling

    @scaling.setter
    def scaling(self: ObjetAnime, scaling: float): self._scaling = scaling

    @property
    def numeroSprite(self: ObjetAnime) -> int: return self._numeroSprite

    @numeroSprite.setter
    def numeroSprite(self: ObjetAnime, numeroSprite: int): self._numeroSprite = numeroSprite

    @property
    def delai(self: ObjetAnime) -> int: return self._delai

    @delai.setter
    def delai(self: ObjetAnime, delai: int): self._delai = delai

    @property
    def delaiDepart(self: ObjetAnime) -> int: return self._delaiDepart

    @delaiDepart.setter
    def delaiDepart(self: ObjetAnime, delaiDepart: int): self._delaiDepart = delaiDepart

    # Méthodes
    def envoiSprite(self: ObjetAnime) -> pygame.Surface:
        """Renvoie le bon sprite nécessaire à l'affichage du feu de camp

        Returns:
            pygame.Surface: Le sprite actuel du feu de camp
        """
        self._delai -= 1
        if self._delai == 0:
            self._numeroSprite += 1
            self._delai = self._delaiDepart
            if self._numeroSprite == self._spriteSheet.get_width()//self._dimension[0]:
                self._numeroSprite = 0
        return pygame.transform.scale_by(self._spriteSheet.subsurface((self._numeroSprite)*self._dimension[0], 0, self._dimension[0], self._dimension[1]), self._scaling)