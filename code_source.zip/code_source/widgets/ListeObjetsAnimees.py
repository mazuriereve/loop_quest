from __future__ import annotations
import constant as constant
from widgets.ObjetAnime import ObjetAnime


from enum import Enum


class ListeObjetsAnimees(Enum):
    """Liste des objets animés du jeu"""
    FeuDeCamp = (constant.CHEMIN_FEUDECAMP, constant.DIMENSION_FEUDECAMP, constant.SCALING_FEUDECAMP, 5)
    Portail = (constant.CHEMIN_PORTAIL, constant.DIMENSION_PORTAIL, constant.SCALING_PORTAIL, 50)

    def creerObjetAnime(self: ListeObjetsAnimees) -> ObjetAnime:
        """Crée un objet animé

        Returns:
            ObjetAnime: L'objet animé créé
        """
        return ObjetAnime(self.value[0], self.value[1], self.value[2], self.value[3])