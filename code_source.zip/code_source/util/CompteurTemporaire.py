from __future__ import annotations

from typing_extensions import TypeVar

from util.ProprietaireCompteur import ProprietaireCompteur
from util.Compteur import Compteur

T = TypeVar('T', bound=ProprietaireCompteur)

O = TypeVar('O')


from typing_extensions import override


class CompteurTemporaire(Compteur):
    """Identique à un compteur mais qui se retire de la liste des compteurs quand il arrive à 0"""
    # Constructeur
    def __init__(self: CompteurTemporaire, valeur: int):
        super().__init__(valeur)

    @override
    def decompter(self: Compteur):
        """
        Décrémente la valeur du compteur de 1. Si la valeur atteint 0 ou moins, retire le compteur de la liste des compteurs.
        """
        self._valeur -= 1
        if self._proprietaire != None:
            self._proprietaire.compteurModifie()
        if self._valeur <= 0:
            self.retirerCompteur()