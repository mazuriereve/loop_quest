from __future__ import annotations

from typing_extensions import TypeVar
from typing_extensions import Generic

from util.ProprietaireCompteur import ProprietaireCompteur

T = TypeVar('T', bound=ProprietaireCompteur)

O = TypeVar('O')


class Compteur(Generic[T]):
    """Classe compteur permettant prennant en charge plusieurs objet compteur à decompter en même temps

    Attributs:
    - valeur (int): La valeur du compteur
    - valeurInitiale (int): La valeur initiale du compteur
    - proprietaire (T): Le propriétaire du compteur
    """

    allCompteur: list[Compteur] = []
    """Liste de tous les compteurs créés"""

    @staticmethod
    def getAllCompteur() -> list[Compteur]:
        """Retourne la liste de tous les compteurs créés"""
        return Compteur.allCompteur

    @staticmethod
    def setAllCompteur(allCompteur: list[Compteur]):
        """Modifie la liste de tous les compteurs créés"""
        Compteur.allCompteur = allCompteur

    @staticmethod
    def decompterAll():
        """Décrémente tous les compteurs de la liste des compteurs"""
        compteurs: list[Compteur] = list(Compteur.getAllCompteur())
        for compteur in compteurs:
            compteur.decompter()

    def __init__(self: Compteur, valeur: int):
        self._valeur: int = valeur
        self._valeurInitiale: int = valeur
        self._proprietaire: T = None
        Compteur.allCompteur.append(self)

    @property
    def valeur(self: Compteur) -> int: return self._valeur

    @valeur.setter
    def valeur(self: Compteur, valeur: int): self._valeur = valeur

    @property
    def valeurInitiale(self: Compteur) -> int: return self._valeurInitiale

    @valeurInitiale.setter
    def valeurInitiale(self: Compteur, valeurInitiale: int): self._valeurInitiale = valeurInitiale

    @property
    def proprietaire(self: Compteur) -> T: return self._proprietaire

    @proprietaire.setter
    def proprietaire(self: Compteur, proprio: T): self._proprietaire = proprio

    def ajouterProprietaire(self: Compteur, proprio: T):
        """Ajoute un propriétaire au compteur"""
        self._proprietaire = proprio

    def decompter(self: Compteur):
        """
        Décrémente la valeur du compteur et notifie son propriétaire si le compteur est à zéro

        Si le compteur est à zéro, sa valeur est remise à sa valeur initiale.
        """
        self._valeur -= 1
        if self._proprietaire != None:
            self._proprietaire.compteurModifie()
        if self._valeur <= 0:
            self._valeur = self._valeurInitiale

    def retirerCompteur(self: Compteur):
        """Retire le compteur de la liste des compteurs"""
        self._proprietaire = None
        Compteur.allCompteur.remove(self)

    def __repr__(self: Compteur) -> str:
        """Retourne une représentation en chaîne de caractères du compteur"""
        return f"Compteur n°{Compteur.getAllCompteur().index(self)} {str(self._valeur)}"