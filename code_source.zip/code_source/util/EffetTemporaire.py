from __future__ import annotations

from util.CompteurTemporaire import CompteurTemporaire
from util.Effet import Effet
from util.ProprietaireCompteur import ProprietaireCompteur
from typing_extensions import TypeVar
from typing_extensions import Callable, Optional

from util.ProprietaireCompteur import ProprietaireCompteur

T = TypeVar('T', bound=ProprietaireCompteur)

O = TypeVar('O')


from typing_extensions import Callable, Optional


class EffetTemporaire(Effet, ProprietaireCompteur):
    """
    Classe représentant un effet temporaire qui s'applique sur une cible pour une durée donnée.

    Attributs:
     - cible (O): La cible sur laquelle l'effet est appliqué.
     - operateur (Optional[Callable]): L'opérateur qui est appliqué sur la cible.
     - valeur (O): La valeur qui est utilisée pour appliquer l'effet.
     - duree (int): La durée de l'effet.
     - attributCible (Optional[str]): L'attribut de la cible sur lequel l'effet est appliqué.
     - operateurInv (Optional[Callable]): L'opérateur inverse qui est appliqué sur la cible lorsque l'effet est retiré.
     - valeurInv (Optional[O]): La valeur inverse qui est utilisée pour retirer l'effet.
     - repetition (bool): Indique si l'effet doit être répété ou inversé.
    """
    def __init__(self: EffetTemporaire, cible: O, operateur: Optional[Callable], valeur: O, duree: int, attributCible: Optional[str] = None, operateurInv: Optional[Callable] = None, valeurInv: Optional[O] = None, repetition: bool = False):
        super().__init__(cible, valeur, attributCible, operateur)
        self._duree: CompteurTemporaire = CompteurTemporaire(duree)
        self._duree.ajouterProprietaire(self)
        if operateurInv is not None and repetition == True:
            raise Exception("Un effet temporaire ne peut pas être répété et inversé en même temps")
        elif operateurInv is None and repetition == False:
            raise Exception("Un effet temporaire doit être soit répété ou soit inversé")
        self._operateurInv: Optional[Callable] = operateurInv
        self._valeurInv: Optional[O] = valeurInv
        self._repetition: bool = repetition
        self.appliquerEffet()

    # Getters et setters
    @property
    def duree(self: EffetTemporaire) -> CompteurTemporaire: return self._duree

    @duree.setter
    def duree(self: EffetTemporaire, duree: CompteurTemporaire): self._duree = duree

    @property
    def operateurInv(self: EffetTemporaire) -> Optional[Callable]: return self._operateurInv

    @operateurInv.setter
    def operateurInv(self: EffetTemporaire, operateurInv: Optional[Callable]): self._operateurInv = operateurInv

    @property
    def valeurInv(self: EffetTemporaire) -> Optional[O]: return self._valeurInv

    @valeurInv.setter
    def valeurInv(self: EffetTemporaire, valeurInv: Optional[O]): self._valeurInv = valeurInv

    @property
    def repetition(self: EffetTemporaire) -> bool: return self._repetition

    @repetition.setter
    def repetition(self: EffetTemporaire, repetition: bool): self._repetition = repetition

    # Méthodes
    def compteurModifie(self: EffetTemporaire):
        """
        Méthode appelée lorsque le compteur de l'effet est modifié.
        Si l'effet doit être répété, l'effet est appliqué à nouveau.
        Si l'effet doit être inversé et que la durée est écoulée, l'effet est retiré.
        """
        if self._repetition and self._operateurInv is None and self._duree.valeur > 0:
            self.appliquerEffet()
        if self._duree.valeur <= 0 and self._operateurInv is not None and self._repetition == False:
            self.retirerEffet()

    def retirerEffet(self: EffetTemporaire):
        """
        Méthode appelée pour retirer l'effet de la cible.
        Si l'effet a un opérateur inverse, il est appliqué sur la cible.
        """
        if self._operateurInv is not None and self._cible is not None and self._attributCible is not None and self._valeurInv is not None:
            setattr(self._cible, self._attributCible, self._operateurInv(getattr(self._cible, self._attributCible), self._valeurInv))
        elif self._cible is None and self._operateur is not None and self._valeur is not None:
            self.operateurInv(self._valeurInv)
        elif self._cible is not None and self._attributCible is not None and self._operateurInv is None and self._valeurInv is not None:
            setattr(self._cible, self._attributCible, self._valeurInv)
        elif self._cible is not None and self._attributCible is None and self._operateurInv is None and self._valeurInv is not None:
            self._cible = self._valeurInv
        else:
            raise Exception("L'effet n'a pas été correctement initialisé")