from __future__ import annotations

from typing_extensions import TypeVar
from typing_extensions import Callable, Optional

from util.ProprietaireCompteur import ProprietaireCompteur

T = TypeVar('T', bound=ProprietaireCompteur)

O = TypeVar('O')



class Effet:
    """Classe modélisant un effet. Plusieurs cas d'initialisation sont possibles:
    - tous les attributs sont définis: la valeur est appliqué sur l'attribut attributCible de l'objet cible avec l'opérateur operateur
    - cible, attributCible et valeur sont définis: la valeur est donnée sur l'attribut attributCible de l'objet cible
    - cible et valeur sont définis: la valeur est donnée à la variable cible
    - operateur et valeur sont définis: la valeur est appliquée sur la variable valeur avec l'opérateur operateur (en général une fonction ou méthode)
    """
    # Constructeur
    def __init__(self: Effet, cible: Optional[O], valeur: O, attributCible: Optional[str] = None, operateur: Optional[Callable] = None):
        self._cible: Optional[O] = cible
        self._attributCible: Optional[str] = attributCible
        self._operateur: Optional[Callable] = operateur
        self._valeur: O = valeur

    # Getters et setters
    @property
    def cible(self: Effet) -> Optional[O]: return self._cible

    @cible.setter
    def cible(self: Effet, cible: Optional[O]): self._cible = cible

    @property
    def operateur(self: Effet) -> Optional[Callable]: return self._operateur

    @operateur.setter
    def operateur(self: Effet, operateur: Optional[Callable]): self._operateur = operateur

    @property
    def valeur(self: Effet) -> O: return self._valeur

    @valeur.setter
    def valeur(self: Effet, valeur: O): self._valeur = valeur

    @property
    def attributCible(self: Effet) -> Optional[str]: return self._attributCible

    @attributCible.setter
    def attributCible(self: Effet, attributCible: Optional[str]): self._attributCible = attributCible

    # Méthodes
    def appliquerEffet(self: Effet, index: Optional[int] = None):
        """
        Applique l'effet selon les attributs indiqués lors de l'initialisation.
        Dans le cas d'un attribut de classe, si l'attribut est une liste il faut indiquer un index si l'intention est
        de modifier un élément de la liste.
        """
        import plateau
        if self._operateur is not None and self._cible is not None and self._attributCible is not None and self._valeur is not None and index is None:
            setattr(self._cible, self._attributCible, self._operateur(getattr(self._cible, self._attributCible), self._valeur))
        elif self._cible is None and self._operateur is not None and self._valeur is not None and index is None:
            self._operateur(self._valeur)
        elif self._cible is not None and self._attributCible is not None and self._operateur is None and self._valeur is not None and index is None:
            setattr(self._cible, self._attributCible, self._valeur)
        elif self._cible is not None and self._attributCible is None and self._operateur is None and self._valeur is not None and index is None:
            self._cible = self._valeur
        elif self._cible is not None and self._attributCible is None and self._operateur is not None and self._valeur is not None and index is None:
            self._cible = self._operateur(self._cible, self._valeur)
        elif self._cible is not None and self._attributCible is not None and self._valeur is not None and index is not None and self._operateur is None:
            attribut = getattr(self._cible, self._attributCible)
            attribut[index] = self._valeur
        else:
            raise Exception("L'effet n'a pas été correctement initialisé")