from abc import ABC, abstractmethod


class ProprietaireCompteur(ABC):
    """Classe abstraite (Interface) permettant de définir un propriétaire de compteur"""
    @abstractmethod
    def compteurModifie():
        """Méthode abstraite permettant de notifier le propriétaire qu'un compteur a été modifié"""
        pass

