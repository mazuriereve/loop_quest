# Luc DELAGE
# TD1-TPA
# SAE S3C1

# importations
from __future__ import annotations

import pygame
from menus.menuJeu import menuJeu

# ------------------ MAIN -------------------- #
if __name__ == "__main__":
    # pygame setup
    pygame.init()
    pygame.font.init()
    
    menuJeu()
    
    pygame.quit()